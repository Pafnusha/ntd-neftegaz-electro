"""Библиотека eldraw для черчения электрических схем в DXF/DWG/SVG."""

from eldraw.core.canvas import SchematicCanvas
from eldraw.core.grid import Grid, Point
from eldraw.core.layers import StandardLayers
from eldraw.core.styles import StandardStyles
from eldraw.frames.sheet import Sheet
from eldraw.frames.sizes import SheetFormat, SheetDimensions
from eldraw.frames.title_block import TitleBlockData
from eldraw.routing import Wire, OrthogonalRouter, JunctionManager
from eldraw.export import (
    export_dxf,
    render_preview,
    render_svg,
    render_png,
    render_pdf,
    PreviewTheme,
    DWGConverter,
    convert_dxf_to_dwg,
)
from eldraw.bom import (
    BOMItem,
    extract_bom,
    parse_refdes,
    draw_pe3_table,
    export_bom_csv,
)
from eldraw.symbols import (
    Symbol,
    Pin,
    CircuitBreaker,
    SwitchDisconnector,
    ResidualCurrentDevice,
    Fuse,
    BusBar,
    ContactorCoil,
    RelayCoil,
    NOContact,
    NCContact,
    PushButton,
    PilotLight,
    Terminal,
    Resistor,
    Capacitor,
    Inductor,
    Diode,
    BJTTransistor,
    Ground,
    MotorCircuitBreaker,
    ThermalOverloadRelay,
    VFDPowerUnit,
    VFDControlUnit,
    BrakingResistor,
    PLCDigitalInputCard,
    PLCDigitalOutputCard,
    IntermediateRelayCoil,
    ChangeoverContact,
    SafetyRelay,
    PowerSupply24V,
    MultiTierTerminal,
    SolenoidValve,
)
from eldraw.frames.multipage import (
    ColumnGrid,
    OffPageConnector,
    MultiPageProject,
)
from eldraw.domain import (
    Device,
    DeviceFunction,
    DeviceRegistry,
    Port,
    Net,
    CrossReference,
    TerminalStrip,
    ProjectNumbering,
)

__version__ = "0.1.0"

__all__ = [
    "SchematicCanvas",
    "Grid",
    "Point",
    "StandardLayers",
    "StandardStyles",
    "Sheet",
    "SheetFormat",
    "SheetDimensions",
    "TitleBlockData",
    "ColumnGrid",
    "OffPageConnector",
    "MultiPageProject",
    "Device",
    "DeviceFunction",
    "DeviceRegistry",
    "Port",
    "Net",
    "CrossReference",
    "TerminalStrip",
    "ProjectNumbering",
]

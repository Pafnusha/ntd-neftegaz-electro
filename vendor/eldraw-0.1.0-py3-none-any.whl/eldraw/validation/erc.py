"""Модуль проверок электрических правил (ERC - Electrical Rules Check)."""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Any, Dict
from eldraw.core.grid import Point


class ERCSeverity(str, Enum):
    """Уровень серьезности замечания ERC."""
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"


@dataclass
class ERCIssue:
    """Замечание проверки электрических правил."""
    severity: ERCSeverity
    code: str
    message: str
    location: Optional[Point] = None
    source: Optional[str] = None

    def __str__(self) -> str:
        loc_str = f" at ({self.location.x:.1f}, {self.location.y:.1f})" if self.location else ""
        src_str = f" [{self.source}]" if self.source else ""
        return f"[{self.severity.value}] {self.code}{src_str}: {self.message}{loc_str}"


@dataclass
class ERCReport:
    """Отчет о выполнении проверок ERC."""
    issues: List[ERCIssue] = field(default_factory=list)

    @property
    def has_errors(self) -> bool:
        """Имеются ли критические ошибки."""
        return any(issue.severity == ERCSeverity.ERROR for issue in self.issues)

    @property
    def has_warnings(self) -> bool:
        """Имеются ли предупреждения."""
        return any(issue.severity == ERCSeverity.WARNING for issue in self.issues)

    @property
    def error_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == ERCSeverity.ERROR)

    @property
    def warning_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == ERCSeverity.WARNING)

    @property
    def info_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == ERCSeverity.INFO)

    def summary(self) -> str:
        """Возвращает текстовую сводку отчета ERC."""
        lines = [
            f"=== Отчет ERC (Electrical Rules Check) ===",
            f"Ошибок: {self.error_count}, Предупреждений: {self.warning_count}, Уведомлений: {self.info_count}",
        ]
        if not self.issues:
            lines.append("✓ Все проверки успешно пройдены. Замечаний нет.")
        else:
            for issue in self.issues:
                lines.append(f"  {issue}")
        return "\n".join(lines)


class ERCChecker:
    """Выполняет проверку корректности схемы по электрическим и геометрическим правилам."""

    def __init__(self, canvas: Any):
        """
        :param canvas: Экземпляр SchematicCanvas.
        """
        self.canvas = canvas

    def run_all(
        self,
        check_unconnected: bool = True,
        check_attributes: bool = True,
    ) -> ERCReport:
        """
        Запускает полный комплекс проверок ERC.
        :param check_unconnected: Проверять ли наличие неподключенных выводов.
        :param check_attributes: Проверять ли заполненность реквизитов аппаратов.
        :return: ERCReport с результатами.
        """
        report = ERCReport()
        self.check_unique_refdes(report)
        self.check_boundary_containment(report)
        self.check_grid_alignment(report)
        self.check_short_wires(report)
        self.check_text_collisions(report)

        if check_attributes:
            self.check_missing_attributes(report)

        if check_unconnected:
            self.check_unconnected_pins(report)

        return report

    def check_unique_refdes(self, report: ERCReport) -> None:
        """Проверяет уникальность позиционных обозначений (RefDes) аппаратов."""
        seen_refdes: Dict[str, List[Any]] = {}
        for sym in self.canvas.symbols:
            ref = sym.refdes.strip() if hasattr(sym, "refdes") and sym.refdes else ""
            if not ref:
                continue
            seen_refdes.setdefault(ref, []).append(sym)

        for ref, syms in seen_refdes.items():
            if len(syms) > 1:
                # Если несколько одинаковых обозначений (например, два QF1)
                locs = [f"({s.position.x:.1f}, {s.position.y:.1f})" for s in syms if s.position]
                report.issues.append(
                    ERCIssue(
                        severity=ERCSeverity.ERROR,
                        code="ERC_DUPLICATE_REFDES",
                        message=f"Дублирующееся позиционное обозначение '{ref}' обнаружено у {len(syms)} компонентов в точках {', '.join(locs)}.",
                        source=ref,
                        location=syms[0].position if syms[0].position else None,
                    )
                )

    def check_boundary_containment(self, report: ERCReport) -> None:
        """Проверяет, что все компоненты и проводники находятся строго внутри рабочей зоны листа."""
        sheet = getattr(self.canvas, "sheet", None)
        if sheet is None:
            return

        # Проверка компонентов
        for sym in self.canvas.symbols:
            if not sym.position:
                continue
            if not sheet.is_point_in_working_area(sym.position):
                report.issues.append(
                    ERCIssue(
                        severity=ERCSeverity.ERROR,
                        code="ERC_OUT_OF_BOUNDS",
                        message=f"Компонент '{getattr(sym, 'refdes', 'Symbol')}' расположен вне рабочей зоны листа.",
                        location=sym.position,
                        source=getattr(sym, "refdes", None),
                    )
                )

            # Проверка выводов компонента
            seen_pins = set()
            for pin_name, pin in getattr(sym, "pins", {}).items():
                if pin in seen_pins:
                    continue
                seen_pins.add(pin)
                wpos = sym.pin(pin_name)
                if not sheet.is_point_in_working_area(wpos):
                    report.issues.append(
                        ERCIssue(
                            severity=ERCSeverity.ERROR,
                            code="ERC_PIN_OUT_OF_BOUNDS",
                            message=f"Вывод '{pin_name}' компонента '{getattr(sym, 'refdes', 'Symbol')}' выходит за пределы рабочей зоны листа.",
                            location=wpos,
                            source=getattr(sym, "refdes", None),
                        )
                    )

        # Проверка проводников
        for wire in getattr(self.canvas, "wires", []):
            for pt in wire.points:
                if not sheet.is_point_in_working_area(pt):
                    report.issues.append(
                        ERCIssue(
                            severity=ERCSeverity.ERROR,
                            code="ERC_WIRE_OUT_OF_BOUNDS",
                            message=f"Проводник '{wire.name}' выходит за пределы рабочей зоны листа.",
                            location=pt,
                            source=wire.name or "Wire",
                        )
                    )
                    break

    def check_grid_alignment(self, report: ERCReport) -> None:
        """Проверяет выравнивание компонентов, выводов и проводников по координатной сетке."""
        grid = getattr(self.canvas, "grid", None)
        if grid is None:
            return

        for sym in self.canvas.symbols:
            if not getattr(sym, "placed", False) or not sym.position:
                continue

            if not grid.is_on_grid(sym.position):
                report.issues.append(
                    ERCIssue(
                        severity=ERCSeverity.WARNING,
                        code="ERC_OFF_GRID_SYMBOL",
                        message=f"Точка вставки компонента '{getattr(sym, 'refdes', 'Symbol')}' не выровнена по сетке {grid.step} мм.",
                        location=sym.position,
                        source=getattr(sym, "refdes", None),
                    )
                )

            seen_pins = set()
            for pin_name, pin in getattr(sym, "pins", {}).items():
                if pin in seen_pins:
                    continue
                seen_pins.add(pin)
                wpos = sym.pin(pin_name)
                if not grid.is_on_grid(wpos):
                    report.issues.append(
                        ERCIssue(
                            severity=ERCSeverity.WARNING,
                            code="ERC_OFF_GRID_PIN",
                            message=f"Вывод '{pin_name}' компонента '{getattr(sym, 'refdes', 'Symbol')}' не лежит в узле сетки {grid.step} мм.",
                            location=wpos,
                            source=getattr(sym, "refdes", None),
                        )
                    )

        for wire in getattr(self.canvas, "wires", []):
            for pt in wire.points:
                if not grid.is_on_grid(pt):
                    report.issues.append(
                        ERCIssue(
                            severity=ERCSeverity.WARNING,
                            code="ERC_OFF_GRID_WIRE",
                            message=f"Вершина проводника не выровнена по сетке {grid.step} мм.",
                            location=pt,
                            source=wire.name or "Wire",
                        )
                    )
                    break

    def check_unconnected_pins(self, report: ERCReport) -> None:
        """Проверяет наличие свободных (висячих) выводов у аппаратов."""
        wires = getattr(self.canvas, "wires", [])
        if not wires and not self.canvas.symbols:
            return

        for sym in self.canvas.symbols:
            if not getattr(sym, "placed", False) or not sym.position:
                continue
            seen_pins = set()
            for pin_name, pin in getattr(sym, "pins", {}).items():
                if pin in seen_pins:
                    continue
                seen_pins.add(pin)
                wpos = sym.pin(pin_name)
                connected = False
                for wire in wires:
                    # Проверяем совпадение с началом или концом провода, либо сегментом
                    if wire.contains_point(wpos, tol=0.1):
                        connected = True
                        break
                if not connected:
                    report.issues.append(
                        ERCIssue(
                            severity=ERCSeverity.WARNING,
                            code="ERC_UNCONNECTED_PIN",
                            message=f"Вывод '{pin_name}' аппарата '{getattr(sym, 'refdes', 'Symbol')}' не подключен ни к одной линии связи.",
                            location=wpos,
                            source=getattr(sym, "refdes", None),
                        )
                    )

    def check_short_wires(self, report: ERCReport) -> None:
        """Проверяет наличие проводников нулевой длины."""
        for wire in getattr(self.canvas, "wires", []):
            if wire.start == wire.end and len(wire.points) <= 2:
                report.issues.append(
                    ERCIssue(
                        severity=ERCSeverity.WARNING,
                        code="ERC_ZERO_LENGTH_WIRE",
                        message=f"Проводник нулевой длины обнаружен в точке {wire.start}.",
                        location=wire.start,
                        source=wire.name or "Wire",
                    )
                )

    def check_missing_attributes(self, report: ERCReport) -> None:
        """Проверяет заполненность позиционных обозначений и наименований компонентов."""
        for sym in self.canvas.symbols:
            if sym.__class__.__name__ in ("Ground", "Earth"):
                continue

            ref = getattr(sym, "refdes", "")
            if not ref or not ref.strip():
                report.issues.append(
                    ERCIssue(
                        severity=ERCSeverity.WARNING,
                        code="ERC_MISSING_REFDES",
                        message=f"У компонента типа {sym.__class__.__name__} не задано позиционное обозначение (RefDes).",
                        location=sym.position,
                    )
                )
            model = getattr(sym, "model", "") or getattr(sym, "value", "")
            if not model or not str(model).strip():
                report.issues.append(
                    ERCIssue(
                        severity=ERCSeverity.INFO,
                        code="ERC_MISSING_MODEL",
                        message=f"У компонента '{ref or sym.__class__.__name__}' не заполнена марка/номинал (model/value).",
                        location=sym.position,
                        source=ref,
                    )
                )

    def check_text_collisions(self, report: ERCReport) -> None:
        """
        Проверяет наложение (коллизии) текстов на проводники, символы аппаратов и другие тексты.
        """
        texts = getattr(self.canvas, "texts", [])
        if not texts:
            return

        wires = getattr(self.canvas, "wires", [])
        symbols = getattr(self.canvas, "symbols", [])

        # 1. Проверка наложения Текст vs Текст
        for i in range(len(texts)):
            t1 = texts[i]
            b1 = t1.get_bbox(margin=0.1)
            for j in range(i + 1, len(texts)):
                t2 = texts[j]
                b2 = t2.get_bbox(margin=0.1)
                if t1.intersects_bbox(b2, margin=0.0):
                    report.issues.append(
                        ERCIssue(
                            severity=ERCSeverity.WARNING,
                            code="ERC_TEXT_TEXT_COLLISION",
                            message=f"Наложение текста: надпись '{t1.text}' перекрывает '{t2.text}' в точке ({t1.position.x:.1f}, {t1.position.y:.1f}).",
                            location=t1.position,
                            source=t1.source or t1.text,
                        )
                    )

        # 2. Проверка наложения Текст vs Проводники (Wire)
        for text in texts:
            for wire in wires:
                # Если текст является маркировкой этого же провода, пропускаем
                if text.text == wire.name:
                    continue
                # Проверяем каждый сегмент провода
                for k in range(len(wire.points) - 1):
                    p_start = wire.points[k]
                    p_end = wire.points[k + 1]
                    if text.intersects_segment(p_start, p_end, margin=0.3):
                        report.issues.append(
                            ERCIssue(
                                severity=ERCSeverity.WARNING,
                                code="ERC_TEXT_WIRE_COLLISION",
                                message=f"Текст '{text.text}' накладывается на проводник '{wire.name or 'Wire'}'.",
                                location=text.position,
                                source=text.source or text.text,
                            )
                        )
                        break

        # 3. Проверка наложения Текст vs Тело символа (Symbol Body)
        for text in texts:
            for sym in symbols:
                if not getattr(sym, "placed", False) or sym.position is None:
                    continue
                # Собственные подписи компонента не считаются коллизией с самим собой
                if text.source and text.source == getattr(sym, "refdes", None):
                    continue
                if hasattr(sym, "get_world_bounds"):
                    sym_bbox = sym.get_world_bounds()
                    if text.intersects_bbox(sym_bbox, margin=0.3):
                        report.issues.append(
                            ERCIssue(
                                severity=ERCSeverity.WARNING,
                                code="ERC_TEXT_SYMBOL_COLLISION",
                                message=f"Текст '{text.text}' накладывается на тело компонента '{getattr(sym, 'refdes', 'Symbol')}'.",
                                location=text.position,
                                source=getattr(sym, "refdes", None),
                            )
                        )


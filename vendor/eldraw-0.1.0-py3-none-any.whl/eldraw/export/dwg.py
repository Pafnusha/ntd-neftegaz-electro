"""Интеграция с DWG: автоопределение конвертеров и инструкции по экспорту."""

from __future__ import annotations
import shutil
import subprocess
from pathlib import Path
from typing import Optional, Union
import logging

logger = logging.getLogger(__name__)


class DWGConverter:
    """Утилита обнаружения внешних конвертеров и экспорта DXF в формат DWG."""

    @classmethod
    def detect_tool(cls) -> Optional[str]:
        """Определяет доступную в системе утилиту конвертации в DWG."""
        # 1. GNU LibreDWG (dxf2dwg)
        if shutil.which("dxf2dwg") is not None:
            return "dxf2dwg"
        # 2. ODA File Converter (Open Design Alliance)
        if shutil.which("ODAFileConverter") is not None:
            return "ODAFileConverter"
        # 3. QCAD CLI
        if shutil.which("qcad") is not None:
            return "qcad"
        return None

    @classmethod
    def is_available(cls) -> bool:
        """Проверяет, доступна ли автоматическая конвертация в DWG в текущей ОС."""
        return cls.detect_tool() is not None

    @classmethod
    def convert(
        cls,
        dxf_path: Union[str, Path],
        dwg_path: Optional[Union[str, Path]] = None,
        version: str = "R2018",
    ) -> bool:
        """
        Конвертирует DXF в DWG с помощью доступного в системе инструмента.
        :param dxf_path: Путь к исходному .dxf файлу.
        :param dwg_path: Целевой путь к .dwg файлу (по умолчанию заменяет расширение).
        :param version: Версия DWG (например, "R2018", "R2010").
        :return: True в случае успешной конвертации, False если утилиты не найдены или произошла ошибка.
        """
        in_path = Path(dxf_path)
        if not in_path.exists():
            raise FileNotFoundError(f"Исходный файл DXF не найден: {in_path}")

        out_path = Path(dwg_path) if dwg_path else in_path.with_suffix(".dwg")
        out_path.parent.mkdir(parents=True, exist_ok=True)

        tool = cls.detect_tool()
        if tool is None:
            logger.info("Утилиты прямой конвертации DXF->DWG не обнаружены.")
            return False

        try:
            if tool == "dxf2dwg":
                # Синтаксис LibreDWG: dxf2dwg [options] input.dxf -o output.dwg
                cmd = ["dxf2dwg", "-y", str(in_path), "-o", str(out_path)]
                res = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
                return res.returncode == 0 and out_path.exists()

            elif tool == "ODAFileConverter":
                # Синтаксис ODA: ODAFileConverter <in_dir> <out_dir> <out_ver> <out_type> <recurse> <audit>
                in_dir = str(in_path.parent)
                out_dir = str(out_path.parent)
                ver_map = {"R2018": "ACAD2018", "R2010": "ACAD2010"}
                acad_ver = ver_map.get(version, "ACAD2018")
                cmd = ["ODAFileConverter", in_dir, out_dir, acad_ver, "DWG", "0", "1"]
                res = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
                return res.returncode == 0 and out_path.exists()

        except Exception as e:
            logger.warning(f"Ошибка при вызове {tool}: {e}")
            return False

        return False

    @classmethod
    def get_instructions(cls) -> str:
        """Возвращает руководство по работе с DWG для инженеров."""
        return """
### 💡 Как получить DWG-файл из сгенерированного DXF:

DXF — это открытый специфицированный стандарт Autodesk, на 100% совместимый со всеми САПР.
Чтобы получить финальный `.dwg`, доступны следующие пути:

1. **Сохранение в 1 клик через САПР (Рекомендуемый способ):**
   * Откройте сгенерированный `.dxf` файл в **AutoCAD**, **nanoCAD**, **QCAD**, **BricsCAD** или **КОМПАС-3D**.
   * Нажмите `Файл` → `Сохранить как...` → выберите тип файла `AutoCAD Drawing (*.dwg)`.

2. **Автоматическая конвертация через бесплатный ODA File Converter:**
   * Скачайте [ODA File Converter](https://www.opendesign.com/guestfiles/oda_file_converter) (официальная утилита Open Design Alliance для Linux, Windows, macOS).
   * После установки eldraw автоматически подхватит утилиту и будет конвертировать файлы автономно.

3. **Установка LibreDWG (Linux):**
   * В дистрибутивах Linux доступен пакет `libredwg-tools` (утилита `dxf2dwg`).
"""


def convert_dxf_to_dwg(dxf_path: Union[str, Path], dwg_path: Optional[Union[str, Path]] = None, version: str = "R2018") -> bool:
    """Обёртка для быстрой конвертации DXF -> DWG."""
    return DWGConverter.convert(dxf_path, dwg_path, version=version)

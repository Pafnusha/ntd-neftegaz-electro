"""Профессиональный экспорт чертежа в DXF с аудитом и валидацией."""

from __future__ import annotations
from pathlib import Path
from typing import TYPE_CHECKING, List, Tuple, Union
import logging

if TYPE_CHECKING:
    from eldraw.core.canvas import SchematicCanvas

logger = logging.getLogger(__name__)


def export_dxf(
    canvas: SchematicCanvas,
    filepath: Union[str, Path],
    audit: bool = True,
) -> Path:
    """
    Экспортирует чертёж в формат DXF с проверкой целостности структуры.
    :param canvas: Холст схемы.
    :param filepath: Путь сохранения файла .dxf.
    :param audit: Выполнять ли аудит базы данных чертежа перед сохранением.
    :return: Path к сохраненному файлу.
    """
    canvas.finalize_connections()

    # Гарантируем корректность системных переменных САПР
    canvas.doc.header["$INSUNITS"] = 4  # Миллиметры
    canvas.doc.header["$MEASUREMENT"] = 1  # Метрическая система
    canvas.doc.header["$LTSCALE"] = 1.0  # Масштаб штриховки линий

    if audit:
        auditor = canvas.doc.audit()
        if auditor.has_errors:
            error_msgs = [f"[{err.code}] {err.message}" for err in auditor.errors]
            logger.warning(f"Обнаружены ошибки при аудите DXF: {error_msgs}")

    path = Path(filepath)
    path.parent.mkdir(parents=True, exist_ok=True)
    canvas.doc.saveas(str(path))
    return path

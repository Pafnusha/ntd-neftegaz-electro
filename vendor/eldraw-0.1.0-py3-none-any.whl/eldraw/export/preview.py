"""Мультиформатный рендерер превью чертежа (SVG, PNG, PDF) с поддержкой цветовых тем."""

from __future__ import annotations
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Optional, Union
import matplotlib.pyplot as plt
from ezdxf.addons.drawing import RenderContext, Frontend
from ezdxf.addons.drawing.matplotlib import MatplotlibBackend
from ezdxf.addons.drawing.config import Configuration, BackgroundPolicy, ColorPolicy

if TYPE_CHECKING:
    from eldraw.core.canvas import SchematicCanvas


class PreviewTheme(str, Enum):
    """Цветовая тема рендеринга чертежа."""

    LIGHT = "light"  # Белый фон для печати и веб-документации
    DARK = "dark"  # Тёмно-серый фон (современный интерфейс)
    CAD = "cad"  # Классический чёрный экран САПР


def render_preview(
    canvas: SchematicCanvas,
    filepath: Union[str, Path],
    fmt: Optional[str] = None,
    theme: Union[PreviewTheme, str] = PreviewTheme.LIGHT,
    dpi: int = 300,
) -> Path:
    """
    Рендерит чертёж в векторный или растровый формат с выбранной темой.
    :param canvas: Холст схемы.
    :param filepath: Путь сохранения файла (.svg, .png, .pdf).
    :param fmt: Формат файла ("svg", "png", "pdf"). Если None — определяется по расширению.
    :param theme: Цветовая тема ("light", "dark", "cad").
    :param dpi: Разрешение для растровых форматов (по умолчанию 300 DPI).
    :return: Path сохранённого файла.
    """
    canvas.finalize_connections()

    path = Path(filepath)
    path.parent.mkdir(parents=True, exist_ok=True)

    target_fmt = (fmt or path.suffix.lstrip(".").lower()) or "svg"
    theme_val = PreviewTheme(theme) if isinstance(theme, str) else theme

    # Настройка цветовой палитры фона
    if theme_val == PreviewTheme.DARK:
        bg_color = "#1E1E1E"
    elif theme_val == PreviewTheme.CAD:
        bg_color = "#000000"
    else:
        bg_color = "#FFFFFF"

    # Конфигурация рендерера ezdxf
    config = Configuration(
        background_policy=BackgroundPolicy.CUSTOM,
        custom_bg_color=bg_color,
        color_policy=ColorPolicy.COLOR,
        lineweight_scaling=1.0,
    )

    # Инициализация Matplotlib
    fig = plt.figure(dpi=dpi if target_fmt == "png" else 100)
    ax = fig.add_axes([0, 0, 1, 1])

    ctx = RenderContext(canvas.doc)
    ctx.set_current_layout(canvas.msp)
    out = MatplotlibBackend(ax)

    frontend = Frontend(ctx, out, config=config)
    frontend.draw_layout(canvas.msp, finalize=True)

    save_kwargs = {
        "format": target_fmt,
        "bbox_inches": "tight",
        "facecolor": bg_color,
        "edgecolor": "none",
    }
    if target_fmt == "png":
        save_kwargs["dpi"] = dpi

    fig.savefig(str(path), **save_kwargs)
    plt.close(fig)

    return path


def render_svg(canvas: SchematicCanvas, filepath: Union[str, Path], theme: Union[PreviewTheme, str] = PreviewTheme.LIGHT) -> Path:
    """Рендерит векторный SVG-файл."""
    return render_preview(canvas, filepath, fmt="svg", theme=theme)



def render_svg_string(canvas, theme: str = "light") -> str:
    """SVG как строка без файлов (для браузера): пишет во временный файл и читает."""
    import tempfile, os
    fp = os.path.join(tempfile.mkdtemp(), "view.svg")
    render_svg(canvas, filepath=fp, theme=theme)
    with open(fp, "r", encoding="utf-8") as fh:
        return fh.read()

def render_png(canvas: SchematicCanvas, filepath: Union[str, Path], theme: Union[PreviewTheme, str] = PreviewTheme.LIGHT, dpi: int = 300) -> Path:
    """Рендерит растровый PNG-файл с заданным DPI."""
    return render_preview(canvas, filepath, fmt="png", theme=theme, dpi=dpi)


def render_pdf(canvas: SchematicCanvas, filepath: Union[str, Path], theme: Union[PreviewTheme, str] = PreviewTheme.LIGHT) -> Path:
    """Рендерит готовый векторный PDF-документ."""
    return render_preview(canvas, filepath, fmt="pdf", theme=theme)

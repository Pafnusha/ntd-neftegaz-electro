"""Экспорт перечня элементов в форматы табличных данных (CSV для Excel)."""

from __future__ import annotations
import csv
from pathlib import Path
from typing import List, Union
from eldraw.bom.parser import BOMItem


def export_bom_csv(
    items: List[BOMItem],
    filepath: Union[str, Path],
    delimiter: str = ";",
) -> Path:
    """
    Экспортирует перечень элементов в файл формата CSV.
    Использует кодировку utf-8-sig (с BOM) для корректного открытия в Microsoft Excel и LibreOffice Calc.
    :param items: Список элементов BOMItem.
    :param filepath: Путь сохранения файла .csv.
    :param delimiter: Разделитель ячеек (по умолчанию точка с запятой ';').
    :return: Path сохранённого файла.
    """
    path = Path(filepath)
    path.parent.mkdir(parents=True, exist_ok=True)

    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f, delimiter=delimiter)
        # Заголовок таблицы по ГОСТ 2.702
        writer.writerow(["Поз. обозначение", "Наименование", "Кол.", "Примечание"])

        for item in items:
            writer.writerow([
                item.refdes,
                item.full_name,
                item.quantity,
                item.note,
            ])

    return path

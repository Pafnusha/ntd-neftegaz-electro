"""Парсер и классификатор элементов схемы по правилам ГОСТ 2.702-2011."""

from __future__ import annotations
import re
from dataclasses import dataclass
from typing import TYPE_CHECKING, Dict, List, Optional, Tuple

if TYPE_CHECKING:
    from eldraw.symbols.base import Symbol


@dataclass
class BOMItem:
    """Элемент перечня элементов (ПЭ3) / спецификации."""

    refdes: str  # Позиционное обозначение: "QF1", "R1...R3"
    name: str  # Наименование изделия: "Выключатель автоматический ВА47-29"
    quantity: int = 1  # Количество штук
    value: str = ""  # Номинал или характеристика: "16A", "10 кОм"
    model: str = ""  # Марка / тип
    note: str = ""  # Примечание
    prefix: str = ""  # Буквенный код: "QF", "R"
    num: int = 0  # Номер: 1, 2, 10

    @property
    def full_name(self) -> str:
        """Полное читаемое наименование для таблицы спецификации."""
        parts = [self.name]
        if self.model and self.model not in self.name:
            parts.append(self.model)
        if self.value and self.value not in self.name:
            parts.append(self.value)
        return " ".join(parts).strip()


def parse_refdes(refdes: str) -> Tuple[str, int, int]:
    """
    Разбирает позиционное обозначение на буквенный префикс, номер и подииндекс.
    Примеры: "QF1" -> ("QF", 1, 0), "KM1.2" -> ("KM", 1, 2), "R10" -> ("R", 10, 0).
    """
    match = re.match(r"^([A-Za-z]+)(\d+)(?:\.(\d+))?", refdes.strip())
    if match:
        prefix = match.group(1).upper()
        num = int(match.group(2))
        sub = int(match.group(3)) if match.group(3) else 0
        return prefix, num, sub
    return refdes.strip().upper(), 0, 0


def extract_symbol_name(symbol: Symbol) -> str:
    """Генерирует осмысленное наименование на основе класса и типа аппарата."""
    cls_name = symbol.__class__.__name__

    name_map = {
        "CircuitBreaker": "Выключатель автоматический",
        "SwitchDisconnector": "Выключатель нагрузки (рубильник)",
        "ResidualCurrentDevice": "Устройство защитного отключения (УЗО)",
        "Fuse": "Предохранитель плавкий",
        "BusBar": "Шина распределительная",
        "ContactorCoil": "Контактор электромагнитный",
        "RelayCoil": "Реле промежуточное",
        "NOContact": "Контакт замыкающий (NO)",
        "NCContact": "Контакт размыкающий (NC)",
        "PushButton": "Кнопка управления",
        "PilotLight": "Арматура светосигнальная",
        "Terminal": "Клемма наборная",
        "Resistor": "Резистор постоянный",
        "Capacitor": "Конденсатор",
        "Inductor": "Катушка индуктивности",
        "Diode": "Диод полупроводниковый",
        "BJTTransistor": "Транзистор биполярный",
        "Ground": "Заземлитель",
    }
    base = name_map.get(cls_name, cls_name)
    return base


def extract_bom(symbols: List[Symbol], group_identical: bool = True) -> List[BOMItem]:
    """
    Извлекает все аппараты со схемы и формирует отсортированный перечень элементов по ГОСТ 2.702-2011.
    :param symbols: Список компонентов со схемы.
    :param group_identical: Объединять ли последовательные однотипные элементы в диапазоны (R1...R3).
    :return: Отсортированный список BOMItem.
    """
    raw_items: List[BOMItem] = []

    for sym in symbols:
        # Пропускаем служебные элементы без позиционного обозначения
        if not sym.refdes or sym.refdes.upper() in ("PE", "N", "GND"):
            continue

        # Вспомогательные контакты аппаратов (например KM1.1) обычно относятся к аппарату KM1
        # и не считаются отдельными аппаратами в BOM, если катушка KM1 уже есть
        prefix, num, sub = parse_refdes(sym.refdes)

        item = BOMItem(
            refdes=sym.refdes,
            name=extract_symbol_name(sym),
            quantity=1,
            value=sym.value,
            model=sym.model,
            note=sym.value if sym.value else "",
            prefix=prefix,
            num=num,
        )
        raw_items.append(item)

    # 1. Сортировка по ГОСТ 2.702:
    # Алфавитный порядок латинского кода префикса (C, FU, HL, KM, QF, QS, R, SB, VD, VT, XT)
    # и по возрастанию числового номера (1, 2, ..., 9, 10).
    raw_items.sort(key=lambda x: (x.prefix, x.num, x.refdes))

    if not group_identical or not raw_items:
        return raw_items

    # 2. Группировка последовательных однотипных элементов
    grouped: List[BOMItem] = []
    current = raw_items[0]
    range_start_num = current.num
    range_end_num = current.num

    for next_item in raw_items[1:]:
        # Критерии объединения: один префикс, одно наименование, модель, номинал и номер идет строго подряд (+1)
        is_same_type = (
            next_item.prefix == current.prefix
            and next_item.name == current.name
            and next_item.model == current.model
            and next_item.value == current.value
        )
        is_consecutive = next_item.num == range_end_num + 1

        if is_same_type and is_consecutive:
            current.quantity += 1
            range_end_num = next_item.num
        else:
            # Завершаем текущую группу
            if current.quantity > 1:
                current.refdes = f"{current.prefix}{range_start_num}...{current.prefix}{range_end_num}"
            grouped.append(current)

            current = next_item
            range_start_num = current.num
            range_end_num = current.num

    # Добавляем последний элемент
    if current.quantity > 1:
        current.refdes = f"{current.prefix}{range_start_num}...{current.prefix}{range_end_num}"
    grouped.append(current)

    return grouped

"""Отрисовка таблицы перечня элементов (ПЭ3) по ГОСТ 2.702-2011."""

from __future__ import annotations
from typing import TYPE_CHECKING, List, Optional, Tuple, Union

from eldraw.core.grid import Point
from eldraw.core.layers import StandardLayers
from eldraw.core.styles import StandardStyles
from eldraw.bom.parser import BOMItem

if TYPE_CHECKING:
    from eldraw.core.canvas import SchematicCanvas


def draw_pe3_table(
    canvas: SchematicCanvas,
    items: List[BOMItem],
    at: Optional[Union[Point, Tuple[float, float]]] = None,
) -> Point:
    """
    Вычерчивает таблицу перечня элементов (ПЭ3) по форме 2 ГОСТ 2.702-2011.
    Общая ширина таблицы: 185.0 мм.
    Колонки:
      1. Поз. обозначение: 20 мм
      2. Наименование: 110 мм
      3. Кол.: 10 мм
      4. Примечание: 45 мм
    :param canvas: Холст схемы.
    :param items: Список отсортированных элементов BOMItem.
    :param at: Координаты левого нижнего угла таблицы. Если None — над штампом листа.
    :return: Точка левого нижнего угла таблицы.
    """
    # 1. Определение положения таблицы
    if at is not None:
        p = at if isinstance(at, Point) else Point(float(at[0]), float(at[1]))
        x0, y0 = p.x, p.y
    elif canvas.sheet is not None:
        dims = canvas.sheet.dimensions
        # По ГОСТ 2.702 перечень элементов размещается непосредственно над основной надписью
        x0 = dims.inner_x_max - 185.0
        y0 = dims.inner_y_min + canvas.sheet.title_block_height
    else:
        x0, y0 = 50.0, 50.0

    width = 185.0
    header_h = 10.0
    row_h = 8.0
    rows_count = max(1, len(items))
    total_height = header_h + rows_count * row_h

    layer = StandardLayers.TABLES.name
    lw_thick = 35
    lw_thin = 20

    # 2. Внешний контур таблицы (185 мм x total_height)
    canvas.add_rect(
        (x0, y0),
        (x0 + width, y0 + total_height),
        layer=layer,
        lineweight=lw_thick,
        snap=False,
    )

    # 3. Горизонтальная линия под шапкой
    y_header_bottom = y0 + total_height - header_h
    canvas.add_line(
        (x0, y_header_bottom),
        (x0 + width, y_header_bottom),
        layer=layer,
        lineweight=lw_thick,
        snap=False,
    )

    # 4. Вертикальные разделители колонок:
    # Col 1: 20 мм, Col 2: 110 мм, Col 3: 10 мм, Col 4: 45 мм
    col_x1 = x0 + 20.0
    col_x2 = x0 + 130.0
    col_x3 = x0 + 140.0

    for col_x in [col_x1, col_x2, col_x3]:
        canvas.add_line(
            (col_x, y0),
            (col_x, y0 + total_height),
            layer=layer,
            lineweight=lw_thick,
            snap=False,
        )

    # 5. Горизонтальные строки элементов
    for i in range(1, rows_count):
        y_row = y_header_bottom - i * row_h
        canvas.add_line(
            (x0, y_row),
            (x0 + width, y_row),
            layer=layer,
            lineweight=lw_thin,
            snap=False,
        )

    # 6. Заполнение шапки таблицы
    canvas.add_text("Поз.", (x0 + 4.0, y_header_bottom + 5.5), height=2.5, layer=layer, snap=False)
    canvas.add_text("обознач.", (x0 + 2.0, y_header_bottom + 2.0), height=2.2, layer=layer, snap=False)

    canvas.add_text("Наименование", (x0 + 55.0, y_header_bottom + 3.5), height=3.0, layer=layer, snap=False)

    canvas.add_text("Кол.", (col_x2 + 1.5, y_header_bottom + 3.5), height=2.5, layer=layer, snap=False)

    canvas.add_text("Примечание", (col_x3 + 12.0, y_header_bottom + 3.5), height=2.8, layer=layer, snap=False)

    # 7. Заполнение строк таблицы элементами (сверху вниз)
    for idx, item in enumerate(items):
        y_curr = y_header_bottom - (idx + 1) * row_h
        y_text = y_curr + 2.5

        # Колонка 1: Позиционное обозначение (например "QF1", "R1...R3")
        h_ref = min(2.5, max(1.6, 15.0 / (len(item.refdes) * 0.85))) if item.refdes else 2.5
        canvas.add_text(item.refdes, (x0 + 1.5, y_text), height=h_ref, layer=layer, snap=False)

        # Колонка 2: Полное наименование (ширина 110 мм)
        name_str = item.full_name
        if len(name_str) > 42:
            name_str = name_str[:39] + "..."
        h_name = min(2.3, max(1.6, 95.0 / (len(name_str) * 0.85))) if name_str else 2.3
        canvas.add_text(name_str, (col_x1 + 2.5, y_text), height=h_name, layer=layer, snap=False)

        # Колонка 3: Количество
        canvas.add_text(str(item.quantity), (col_x2 + 3.5, y_text), height=2.5, layer=layer, snap=False)

        # Колонка 4: Примечание
        if item.note:
            note_str = item.note
            if len(note_str) > 18:
                note_str = note_str[:16] + "..."
            h_note = min(2.2, max(1.6, 38.0 / (len(note_str) * 0.85)))
            canvas.add_text(note_str, (col_x3 + 2.5, y_text), height=h_note, layer=layer, snap=False)

    return Point(x0, y0)

"""Аппараты релейной защиты, управления и сигнализации по ГОСТ 2.755 и ГОСТ 2.756."""

from __future__ import annotations
from eldraw.core.grid import Point
from eldraw.core.layers import StandardLayers
from eldraw.symbols.base import Symbol


class ContactorCoil(Symbol):
    """Катушка контактора / электромагнитного пускателя (KM) по ГОСТ 2.756."""

    def __init__(self, refdes: str = "KM1", value: str = "~220V", model: str = "КМИ-10910"):
        super().__init__(block_name="SYM_COIL_KM", refdes=refdes, value=value, model=model)
        self.add_pin("A1", Point(0.0, 10.0), direction=(0.0, 1.0))
        self.add_pin("A2", Point(0.0, -10.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50

        # Прямоугольник 10x5 мм (катушка по ГОСТ 2.756)
        block.add_lwpolyline(
            [(-2.5, -5.0), (2.5, -5.0), (2.5, 5.0), (-2.5, 5.0)],
            close=True,
            dxfattribs={"layer": layer, "lineweight": lw},
        )
        # Выводы катушки: верхний A1 и нижний A2
        block.add_line((0.0, 5.0), (0.0, 10.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((0.0, -5.0), (0.0, -10.0), dxfattribs={"layer": layer, "lineweight": lw})


class RelayCoil(Symbol):
    """Катушка промежуточного реле (KL) или реле времени (KT)."""

    def __init__(self, refdes: str = "KL1", value: str = "=24V", model: str = "РП-21"):
        super().__init__(block_name="SYM_COIL_KL", refdes=refdes, value=value, model=model)
        self.add_pin("13", Point(0.0, 10.0), direction=(0.0, 1.0))
        self.add_pin("14", Point(0.0, -10.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50

        block.add_lwpolyline(
            [(-2.5, -5.0), (2.5, -5.0), (2.5, 5.0), (-2.5, 5.0)],
            close=True,
            dxfattribs={"layer": layer, "lineweight": lw},
        )
        block.add_line((0.0, 5.0), (0.0, 10.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((0.0, -5.0), (0.0, -10.0), dxfattribs={"layer": layer, "lineweight": lw})


class NOContact(Symbol):
    """Нормально-разомкнутый контакт (замыкающий) по ГОСТ 2.755 (1..4 полюса)."""

    def __init__(
        self,
        refdes: str = "KM1.1",
        value: str = "",
        model: str = "",
        poles: int = 1,
        pole_pitch: float = 15.0,
    ):
        self.poles = max(1, min(4, int(poles)))
        self.pole_pitch = float(pole_pitch)
        block_name = f"SYM_CONTACT_NO_{self.poles}P_P{int(self.pole_pitch)}"
        super().__init__(block_name=block_name, refdes=refdes, value=value, model=model)

        if self.poles == 1:
            self.add_pin("1", Point(0.0, 10.0), direction=(0.0, 1.0))
            self.add_pin("2", Point(0.0, -10.0), direction=(0.0, -1.0))
            self.add_pin("in_1", Point(0.0, 10.0), direction=(0.0, 1.0))
            self.add_pin("out_1", Point(0.0, -10.0), direction=(0.0, -1.0))
        else:
            for p in range(self.poles):
                x = p * self.pole_pitch
                p_num = p + 1
                self.add_pin(f"in_{p_num}", Point(x, 10.0), direction=(0.0, 1.0))
                self.add_pin(f"out_{p_num}", Point(x, -10.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50

        for p in range(self.poles):
            x = p * self.pole_pitch
            # Верхний проводник
            block.add_line((x, 10.0), (x, 3.0), dxfattribs={"layer": layer, "lineweight": lw})
            # Неподвижный контакт (засечка)
            block.add_line((x - 1.5, 3.0), (x + 1.5, 3.0), dxfattribs={"layer": layer, "lineweight": lw})
            # Подвижный наклонный контакт
            block.add_line((x, -3.0), (x + 3.5, 4.0), dxfattribs={"layer": layer, "lineweight": lw})
            # Нижний проводник
            block.add_line((x, -3.0), (x, -10.0), dxfattribs={"layer": layer, "lineweight": lw})

        # Механическая связь между полюсами
        if self.poles > 1:
            block.add_line(
                (0.0, 0.0),
                ((self.poles - 1) * self.pole_pitch, 0.0),
                dxfattribs={"layer": StandardLayers.SYMBOLS.name, "lineweight": 25},
            )


class NCContact(Symbol):
    """Нормально-замкнутый контакт (размыкающий) по ГОСТ 2.755."""

    def __init__(self, refdes: str = "KM1.2", value: str = "", model: str = ""):
        super().__init__(block_name="SYM_CONTACT_NC", refdes=refdes, value=value, model=model)
        self.add_pin("1", Point(0.0, 10.0), direction=(0.0, 1.0))
        self.add_pin("2", Point(0.0, -10.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50

        block.add_line((0.0, 10.0), (0.0, 3.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((-1.5, 3.0), (1.5, 3.0), dxfattribs={"layer": layer, "lineweight": lw})
        # Замкнутый наклонный контакт с засечкой
        block.add_line((0.0, -3.0), (0.0, 3.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((-2.0, 0.0), (2.0, 0.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((0.0, -3.0), (0.0, -10.0), dxfattribs={"layer": layer, "lineweight": lw})


class PushButton(Symbol):
    """Кнопка управления (SB) по ГОСТ 2.755."""

    def __init__(self, refdes: str = "SB1", button_type: str = "NO", value: str = "", model: str = ""):
        """
        :param button_type: "NO" (Пуск, замыкающая) или "NC" (Стоп, размыкающая).
        """
        self.button_type = button_type.upper()
        block_name = f"SYM_BTN_{self.button_type}"
        super().__init__(block_name=block_name, refdes=refdes, value=value, model=model)
        self.add_pin("1", Point(0.0, 10.0), direction=(0.0, 1.0))
        self.add_pin("2", Point(0.0, -10.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50

        block.add_line((0.0, 10.0), (0.0, 3.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((-1.5, 3.0), (1.5, 3.0), dxfattribs={"layer": layer, "lineweight": lw})

        if self.button_type == "NO":
            block.add_line((0.0, -3.0), (3.5, 4.0), dxfattribs={"layer": layer, "lineweight": lw})
        else:
            block.add_line((0.0, -3.0), (0.0, 3.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_line((-2.0, 0.0), (2.0, 0.0), dxfattribs={"layer": layer, "lineweight": lw})

        block.add_line((0.0, -3.0), (0.0, -10.0), dxfattribs={"layer": layer, "lineweight": lw})

        # Т-образный толкатель кнопки
        block.add_line((1.5, 0.0), (5.0, 0.0), dxfattribs={"layer": layer, "lineweight": 25})
        block.add_line((5.0, -2.5), (5.0, 2.5), dxfattribs={"layer": layer, "lineweight": lw})


class PilotLight(Symbol):
    """Светосигнальная арматура / индикаторная лампа (HL) по ГОСТ 2.755."""

    def __init__(self, refdes: str = "HL1", value: str = "Красный", model: str = "AL-22"):
        super().__init__(block_name="SYM_LAMP_HL", refdes=refdes, value=value, model=model)
        self.add_pin("1", Point(0.0, 10.0), direction=(0.0, 1.0))
        self.add_pin("2", Point(0.0, -10.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50

        # Окружность диаметром 8 мм (r=4.0)
        block.add_circle((0.0, 0.0), radius=4.0, dxfattribs={"layer": layer, "lineweight": lw})

        # Диагональный крест внутри окружности по ГОСТ
        delta = 2.828  # 4 * sin(45°)
        block.add_line((-delta, -delta), (delta, delta), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((-delta, delta), (delta, -delta), dxfattribs={"layer": layer, "lineweight": lw})

        # Выводы лампы
        block.add_line((0.0, 4.0), (0.0, 10.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((0.0, -4.0), (0.0, -10.0), dxfattribs={"layer": layer, "lineweight": lw})


class Terminal(Symbol):
    """Проходная наборная клемма (XT) по ГОСТ 2.755 (1..10 полюсов)."""

    def __init__(
        self,
        refdes: str = "XT1",
        value: str = "1",
        model: str = "",
        poles: int = 1,
        pole_pitch: float = 15.0,
    ):
        self.poles = max(1, min(10, int(poles)))
        self.pole_pitch = float(pole_pitch)
        block_name = f"SYM_TERMINAL_XT_{self.poles}P_P{int(self.pole_pitch)}"
        super().__init__(block_name=block_name, refdes=refdes, value=value, model=model)

        if self.poles == 1:
            self.add_pin("in", Point(0.0, 5.0), direction=(0.0, 1.0))
            self.add_pin("out", Point(0.0, -5.0), direction=(0.0, -1.0))
            self.add_pin("in_1", Point(0.0, 5.0), direction=(0.0, 1.0))
            self.add_pin("out_1", Point(0.0, -5.0), direction=(0.0, -1.0))
        else:
            for p in range(self.poles):
                x = p * self.pole_pitch
                p_num = p + 1
                self.add_pin(f"in_{p_num}", Point(x, 5.0), direction=(0.0, 1.0))
                self.add_pin(f"out_{p_num}", Point(x, -5.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50

        for p in range(self.poles):
            x = p * self.pole_pitch
            # Кружок клеммы d = 3.0 мм
            block.add_circle((x, 0.0), radius=1.5, dxfattribs={"layer": layer, "lineweight": lw})
            block.add_line((x, 1.5), (x, 5.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_line((x, -1.5), (x, -5.0), dxfattribs={"layer": layer, "lineweight": lw})

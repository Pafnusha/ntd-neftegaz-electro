"""Продвинутые элементы промышленной автоматизации и безопасности (ГОСТ / IEC).

Включает:
- IntermediateRelayCoil (катушка промежуточного реле с таблицей перекрестных ссылок)
- ChangeoverContact (перекидной контакт 11-12-14)
- SafetyRelay (реле безопасности Schneider XPS / Pilz PNOZ)
- PowerSupply24V (импульсный блок питания 24VDC)
- MultiTierTerminal (многоуровневая клеммная колодка с разделителем Шкаф/Поле)
"""

from __future__ import annotations
from typing import Dict, List, Optional, Tuple, Union

from eldraw.core.grid import Point
from eldraw.core.layers import StandardLayers
from eldraw.symbols.base import Symbol


class IntermediateRelayCoil(Symbol):
    """
    Катушка промежуточного реле (Finder 40.52 / Phoenix Contact / РПИ).
    
    Содержит:
    - Выводы катушки A1 (сверху) и A2 (снизу);
    - Встроенную под катушкой таблицу перекрестных ссылок на задействованные контакты
      (Contact Cross-Reference Table) с указанием номеров листов и колонок (Sh.Col).
    """

    def __init__(
        self,
        refdes: str = "KA1",
        value: str = "=24V",
        model: str = "Finder 40.52",
        contacts_crossref: Optional[List[Tuple[str, str]]] = None,
    ):
        """
        :param contacts_crossref: Список пар (тип контакта, целевой лист.колонка),
                                  например: [("NO", "8222.4"), ("NC", "8222.5")]
        """
        self.crossrefs = contacts_crossref or []
        super().__init__(block_name=f"SYM_INTERMEDIATE_RELAY_{refdes}", refdes=refdes, value=value, model=model)
        self.add_pin("A1", Point(0.0, 10.0), direction=(0.0, 1.0))
        self.add_pin("A2", Point(0.0, -10.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        table_layer = StandardLayers.TABLES.name
        text_layer = StandardLayers.TEXT.name
        lw = 50

        # Прямоугольник катушки 5x10 мм
        block.add_lwpolyline(
            [(-2.5, -5.0), (2.5, -5.0), (2.5, 5.0), (-2.5, 5.0)],
            close=True,
            dxfattribs={"layer": layer, "lineweight": lw},
        )
        # Выводы A1 и A2
        block.add_line((0.0, 5.0), (0.0, 10.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((0.0, -5.0), (0.0, -10.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_text("A1", dxfattribs={"layer": text_layer, "height": 1.4, "style": "GOST_B"}).set_placement((0.8, 6.0))
        block.add_text("A2", dxfattribs={"layer": text_layer, "height": 1.4, "style": "GOST_B"}).set_placement((0.8, -8.0))

        # Таблица перекрестных ссылок под катушкой справа от провода A2 (x >= 4.0, y < -12)
        if self.crossrefs:
            y_curr = -14.0
            for contact_type, location in self.crossrefs:
                # Маленький символ контакта (x from 4.0 to 10.0)
                if contact_type.upper() == "NO":
                    block.add_line((4.0, y_curr), (6.0, y_curr), dxfattribs={"layer": layer, "lineweight": 25})
                    block.add_line((6.0, y_curr), (8.5, y_curr + 2.0), dxfattribs={"layer": layer, "lineweight": 25})
                    block.add_line((8.5, y_curr), (10.0, y_curr), dxfattribs={"layer": layer, "lineweight": 25})
                elif contact_type.upper() == "NC":
                    block.add_line((4.0, y_curr), (6.0, y_curr), dxfattribs={"layer": layer, "lineweight": 25})
                    block.add_line((6.0, y_curr + 2.0), (8.5, y_curr), dxfattribs={"layer": layer, "lineweight": 25})
                    block.add_line((8.5, y_curr), (10.0, y_curr), dxfattribs={"layer": layer, "lineweight": 25})
                else:  # CO / Changeover
                    block.add_line((4.0, y_curr), (7.0, y_curr), dxfattribs={"layer": layer, "lineweight": 25})
                    block.add_line((7.0, y_curr), (9.5, y_curr + 2.0), dxfattribs={"layer": layer, "lineweight": 25})

                # Текст ссылки (напр. "8222.4")
                block.add_text(
                    location,
                    dxfattribs={"layer": text_layer, "height": 1.6, "style": "GOST_B"},
                ).set_placement((11.5, y_curr - 0.8))
                y_curr -= 4.0

    def get_bounds(self) -> Tuple[float, float, float, float]:
        min_y = -14.0 - len(self.crossrefs) * 4.0 if self.crossrefs else -10.0
        return (-3.0, min_y, 25.0, 10.0)


class ChangeoverContact(Symbol):
    """
    Перекидной контакт (Changeover / CO / SPDT) по ГОСТ 2.755 / IEC 60617.
    
    Выводы:
    - 11 (или 21): общий вход (снизу);
    - 12 (или 22): нормально-замкнутый контакт NC (сверху слева);
    - 14 (или 24): нормально-разомкнутый контакт NO (сверху справа).
    """

    def __init__(
        self,
        refdes: str = "KA1.1",
        value: str = "",
        model: str = "",
        contact_group: int = 1,
    ):
        self.group = contact_group
        c_com = f"{contact_group}1"
        c_nc = f"{contact_group}2"
        c_no = f"{contact_group}4"
        block_name = f"SYM_CONTACT_CO_G{contact_group}"
        super().__init__(block_name=block_name, refdes=refdes, value=value, model=model)

        self.add_pin(c_com, Point(0.0, -10.0), direction=(0.0, -1.0))
        self.add_pin(c_nc, Point(-5.0, 10.0), direction=(0.0, 1.0))
        self.add_pin(c_no, Point(5.0, 10.0), direction=(0.0, 1.0))
        self.add_pin("com", Point(0.0, -10.0), direction=(0.0, -1.0))
        self.add_pin("nc", Point(-5.0, 10.0), direction=(0.0, 1.0))
        self.add_pin("no", Point(5.0, 10.0), direction=(0.0, 1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        text_layer = StandardLayers.TEXT.name
        lw = 50

        # Нижний общий вывод (y: -10 -> -3)
        block.add_line((0.0, -10.0), (0.0, -3.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_text(f"{self.group}1", dxfattribs={"layer": text_layer, "height": 1.4, "style": "GOST_B"}).set_placement((1.0, -8.0))

        # Левый вывод NC (y: 10 -> 3, засечка на x=-5)
        block.add_line((-5.0, 10.0), (-5.0, 3.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((-6.0, 3.0), (-4.0, 3.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_text(f"{self.group}2", dxfattribs={"layer": text_layer, "height": 1.4, "style": "GOST_B"}).set_placement((-9.0, 6.0))

        # Правый вывод NO (y: 10 -> 3, засечка на x=5)
        block.add_line((5.0, 10.0), (5.0, 3.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_text(f"{self.group}4", dxfattribs={"layer": text_layer, "height": 1.4, "style": "GOST_B"}).set_placement((6.0, 6.0))

        # Подвижный нож от (0, -3) к замкнутому левому контакту (-5, 3)
        block.add_line((0.0, -3.0), (-4.5, 3.0), dxfattribs={"layer": layer, "lineweight": lw})

    def get_bounds(self) -> Tuple[float, float, float, float]:
        return (-9.0, -10.0, 8.0, 10.0)


class SafetyRelay(Symbol):
    """
    Модуль реле безопасности (Safety Relay, напр. Schneider XPSUAF13AP / Pilz PNOZ).
    
    Выводы:
    - Питание: A1 (+24V), A2 (0V);
    - Входы аварийного останова: S11-S12 (Канал 1), S21-S22 (Канал 2);
    - Цепь запуска/сброса/обратной связи: Y1, Y2, Z1;
    - Выходные контакты безопасности: 13-14, 23-24, 33-34 (NO).
    """

    def __init__(
        self,
        refdes: str = "KA_SAFE",
        value: str = "XPSUAF13AP",
        model: str = "Schneider XPS",
    ):
        super().__init__(block_name="SYM_SAFETY_RELAY_XPS", refdes=refdes, value=value, model=model)

        # Выводы сверху
        self.add_pin("A1", Point(-25.0, 20.0), direction=(0.0, 1.0))
        self.add_pin("Y1", Point(-10.0, 20.0), direction=(0.0, 1.0))
        self.add_pin("Y2", Point(0.0, 20.0), direction=(0.0, 1.0))
        self.add_pin("Z1", Point(10.0, 20.0), direction=(0.0, 1.0))
        self.add_pin("13", Point(25.0, 20.0), direction=(0.0, 1.0))
        self.add_pin("23", Point(35.0, 20.0), direction=(0.0, 1.0))
        self.add_pin("33", Point(45.0, 20.0), direction=(0.0, 1.0))

        # Выводы снизу
        self.add_pin("A2", Point(-25.0, -20.0), direction=(0.0, -1.0))
        self.add_pin("S11", Point(-15.0, -20.0), direction=(0.0, -1.0))
        self.add_pin("S12", Point(-5.0, -20.0), direction=(0.0, -1.0))
        self.add_pin("S21", Point(5.0, -20.0), direction=(0.0, -1.0))
        self.add_pin("S22", Point(15.0, -20.0), direction=(0.0, -1.0))
        self.add_pin("14", Point(25.0, -20.0), direction=(0.0, -1.0))
        self.add_pin("24", Point(35.0, -20.0), direction=(0.0, -1.0))
        self.add_pin("34", Point(45.0, -20.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        text_layer = StandardLayers.TEXT.name
        lw = 50

        # Корпус модуля: x in [-30, 50], y in [-15, 15]
        block.add_lwpolyline(
            [(-30.0, -15.0), (50.0, -15.0), (50.0, 15.0), (-30.0, 15.0)],
            close=True,
            dxfattribs={"layer": layer, "lineweight": lw},
        )

        # Выводы сверху (20 -> 15)
        top_pins = [(-25.0, "A1"), (-10.0, "Y1"), (0.0, "Y2"), (10.0, "Z1"), (25.0, "13"), (35.0, "23"), (45.0, "33")]
        for x, lbl in top_pins:
            block.add_line((x, 15.0), (x, 20.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_text(lbl, dxfattribs={"layer": text_layer, "height": 1.6, "style": "GOST_B"}).set_placement((x - 1.5, 10.5))

        # Выводы снизу (-15 -> -20)
        bot_pins = [(-25.0, "A2"), (-15.0, "S11"), (-5.0, "S12"), (5.0, "S21"), (15.0, "S22"), (25.0, "14"), (35.0, "24"), (45.0, "34")]
        for x, lbl in bot_pins:
            block.add_line((x, -15.0), (x, -20.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_text(lbl, dxfattribs={"layer": text_layer, "height": 1.6, "style": "GOST_B"}).set_placement((x - 2.0, -13.0))

        # Внутренний блок Logic & K1/K2
        block.add_lwpolyline(
            [(-18.0, -8.0), (3.0, -8.0), (3.0, 8.0), (-18.0, 8.0)],
            close=True,
            dxfattribs={"layer": layer, "lineweight": 25},
        )
        block.add_text("Logic", dxfattribs={"layer": text_layer, "height": 2.2, "style": "GOST_B"}).set_placement((-12.0, -1.0))

        # Внутренние силовые контакты K1/K2 (NO) между 13-14, 23-24, 33-34
        for x in [25.0, 35.0, 45.0]:
            block.add_line((x, 8.0), (x, 3.0), dxfattribs={"layer": layer, "lineweight": 25})
            block.add_line((x, -8.0), (x, -3.0), dxfattribs={"layer": layer, "lineweight": 25})
            block.add_line((x, -3.0), (x + 2.0, 3.0), dxfattribs={"layer": layer, "lineweight": 25})

        block.add_text("SAFETY RELAY", dxfattribs={"layer": text_layer, "height": 2.0, "style": "GOST_B"}).set_placement((-25.0, 1.0))

    def get_bounds(self) -> Tuple[float, float, float, float]:
        return (-30.0, -20.0, 50.0, 20.0)


class PowerSupply24V(Symbol):
    """Импульсный промышленный блок питания ~230V / 24VDC (Mean Well / Weidmüller / Phoenix)."""

    def __init__(self, refdes: str = "G1", value: str = "24V 10A", model: str = "PRO MAX 240W"):
        super().__init__(block_name="SYM_POWER_SUPPLY_24V", refdes=refdes, value=value, model=model)
        # Вход ~230В сверху
        self.add_pin("L", Point(-10.0, 15.0), direction=(0.0, 1.0))
        self.add_pin("N", Point(0.0, 15.0), direction=(0.0, 1.0))
        self.add_pin("PE", Point(10.0, 15.0), direction=(0.0, 1.0))
        # Выход =24В снизу
        self.add_pin("+", Point(-5.0, -15.0), direction=(0.0, -1.0))
        self.add_pin("-", Point(5.0, -15.0), direction=(0.0, -1.0))
        self.add_pin("24V", Point(-5.0, -15.0), direction=(0.0, -1.0))
        self.add_pin("0V", Point(5.0, -15.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        text_layer = StandardLayers.TEXT.name
        lw = 50

        # Корпус 30x20 мм
        block.add_lwpolyline(
            [(-15.0, -10.0), (15.0, -10.0), (15.0, 10.0), (-15.0, 10.0)],
            close=True,
            dxfattribs={"layer": layer, "lineweight": lw},
        )

        # Выводы сверху (L, N, PE)
        for x, lbl in [(-10.0, "L"), (0.0, "N"), (10.0, "PE")]:
            block.add_line((x, 10.0), (x, 15.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_text(lbl, dxfattribs={"layer": text_layer, "height": 1.6, "style": "GOST_B"}).set_placement((x - 1.5, 6.0))

        # Выводы снизу (+, -)
        for x, lbl in [(-5.0, "+"), (5.0, "-")]:
            block.add_line((x, -10.0), (x, -15.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_text(lbl, dxfattribs={"layer": text_layer, "height": 2.0, "style": "GOST_B"}).set_placement((x - 1.0, -8.0))

        # Разделительная диагональ (AC -> DC)
        block.add_line((-15.0, -10.0), (15.0, 10.0), dxfattribs={"layer": layer, "lineweight": 25})
        block.add_text("~", dxfattribs={"layer": text_layer, "height": 2.5, "style": "GOST_B"}).set_placement((-8.0, 2.0))
        block.add_text("=", dxfattribs={"layer": text_layer, "height": 2.5, "style": "GOST_B"}).set_placement((4.0, -6.0))

    def get_bounds(self) -> Tuple[float, float, float, float]:
        return (-15.0, -15.0, 15.0, 15.0)


class MultiTierTerminal(Symbol):
    """
    Многоуровневая клемма (напр. 3-уровневая L/N/PE клемма Phoenix Contact / WAGO)
    с разделителем границ монтажных зон (=PANEL шкаф / =EXT поле).
    """

    def __init__(
        self,
        refdes: str = "XT1",
        value: str = "1",
        model: str = "PTI 2.5-PE/L/N",
        levels: int = 3,
    ):
        self.levels = max(1, min(4, int(levels)))
        super().__init__(block_name=f"SYM_MULTITIER_TERM_{self.levels}L", refdes=refdes, value=value, model=model)

        # Выводы: сторона шкафа (сверху/слева) и сторона поля (снизу/справа)
        for lvl in range(self.levels):
            y_offset = (lvl - (self.levels - 1) / 2.0) * 8.0
            self.add_pin(f"in_{lvl+1}", Point(-5.0, y_offset), direction=(-1.0, 0.0))
            self.add_pin(f"out_{lvl+1}", Point(5.0, y_offset), direction=(1.0, 0.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        text_layer = StandardLayers.TEXT.name
        lw = 50

        # Кружки клемм на каждом уровне
        for lvl in range(self.levels):
            y = (lvl - (self.levels - 1) / 2.0) * 8.0
            block.add_circle((0.0, y), radius=1.5, dxfattribs={"layer": layer, "lineweight": lw})
            block.add_line((-5.0, y), (-1.5, y), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_line((1.5, y), (5.0, y), dxfattribs={"layer": layer, "lineweight": lw})

        # Вертикальная пунктирная линия границы шкаф/поле (Field boundary)
        y_max = (self.levels - 1) / 2.0 * 8.0 + 5.0
        y_min = -(self.levels - 1) / 2.0 * 8.0 - 5.0
        block.add_line(
            (0.0, y_min),
            (0.0, y_max),
            dxfattribs={"layer": layer, "linetype": "DASHED", "lineweight": 25},
        )

    def get_bounds(self) -> Tuple[float, float, float, float]:
        span = (self.levels - 1) / 2.0 * 8.0 + 5.0
        return (-5.0, -span, 5.0, span)


class SolenoidValve(Symbol):
    """
    Электромагнитный клапан / соленоид пневмораспределителя (YV)
    по ГОСТ 2.784 / ГОСТ 2.756.
    """

    def __init__(self, refdes: str = "YV1", value: str = "=24V", model: str = "Festo CPE14"):
        super().__init__(block_name="SYM_SOLENOID_VALVE", refdes=refdes, value=value, model=model)
        self.add_pin("1", Point(0.0, 10.0), direction=(0.0, 1.0))
        self.add_pin("2", Point(0.0, -10.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50

        # Прямоугольник привода 5x10 мм
        block.add_lwpolyline(
            [(-2.5, -5.0), (2.5, -5.0), (2.5, 5.0), (-2.5, 5.0)],
            close=True,
            dxfattribs={"layer": layer, "lineweight": lw},
        )
        # Диагональная линия соленоида
        block.add_line((-2.5, -5.0), (2.5, 5.0), dxfattribs={"layer": layer, "lineweight": 25})

        # Выводы: верхний 1 и нижний 2
        block.add_line((0.0, 5.0), (0.0, 10.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((0.0, -5.0), (0.0, -10.0), dxfattribs={"layer": layer, "lineweight": lw})

    def get_bounds(self) -> Tuple[float, float, float, float]:
        return (-3.0, -10.0, 3.0, 10.0)


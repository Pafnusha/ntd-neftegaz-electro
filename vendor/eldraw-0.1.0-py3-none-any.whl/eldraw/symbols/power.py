"""Силовые коммутационные и защитные аппараты по ГОСТ 2.755-87 и ГОСТ 2.702-2011."""

from __future__ import annotations
from typing import List, Tuple
from eldraw.core.grid import Point
from eldraw.core.layers import StandardLayers
from eldraw.symbols.base import Symbol


class CircuitBreaker(Symbol):
    """
    Автоматический выключатель (QF) по ГОСТ 2.755-87.
    Содержит контактную группу с тепловым и электромагнитным расцепителями.
    Поддерживает 1, 2, 3 и 4 полюса.
    """

    def __init__(
        self,
        refdes: str = "QF1",
        value: str = "16A",
        model: str = "ВА47-29",
        poles: int = 1,
        pole_pitch: float = 15.0,
    ):
        """
        :param poles: Количество полюсов (1, 2, 3, 4).
        :param pole_pitch: Шаг между полюсами в мм (кратно 5 мм, по умолчанию 15.0 мм).
        """
        self.poles = max(1, min(4, int(poles)))
        self.pole_pitch = float(pole_pitch)

        block_name = f"SYM_QF_{self.poles}P_PITCH{int(self.pole_pitch)}"
        super().__init__(block_name=block_name, refdes=refdes, value=value, model=model)

        # Регистрация выводов
        for p in range(self.poles):
            x_offset = p * self.pole_pitch
            # Выводы: сверху (in) и снизу (out)
            p_num = p + 1
            self.add_pin(f"in_{p_num}", Point(x_offset, 10.0), direction=(0.0, 1.0))
            self.add_pin(f"out_{p_num}", Point(x_offset, -10.0), direction=(0.0, -1.0))

        # Псевдонимы для однополюсного аппарата
        if self.poles == 1:
            self.pins["in"] = self.pins["in_1"]
            self.pins["out"] = self.pins["out_1"]

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50

        for p in range(self.poles):
            x = p * self.pole_pitch

            # 1. Входной верхний проводник: от (x, 10) до (x, 4)
            block.add_line((x, 10.0), (x, 4.0), dxfattribs={"layer": layer, "lineweight": lw})

            # 2. Неподвижный контакт (засечка)
            block.add_line((x - 1.5, 4.0), (x + 1.5, 4.0), dxfattribs={"layer": layer, "lineweight": lw})

            # 3. Подвижный контакт (наклонный отрезок)
            block.add_line((x, -4.0), (x + 3.5, 4.0), dxfattribs={"layer": layer, "lineweight": lw})

            # 4. Выходной нижний проводник: от (x, -4) до (x, -10)
            block.add_line((x, -4.0), (x, -10.0), dxfattribs={"layer": layer, "lineweight": lw})

            # 5. Символ теплового расцепителя (прямоугольник 3x2 мм на линии контакта)
            block.add_lwpolyline(
                [(x + 0.5, -1.0), (x + 3.5, -1.0), (x + 3.5, 1.0), (x + 0.5, 1.0)],
                close=True,
                dxfattribs={"layer": layer, "lineweight": lw},
            )

            # 6. Символ электромагнитного расцепителя (полукруг/разомкнутый контур)
            block.add_arc((x + 2.0, 2.5), radius=1.2, start_angle=0, end_angle=180, dxfattribs={"layer": layer, "lineweight": lw})

        # Если несколько полюсов — механическая связь (штриховая линия)
        if self.poles > 1:
            x_start = 0.0
            x_end = (self.poles - 1) * self.pole_pitch
            block.add_line(
                (x_start, 0.0),
                (x_end, 0.0),
                dxfattribs={"layer": layer, "linetype": "DASHED", "lineweight": 25},
            )


class SwitchDisconnector(Symbol):
    """Выключатель нагрузки / рубильник (QS) по ГОСТ 2.755-87."""

    def __init__(self, refdes: str = "QS1", value: str = "40A", model: str = "ВН-32", poles: int = 1):
        self.poles = max(1, min(4, int(poles)))
        block_name = f"SYM_QS_{self.poles}P"
        super().__init__(block_name=block_name, refdes=refdes, value=value, model=model)

        for p in range(self.poles):
            x = p * 15.0
            p_num = p + 1
            self.add_pin(f"in_{p_num}", Point(x, 10.0), direction=(0.0, 1.0))
            self.add_pin(f"out_{p_num}", Point(x, -10.0), direction=(0.0, -1.0))

        if self.poles == 1:
            self.pins["in"] = self.pins["in_1"]
            self.pins["out"] = self.pins["out_1"]

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50

        for p in range(self.poles):
            x = p * 15.0
            # Верхний проводник
            block.add_line((x, 10.0), (x, 4.0), dxfattribs={"layer": layer, "lineweight": lw})
            # Поперечная черта разъединителя на неподвижном контакте
            block.add_line((x - 2.5, 4.0), (x + 2.5, 4.0), dxfattribs={"layer": layer, "lineweight": lw})
            # Подвижный контакт
            block.add_line((x, -4.0), (x + 3.5, 4.0), dxfattribs={"layer": layer, "lineweight": lw})
            # Нижний проводник
            block.add_line((x, -4.0), (x, -10.0), dxfattribs={"layer": layer, "lineweight": lw})

        if self.poles > 1:
            block.add_line(
                (0.0, 0.0),
                ((self.poles - 1) * 15.0, 0.0),
                dxfattribs={"layer": layer, "linetype": "DASHED", "lineweight": 25},
            )


class ResidualCurrentDevice(Symbol):
    """Устройство защитного отключения / УЗО (QFD) по ГОСТ 2.755."""

    def __init__(self, refdes: str = "QFD1", value: str = "25A 30mA", model: str = "ВДТ ВД1-63", poles: int = 2):
        self.poles = max(1, min(4, int(poles)))
        block_name = f"SYM_QFD_{self.poles}P"
        super().__init__(block_name=block_name, refdes=refdes, value=value, model=model)

        if self.poles == 1:
            self.add_pin("in", Point(0.0, 15.0), direction=(0.0, 1.0))
            self.add_pin("out", Point(0.0, -15.0), direction=(0.0, -1.0))
            self.add_pin("in_1", Point(0.0, 15.0), direction=(0.0, 1.0))
            self.add_pin("out_1", Point(0.0, -15.0), direction=(0.0, -1.0))
        else:
            for p in range(self.poles):
                x = p * 15.0
                p_num = p + 1
                self.add_pin(f"in_{p_num}", Point(x, 15.0), direction=(0.0, 1.0))
                self.add_pin(f"out_{p_num}", Point(x, -15.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50

        # Контакты выключателя
        for p in range(self.poles):
            x = p * 15.0
            block.add_line((x, 15.0), (x, 4.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_line((x - 1.5, 4.0), (x + 1.5, 4.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_line((x, -4.0), (x + 3.5, 4.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_line((x, -4.0), (x, -15.0), dxfattribs={"layer": layer, "lineweight": lw})

        # Дифференциальный трансформатор тока (овал вокруг проводников)
        if self.poles == 1:
            block.add_ellipse(
                center=(0.0, -9.0),
                major_axis=(4.0, 0.0),
                ratio=0.7,
                dxfattribs={"layer": layer, "lineweight": lw},
            )
        else:
            center_x = (self.poles - 1) * 15.0 / 2.0
            block.add_ellipse(
                center=(center_x, -9.0),
                major_axis=((self.poles * 15.0) / 2.0 + 3.0, 0.0),
                ratio=0.4,
                dxfattribs={"layer": layer, "lineweight": lw},
            )


class Fuse(Symbol):
    """Плавкий предохранитель (FU) по ГОСТ 2.728."""

    def __init__(self, refdes: str = "FU1", value: str = "10A", model: str = ""):
        super().__init__(block_name="SYM_FUSE", refdes=refdes, value=value, model=model)
        self.add_pin("in", Point(0.0, 10.0), direction=(0.0, 1.0))
        self.add_pin("out", Point(0.0, -10.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50

        # Прямоугольник 10x4 мм по ГОСТ 2.728
        block.add_lwpolyline(
            [(-2.0, -5.0), (2.0, -5.0), (2.0, 5.0), (-2.0, 5.0)],
            close=True,
            dxfattribs={"layer": layer, "lineweight": lw},
        )
        # Осевая линия насквозь через предохранитель
        block.add_line((0.0, 10.0), (0.0, -10.0), dxfattribs={"layer": layer, "lineweight": lw})


class BusBar(Symbol):
    """Сборная шина распределения (L, N, PE) с настраиваемой длиной и портами."""

    default_label_pos: str = "top"

    def __init__(
        self,
        refdes: str = "PE",
        length: float = 60.0,
        num_taps: int = 5,
        tap_pitch: float = 10.0,
        value: str = "",
        model: str = "",
    ):
        self.length = float(length)
        self.num_taps = int(num_taps)
        self.tap_pitch = float(tap_pitch)

        block_name = f"SYM_BUSBAR_L{int(self.length)}_N{self.num_taps}"
        super().__init__(block_name=block_name, refdes=refdes, value=value, model=model)

        # Главные вводы шины по краям
        self.add_pin("main_left", Point(0.0, 0.0), direction=(-1.0, 0.0))
        self.add_pin("main_right", Point(self.length, 0.0), direction=(1.0, 0.0))

        # Отводы шины
        for i in range(self.num_taps):
            x = 10.0 + i * self.tap_pitch
            if x <= self.length - 5.0:
                self.add_pin(f"tap_{i+1}", Point(x, 0.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.WIRES.name
        # Массивная шина lineweight = 100 (1.00 мм)
        block.add_line((0.0, 0.0), (self.length, 0.0), dxfattribs={"layer": layer, "lineweight": 100})

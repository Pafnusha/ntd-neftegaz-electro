"""Базовые классы для условно-графических обозначений (УГО) и точек подключения."""

from __future__ import annotations
import math
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Dict, List, Optional, Tuple, Union

from eldraw.core.grid import Point
from eldraw.core.layers import StandardLayers
from eldraw.core.styles import StandardStyles

if TYPE_CHECKING:
    from eldraw.core.canvas import SchematicCanvas
    from ezdxf.document import Drawing


@dataclass(frozen=True)
class Pin:
    """Точка подключения (вывод/терминал) компонента."""

    name: str  # Имя вывода (например: "in", "out", "A1", "A2", "1", "2")
    local_pos: Point  # Координаты относительно базовой точки блока (0, 0)
    direction: Tuple[float, float] = (0.0, 1.0)  # Вектор направления подключения (нормаль)

    def get_world_pos(self, origin: Point, rotation: float = 0.0) -> Point:
        """
        Вычисляет абсолютные мировые координаты вывода на чертеже
        с учётом точки размещения компонента и угла поворота.
        """
        rad = math.radians(rotation)
        cos_a = math.cos(rad)
        sin_a = math.sin(rad)

        rx = self.local_pos.x * cos_a - self.local_pos.y * sin_a
        ry = self.local_pos.x * sin_a + self.local_pos.y * cos_a

        return Point(round(origin.x + rx, 4), round(origin.y + ry, 4))


class Symbol:
    """Базовый класс условно-графического обозначения (УГО) в виде блока DXF."""

    default_label_pos: Optional[str] = None

    def __init__(
        self,
        block_name: str,
        refdes: str,
        value: str = "",
        model: str = "",
    ):
        """
        :param block_name: Уникальное имя блока в секции BLOCKS файла DXF.
        :param refdes: Позиционное обозначение (ГОСТ 2.710: QF1, KM1, R1).
        :param value: Номинал или технические параметры (16A, 10 кОм).
        :param model: Марка изделия или артикул (ВА47-29).
        """
        self.block_name = block_name
        self.refdes = refdes
        self.value = value
        self.model = model

        self.pins: Dict[str, Pin] = {}
        self.position: Optional[Point] = None
        self.rotation: float = 0.0
        self.placed: bool = False

    def add_pin(self, name: str, local_pos: Union[Point, Tuple[float, float]], direction: Tuple[float, float] = (0.0, 1.0)) -> Pin:
        """Регистрирует вывод компонента."""
        pt = local_pos if isinstance(local_pos, Point) else Point(float(local_pos[0]), float(local_pos[1]))
        pin = Pin(name=name, local_pos=pt, direction=direction)
        self.pins[name] = pin
        return pin

    def pin(self, name: str) -> Point:
        """
        Возвращает абсолютные мировые координаты вывода на чертеже.
        Компонент должен быть предварительно размещен на холсте.
        """
        if not self.placed or self.position is None:
            raise RuntimeError(f"Компонент {self.refdes} еще не размещен на холсте (вызовите place() или add_symbol()).")
        if name not in self.pins:
            available = ", ".join(f"'{k}'" for k in self.pins.keys())
            raise KeyError(f"Вывод '{name}' не найден у {self.refdes}. Доступные выводы: [{available}]")

        return self.pins[name].get_world_pos(self.position, self.rotation)

    def build_geometry(self, block) -> None:
        """
        Переопределяется в подклассах для вычерчивания геометрии символа внутри блока.
        Геометрия строится относительно базовой точки (0, 0).
        """
        raise NotImplementedError("Подкласс должен реализовать метод build_geometry().")

    def register_block(self, doc: Drawing) -> None:
        """Создает определение блока в секции BLOCKS, если оно еще не создано."""
        if self.block_name not in doc.blocks:
            block = doc.blocks.new(name=self.block_name)
            self.build_geometry(block)

    def get_local_bounds(self) -> Tuple[float, float, float, float]:
        """
        Возвращает локальный габаритный прямоугольник символа (x_min, y_min, x_max, y_max)
        относительно базовой точки (0, 0).
        """
        if self.pins:
            min_x = min(p.local_pos.x for p in self.pins.values()) - 2.5
            max_x = max(p.local_pos.x for p in self.pins.values()) + 2.5
            min_y = min(p.local_pos.y for p in self.pins.values()) - 2.0
            max_y = max(p.local_pos.y for p in self.pins.values()) + 2.0
            return (min_x, min_y, max_x, max_y)
        return (-5.0, -5.0, 5.0, 5.0)

    def get_world_bounds(self) -> Tuple[float, float, float, float]:
        """Возвращает габаритный прямоугольник символа в мировых координатах чертежа."""
        if self.position is None:
            return (0.0, 0.0, 0.0, 0.0)

        lx_min, ly_min, lx_max, ly_max = self.get_local_bounds()
        rad = math.radians(self.rotation)
        cos_a = math.cos(rad)
        sin_a = math.sin(rad)

        corners = [
            (lx_min, ly_min),
            (lx_max, ly_min),
            (lx_max, ly_max),
            (lx_min, ly_max),
        ]
        wx = [self.position.x + (cx * cos_a - cy * sin_a) for cx, cy in corners]
        wy = [self.position.y + (cx * sin_a + cy * cos_a) for cx, cy in corners]
        return (min(wx), min(wy), max(wx), max(wy))

    def place(
        self,
        canvas: SchematicCanvas,
        at: Union[Point, Tuple[float, float]],
        rotation: float = 0.0,
        label_pos: str = "right",
        label_offset: Optional[Tuple[float, float]] = None,
        snap: bool = True,
    ) -> Symbol:
        """
        Размещает экземпляр символа на холсте схемы.
        :param canvas: Холст схемы.
        :param at: Точка вставки.
        :param rotation: Угол поворота в градусах (0, 90, 180, 270).
        :param label_pos: Расположение подписи относительно компонента ("right", "left", "top", "bottom").
        :param label_offset: Пользовательское смещение подписи (dx, dy). Если задано, label_pos игнорируется.
        :param snap: Привязывать ли точку вставки к модульной сетке.
        """
        pos = canvas._to_point(at, snap=snap)
        self.position = pos
        self.rotation = float(rotation)
        self.placed = True
        if label_pos is not None:
            self.label_pos = label_pos.lower()
        elif getattr(self, "default_label_pos", None) is not None:
            self.label_pos = self.default_label_pos.lower()
        else:
            self.label_pos = None
        self.label_offset = label_offset

        self._canvas = canvas

        # Регистрация блока в DXF документе
        self.register_block(canvas.doc)

        # Вставка ссылки на блок (INSERT)
        canvas.msp.add_blockref(
            name=self.block_name,
            insert=pos.to_tuple(),
            dxfattribs={
                "rotation": self.rotation,
                "layer": StandardLayers.SYMBOLS.name,
            },
        )

        # Вывод видимых подписей (позиционное обозначение и номинал)
        self.draw_labels(canvas)

        return self

    def rebuild(self, doc=None) -> None:
        """Перестраивает геометрию блока символа в DXF документе."""
        if doc is None and hasattr(self, "_canvas") and self._canvas is not None:
            doc = self._canvas.doc
        if doc is not None and self.block_name in doc.blocks:
            blk = doc.blocks[self.block_name]
            for e in list(blk):
                blk.delete_entity(e)
            self.build_geometry(blk)

    def draw_labels(self, canvas: SchematicCanvas) -> None:
        """
        Отрисовывает позиционное обозначение и номинал рядом с компонентом
        без наложения на тело символа или точки выводов.
        """
        if not getattr(self, "show_labels", True):
            return

        if self.position is None or not (self.refdes or self.value):
            return

        wx_min, wy_min, wx_max, wy_max = self.get_world_bounds()
        wx_center = (wx_min + wx_max) / 2.0
        wy_center = (wy_min + wy_max) / 2.0

        if self.label_offset is not None:
            dx, dy = self.label_offset
            ref_pos = self.position.offset(dx, dy)
            val_pos = self.position.offset(dx, dy - 4.5)
            ref_align = "LEFT"
            val_align = "LEFT"
        else:
            mode = getattr(self, "label_pos", None)
            if mode is None:
                # Определяем ориентацию по направлению выводов (ГОСТ 2.702-2011)
                has_vertical_pins = False
                has_horizontal_pins = False
                for p in self.pins.values():
                    rad = math.radians(self.rotation)
                    dx = p.direction[0] * math.cos(rad) - p.direction[1] * math.sin(rad)
                    dy = p.direction[0] * math.sin(rad) + p.direction[1] * math.cos(rad)
                    if abs(dy) > abs(dx) + 0.1:
                        has_vertical_pins = True
                    elif abs(dx) > abs(dy) + 0.1:
                        has_horizontal_pins = True

                if has_vertical_pins and not has_horizontal_pins:
                    # Вертикальное подключение (сверху/снизу) -> подпись справа
                    mode = "right"
                elif has_horizontal_pins and not has_vertical_pins:
                    # Горизонтальное подключение (слева/справа) -> подпись сверху
                    mode = "top"
                else:
                    sym_w = wx_max - wx_min
                    sym_h = wy_max - wy_min
                    mode = "top" if sym_w > sym_h else "right"

            mode = mode.lower()
            if mode == "top":
                ref_pos = Point(wx_center, wy_max + (7.5 if self.value else 2.5))
                val_pos = Point(wx_center, wy_max + 2.5)
                ref_align = "CENTER"
                val_align = "CENTER"
            elif mode == "bottom":
                ref_pos = Point(wx_center, wy_min - 4.5)
                val_pos = Point(wx_center, wy_min - 8.5)
                ref_align = "CENTER"
                val_align = "CENTER"
            elif mode == "left":
                ref_pos = Point(wx_min - 3.0, wy_center + 1.5)
                val_pos = Point(wx_min - 3.0, wy_center - 3.0)
                ref_align = "RIGHT"
                val_align = "RIGHT"
            else:  # "right"
                ref_pos = Point(wx_max + 3.0, wy_center + 1.5)
                val_pos = Point(wx_max + 3.0, wy_center - 3.0)
                ref_align = "LEFT"
                val_align = "LEFT"

        if self.refdes:
            canvas.add_text(
                text=self.refdes,
                position=ref_pos.to_tuple(),
                height=StandardStyles.HEIGHT_REFDES,
                layer=StandardLayers.REFDES.name,
                align=ref_align,
                source=self.refdes,
                snap=False,
            )

        if self.value:
            canvas.add_text(
                text=self.value,
                position=val_pos.to_tuple(),
                height=StandardStyles.HEIGHT_PARAMS,
                layer=StandardLayers.PARAMS.name,
                align=val_align,
                source=self.refdes,
                snap=False,
            )

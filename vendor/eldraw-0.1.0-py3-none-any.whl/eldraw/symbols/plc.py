"""Программируемые логические контроллеры (ПЛК / PLC) и модули ввода-вывода (ГОСТ / IEC).

Реализует европейский стандарт схем автоматизации (Siemens S7-1500 / ET200 / Robor):
- PLCDigitalInputCard (8-канальная плата дискретных входов с табличной шапкой)
- PLCDigitalOutputCard (8-канальная плата дискретных выходов с табличной шапкой)
- PLCAnalogCard (модуль аналоговых входов/выходов)
- PLCCommunicationPort (коммуникационные порты PROFINET / Ethernet)
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Union

from eldraw.core.grid import Point
from eldraw.core.layers import StandardLayers
from eldraw.symbols.base import Symbol


@dataclass
class PLCChannelInfo:
    """Метаданные канала ввода-вывода ПЛК."""
    index: int                  # Номер канала (0..7)
    address: str                # Адрес переменной (напр. "E207.0" или "%I0.0")
    terminal_no: str            # Номер клеммы (напр. "31", "1", "DI0")
    tag: str = ""               # Позиционное обозначение подключенного датчика (напр. "8614SQ3")
    description: str = ""       # Описание функции (напр. "Limit switch lower")


class PLCDigitalInputCard(Symbol):
    """
    8-канальный модуль дискретного ввода ПЛК (Siemens DI 8x24VDC / Robor style).
    
    Содержит:
    - Горизонтальную полосу интерфейсного модуля;
    - Табличную шапку каналов (адрес, номер клеммы, имя датчика, функциональный комментарий);
    - Точки подключения каналов 0..7 и общего питания (+24V, 0V).
    """

    def __init__(
        self,
        refdes: str = "A1",
        value: str = "DI 8x24VDC",
        model: str = "6ES7 521-1BH00-0AB0",
        channels: Optional[List[PLCChannelInfo]] = None,
        channel_pitch: float = 25.0,
    ):
        self.channel_pitch = float(channel_pitch)
        self.num_channels = 8
        self.channels = channels or [
            PLCChannelInfo(i, f"E{100+i//8}.{i%8}", str(31 + i)) for i in range(self.num_channels)
        ]

        block_name = f"SYM_PLC_DI8_{refdes}_P{int(self.channel_pitch)}"
        super().__init__(block_name=block_name, refdes=refdes, value=value, model=model)

        # Выводы питания слева
        self.add_pin("24V", Point(-20.0, 0.0), direction=(0.0, -1.0))
        self.add_pin("0V", Point(-10.0, 0.0), direction=(0.0, -1.0))

        # Выводы каналов снизу полосы модуля (y=0)
        for i in range(self.num_channels):
            x = i * self.channel_pitch
            pin_name = f"in_{i}"
            self.add_pin(pin_name, Point(x, 0.0), direction=(0.0, -1.0))
            self.add_pin(str(i), Point(x, 0.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        table_layer = StandardLayers.TABLES.name
        text_layer = StandardLayers.TEXT.name
        lw = 50

        total_width = (self.num_channels - 1) * self.channel_pitch
        x_start = -25.0
        x_end = total_width + 15.0

        # 1. Горизонтальная закрашенная/утолщенная шина интерфейсного модуля (y in [-2.5, 2.5])
        block.add_lwpolyline(
            [(x_start, -2.0), (x_end, -2.0), (x_end, 2.0), (x_start, 2.0)],
            close=True,
            dxfattribs={"layer": layer, "lineweight": 70},
        )

        # Подпись модуля
        block.add_text(
            f"{self.refdes} =QG INTERFACE MODULE",
            dxfattribs={"layer": text_layer, "height": 2.0, "style": "GOST_B"},
        ).set_placement((x_start, 5.0))

        # Выводы питания (+24V, 0V)
        for x, lbl in [(-20.0, "+"), (-10.0, "-")]:
            block.add_line((x, -2.0), (x, -6.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_text(lbl, dxfattribs={"layer": text_layer, "height": 2.0, "style": "GOST_B"}).set_placement((x - 1.0, 3.5))

        # 2. Табличная шапка каналов ПЛК (над шиной: y from 8.0 to 45.0)
        y_b = 8.0
        y_t = 45.0
        # Рамка таблицы каналов
        block.add_lwpolyline(
            [(-5.0, y_b), (total_width + 5.0, y_b), (total_width + 5.0, y_t), (-5.0, y_t)],
            close=True,
            dxfattribs={"layer": table_layer, "lineweight": 35},
        )

        # Горизонтальные строки таблицы:
        # y=16: клеммы
        # y=26: адреса ПЛК
        # y=36: теги датчиков
        # y=45: верх
        block.add_line((-5.0, 16.0), (total_width + 5.0, 16.0), dxfattribs={"layer": table_layer, "lineweight": 25})
        block.add_line((-5.0, 26.0), (total_width + 5.0, 26.0), dxfattribs={"layer": table_layer, "lineweight": 25})
        block.add_line((-5.0, 36.0), (total_width + 5.0, 36.0), dxfattribs={"layer": table_layer, "lineweight": 25})

        # Разделители колонок каналов
        for i in range(self.num_channels):
            x = i * self.channel_pitch
            col_left = x - self.channel_pitch / 2.0 if i > 0 else -5.0
            if i > 0:
                block.add_line((col_left, y_b), (col_left, y_t), dxfattribs={"layer": table_layer, "lineweight": 25})

            ch = self.channels[i] if i < len(self.channels) else PLCChannelInfo(i, f"E.{i}", str(i))

            # Строка 1: Клемма (y in [8, 16])
            block.add_text(ch.terminal_no, dxfattribs={"layer": text_layer, "height": 1.8, "style": "GOST_B"}).set_placement((x - 2.0, 11.0))
            # Строка 2: Адрес (y in [16, 26])
            block.add_text(ch.address, dxfattribs={"layer": text_layer, "height": 2.2, "style": "GOST_B"}).set_placement((x - 6.0, 20.0))
            # Строка 3: Тег (y in [26, 36])
            block.add_text(ch.tag or f"Ch{i}", dxfattribs={"layer": text_layer, "height": 1.8, "style": "GOST_B"}).set_placement((x - 5.0, 29.5))
            # Строка 4: Комментарий (y in [36, 45])
            desc = ch.description[:18] if ch.description else f"DI Channel {i}"
            block.add_text(desc, dxfattribs={"layer": text_layer, "height": 1.4, "style": "GOST_B"}).set_placement((x - 10.0, 39.5))

            # Вывод канала вниз из шины (y: -2.0 -> -6.0)
            block.add_line((x, -2.0), (x, -6.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_text(str(i), dxfattribs={"layer": text_layer, "height": 1.6, "style": "GOST_B"}).set_placement((x - 1.0, -5.0))

    def get_bounds(self) -> Tuple[float, float, float, float]:
        total_width = (self.num_channels - 1) * self.channel_pitch
        return (-25.0, -6.0, total_width + 15.0, 45.0)


class PLCDigitalOutputCard(Symbol):
    """
    8-канальный модуль дискретного вывода ПЛК (Siemens DO 8x24VDC 0.5A / Robor style).
    
    Содержит табличную шапку, адреса выходов (%Q / A111.0..A111.7) и выводы
    для управления промежуточными реле или клапанами.
    """

    def __init__(
        self,
        refdes: str = "A2",
        value: str = "DO 8x24VDC 0.5A",
        model: str = "6ES7 522-1BF00-0AB0",
        channels: Optional[List[PLCChannelInfo]] = None,
        channel_pitch: float = 25.0,
    ):
        self.channel_pitch = float(channel_pitch)
        self.num_channels = 8
        self.channels = channels or [
            PLCChannelInfo(i, f"A{110+i//8}.{i%8}", str(31 + i)) for i in range(self.num_channels)
        ]

        block_name = f"SYM_PLC_DO8_{refdes}_P{int(self.channel_pitch)}"
        super().__init__(block_name=block_name, refdes=refdes, value=value, model=model)

        self.add_pin("24V", Point(-20.0, 0.0), direction=(0.0, -1.0))
        self.add_pin("0V", Point(-10.0, 0.0), direction=(0.0, -1.0))

        for i in range(self.num_channels):
            x = i * self.channel_pitch
            self.add_pin(f"out_{i}", Point(x, 0.0), direction=(0.0, -1.0))
            self.add_pin(str(i), Point(x, 0.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        # Геометрия идентична модулю ввода, с маркировкой DIGITAL OUTPUT
        layer = StandardLayers.SYMBOLS.name
        table_layer = StandardLayers.TABLES.name
        text_layer = StandardLayers.TEXT.name
        lw = 50

        total_width = (self.num_channels - 1) * self.channel_pitch
        x_start = -25.0
        x_end = total_width + 15.0

        block.add_lwpolyline(
            [(x_start, -2.0), (x_end, -2.0), (x_end, 2.0), (x_start, 2.0)],
            close=True,
            dxfattribs={"layer": layer, "lineweight": 70},
        )

        block.add_text(
            f"{self.refdes} =QG DIGITAL OUTPUT MODULE",
            dxfattribs={"layer": text_layer, "height": 2.0, "style": "GOST_B"},
        ).set_placement((x_start, 5.0))

        for x, lbl in [(-20.0, "+"), (-10.0, "-")]:
            block.add_line((x, -2.0), (x, -6.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_text(lbl, dxfattribs={"layer": text_layer, "height": 2.0, "style": "GOST_B"}).set_placement((x - 1.0, 3.5))

        y_b = 8.0
        y_t = 45.0
        block.add_lwpolyline(
            [(-5.0, y_b), (total_width + 5.0, y_b), (total_width + 5.0, y_t), (-5.0, y_t)],
            close=True,
            dxfattribs={"layer": table_layer, "lineweight": 35},
        )

        block.add_line((-5.0, 16.0), (total_width + 5.0, 16.0), dxfattribs={"layer": table_layer, "lineweight": 25})
        block.add_line((-5.0, 26.0), (total_width + 5.0, 26.0), dxfattribs={"layer": table_layer, "lineweight": 25})
        block.add_line((-5.0, 36.0), (total_width + 5.0, 36.0), dxfattribs={"layer": table_layer, "lineweight": 25})

        for i in range(self.num_channels):
            x = i * self.channel_pitch
            col_left = x - self.channel_pitch / 2.0 if i > 0 else -5.0
            if i > 0:
                block.add_line((col_left, y_b), (col_left, y_t), dxfattribs={"layer": table_layer, "lineweight": 25})

            ch = self.channels[i] if i < len(self.channels) else PLCChannelInfo(i, f"A.{i}", str(i))

            block.add_text(ch.terminal_no, dxfattribs={"layer": text_layer, "height": 1.8, "style": "GOST_B"}).set_placement((x - 2.0, 11.0))
            block.add_text(ch.address, dxfattribs={"layer": text_layer, "height": 2.2, "style": "GOST_B"}).set_placement((x - 6.0, 20.0))
            block.add_text(ch.tag or f"Actuator {i}", dxfattribs={"layer": text_layer, "height": 1.8, "style": "GOST_B"}).set_placement((x - 5.0, 29.5))
            desc = ch.description[:18] if ch.description else f"DO Command {i}"
            block.add_text(desc, dxfattribs={"layer": text_layer, "height": 1.4, "style": "GOST_B"}).set_placement((x - 10.0, 39.5))

            block.add_line((x, -2.0), (x, -6.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_text(str(i), dxfattribs={"layer": text_layer, "height": 1.6, "style": "GOST_B"}).set_placement((x - 1.0, -5.0))

    def get_bounds(self) -> Tuple[float, float, float, float]:
        total_width = (self.num_channels - 1) * self.channel_pitch
        return (-25.0, -6.0, total_width + 15.0, 45.0)

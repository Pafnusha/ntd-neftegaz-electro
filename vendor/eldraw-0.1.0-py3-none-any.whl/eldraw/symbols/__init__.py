"""Библиотека УГО (условно-графических обозначений) по стандартам ГОСТ."""

from eldraw.symbols.base import Pin, Symbol
from eldraw.symbols.power import (
    CircuitBreaker,
    SwitchDisconnector,
    ResidualCurrentDevice,
    Fuse,
    BusBar,
)
from eldraw.symbols.automation import (
    ContactorCoil,
    RelayCoil,
    NOContact,
    NCContact,
    PushButton,
    PilotLight,
    Terminal,
)
from eldraw.symbols.electronics import (
    Resistor,
    Capacitor,
    Inductor,
    Diode,
    BJTTransistor,
    Ground,
)
from eldraw.symbols.protection import (
    MotorCircuitBreaker,
    ThermalOverloadRelay,
)
from eldraw.symbols.drives import (
    VFDPowerUnit,
    VFDControlUnit,
    BrakingResistor,
)
from eldraw.symbols.plc import (
    PLCDigitalInputCard,
    PLCDigitalOutputCard,
    PLCChannelInfo,
)
from eldraw.symbols.automation_advanced import (
    IntermediateRelayCoil,
    ChangeoverContact,
    SafetyRelay,
    PowerSupply24V,
    MultiTierTerminal,
    SolenoidValve,
)

__all__ = [
    "Pin",
    "Symbol",
    # Силовые и защита
    "CircuitBreaker",
    "SwitchDisconnector",
    "ResidualCurrentDevice",
    "Fuse",
    "BusBar",
    "MotorCircuitBreaker",
    "ThermalOverloadRelay",
    # Частотный привод
    "VFDPowerUnit",
    "VFDControlUnit",
    "BrakingResistor",
    # ПЛК и ввод-вывод
    "PLCDigitalInputCard",
    "PLCDigitalOutputCard",
    "PLCChannelInfo",
    # Автоматика и релейная защита
    "ContactorCoil",
    "RelayCoil",
    "IntermediateRelayCoil",
    "NOContact",
    "NCContact",
    "ChangeoverContact",
    "SafetyRelay",
    "PushButton",
    "PilotLight",
    "Terminal",
    "MultiTierTerminal",
    "PowerSupply24V",
    "SolenoidValve",
    # Электроника
    "Resistor",
    "Capacitor",
    "Inductor",
    "Diode",
    "BJTTransistor",
    "Ground",
]


"""Радиоэлектронные компоненты по ГОСТ 2.728, ГОСТ 2.730 и ГОСТ 2.710."""

from __future__ import annotations
import math
from eldraw.core.grid import Point
from eldraw.core.layers import StandardLayers
from eldraw.symbols.base import Symbol


class Resistor(Symbol):
    """Постоянный резистор (R) по ГОСТ 2.728 (прямоугольник 10x4 мм)."""

    def __init__(self, refdes: str = "R1", value: str = "10k", model: str = ""):
        super().__init__(block_name="SYM_RESISTOR", refdes=refdes, value=value, model=model)
        self.add_pin("1", Point(-10.0, 0.0), direction=(-1.0, 0.0))
        self.add_pin("2", Point(10.0, 0.0), direction=(1.0, 0.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50

        # Прямоугольник 10x4 мм
        block.add_lwpolyline(
            [(-5.0, -2.0), (5.0, -2.0), (5.0, 2.0), (-5.0, 2.0)],
            close=True,
            dxfattribs={"layer": layer, "lineweight": lw},
        )
        # Осевые выводы
        block.add_line((-10.0, 0.0), (-5.0, 0.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((5.0, 0.0), (10.0, 0.0), dxfattribs={"layer": layer, "lineweight": lw})


class Capacitor(Symbol):
    """Конденсатор постоянной емкости (C) по ГОСТ 2.728."""

    def __init__(self, refdes: str = "C1", value: str = "100nF", polarized: bool = False, model: str = ""):
        self.polarized = polarized
        block_name = "SYM_CAPACITOR_POL" if polarized else "SYM_CAPACITOR"
        super().__init__(block_name=block_name, refdes=refdes, value=value, model=model)
        self.add_pin("1", Point(-10.0, 0.0), direction=(-1.0, 0.0))
        self.add_pin("2", Point(10.0, 0.0), direction=(1.0, 0.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50

        # Две параллельные обкладки длиной 8 мм с зазором 2 мм
        block.add_line((-1.0, -4.0), (-1.0, 4.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((1.0, -4.0), (1.0, 4.0), dxfattribs={"layer": layer, "lineweight": lw})

        # Выводы
        block.add_line((-10.0, 0.0), (-1.0, 0.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((1.0, 0.0), (10.0, 0.0), dxfattribs={"layer": layer, "lineweight": lw})

        # Знак плюс для полярного конденсатора
        if self.polarized:
            block.add_line((-4.5, 2.5), (-2.5, 2.5), dxfattribs={"layer": layer, "lineweight": 25})
            block.add_line((-3.5, 1.5), (-3.5, 3.5), dxfattribs={"layer": layer, "lineweight": 25})


class Inductor(Symbol):
    """Катушка индуктивности / дроссель (L) по ГОСТ 2.728 (4 полуокружности)."""

    def __init__(self, refdes: str = "L1", value: str = "10uH", model: str = ""):
        super().__init__(block_name="SYM_INDUCTOR", refdes=refdes, value=value, model=model)
        self.add_pin("1", Point(-10.0, 0.0), direction=(-1.0, 0.0))
        self.add_pin("2", Point(10.0, 0.0), direction=(1.0, 0.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50

        # 4 полукольца радиусом 2.0 мм от x=-8 до x=+8
        r = 2.0
        for i in range(4):
            center_x = -6.0 + i * 4.0
            block.add_arc(
                (center_x, 0.0),
                radius=r,
                start_angle=0,
                end_angle=180,
                dxfattribs={"layer": layer, "lineweight": lw},
            )

        # Выводы по краям
        block.add_line((-10.0, 0.0), (-8.0, 0.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((8.0, 0.0), (10.0, 0.0), dxfattribs={"layer": layer, "lineweight": lw})


class Diode(Symbol):
    """Полупроводниковый диод (VD) по ГОСТ 2.730."""

    def __init__(self, refdes: str = "VD1", value: str = "1N4148", led: bool = False, model: str = ""):
        self.led = led
        block_name = "SYM_LED" if led else "SYM_DIODE"
        super().__init__(block_name=block_name, refdes=refdes, value=value, model=model)
        self.add_pin("anode", Point(-10.0, 0.0), direction=(-1.0, 0.0))
        self.add_pin("cathode", Point(10.0, 0.0), direction=(1.0, 0.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50

        # Треугольник диода (вершина направлена вправо)
        block.add_lwpolyline(
            [(-3.0, -3.0), (3.0, 0.0), (-3.0, 3.0)],
            close=True,
            dxfattribs={"layer": layer, "lineweight": lw},
        )
        # Катодная черточка
        block.add_line((3.0, -3.5), (3.0, 3.5), dxfattribs={"layer": layer, "lineweight": lw})

        # Выводы
        block.add_line((-10.0, 0.0), (-3.0, 0.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((3.0, 0.0), (10.0, 0.0), dxfattribs={"layer": layer, "lineweight": lw})

        # Стрелки излучения для светодиода
        if self.led:
            block.add_line((1.0, 4.0), (4.0, 7.0), dxfattribs={"layer": layer, "lineweight": 25})
            block.add_line((4.0, 7.0), (2.5, 7.0), dxfattribs={"layer": layer, "lineweight": 25})
            block.add_line((4.0, 7.0), (4.0, 5.5), dxfattribs={"layer": layer, "lineweight": 25})

            block.add_line((3.5, 2.5), (6.5, 5.5), dxfattribs={"layer": layer, "lineweight": 25})
            block.add_line((6.5, 5.5), (5.0, 5.5), dxfattribs={"layer": layer, "lineweight": 25})
            block.add_line((6.5, 5.5), (6.5, 4.0), dxfattribs={"layer": layer, "lineweight": 25})


class BJTTransistor(Symbol):
    """Биполярный транзистор (VT) по ГОСТ 2.730 (NPN или PNP)."""

    def __init__(self, refdes: str = "VT1", transistor_type: str = "NPN", value: str = "BC547", model: str = ""):
        self.transistor_type = transistor_type.upper()
        block_name = f"SYM_BJT_{self.transistor_type}"
        super().__init__(block_name=block_name, refdes=refdes, value=value, model=model)
        self.add_pin("B", Point(-10.0, 0.0), direction=(-1.0, 0.0))  # База
        self.add_pin("C", Point(5.0, 10.0), direction=(0.0, 1.0))  # Коллектор
        self.add_pin("E", Point(5.0, -10.0), direction=(0.0, -1.0))  # Эмиттер

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50

        # Корпус (окружность диаметром 12 мм)
        block.add_circle((0.0, 0.0), radius=6.0, dxfattribs={"layer": layer, "lineweight": 25})

        # База: вертикальная черта
        block.add_line((-2.0, -4.0), (-2.0, 4.0), dxfattribs={"layer": layer, "lineweight": lw})
        # Вывод базы
        block.add_line((-10.0, 0.0), (-2.0, 0.0), dxfattribs={"layer": layer, "lineweight": lw})

        # Коллектор: наклонная линия и вывод
        block.add_line((-2.0, 2.0), (3.0, 5.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((3.0, 5.0), (5.0, 5.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((5.0, 5.0), (5.0, 10.0), dxfattribs={"layer": layer, "lineweight": lw})

        # Эмиттер: наклонная линия и вывод
        block.add_line((-2.0, -2.0), (3.0, -5.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((3.0, -5.0), (5.0, -5.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((5.0, -5.0), (5.0, -10.0), dxfattribs={"layer": layer, "lineweight": lw})

        # Стрелка на эмиттере (NPN — наружу, PNP — внутрь)
        if self.transistor_type == "NPN":
            block.add_line((1.5, -4.0), (3.0, -5.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_line((1.5, -6.0), (3.0, -5.0), dxfattribs={"layer": layer, "lineweight": lw})
        else:
            block.add_line((-0.5, -1.0), (-2.0, -2.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_line((-0.5, -3.0), (-2.0, -2.0), dxfattribs={"layer": layer, "lineweight": lw})


class Ground(Symbol):
    """Символ заземления (PE / Корпус / Земля) по ГОСТ 2.702."""

    def __init__(self, ground_type: str = "PE"):
        self.ground_type = ground_type.upper()
        super().__init__(block_name=f"SYM_GND_{self.ground_type}", refdes="", value="")
        self.add_pin("in", Point(0.0, 5.0), direction=(0.0, 1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50

        # Вводный провод сверху
        block.add_line((0.0, 5.0), (0.0, 0.0), dxfattribs={"layer": layer, "lineweight": lw})

        # 3 горизонтальные уменьшающиеся черты
        block.add_line((-4.0, 0.0), (4.0, 0.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((-2.5, -2.0), (2.5, -2.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((-1.0, -4.0), (1.0, -4.0), dxfattribs={"layer": layer, "lineweight": lw})

"""Частотные преобразователи (VFD / ПЧ) и компоненты электропривода.

Реализует европейский стандарт разделения на:
- VFDPowerUnit (силовой блок: 3Ф вход, тормозной резистор, 3Ф выход на двигатель, экран)
- VFDControlUnit (блок управления: дискретные входы, аналоговые каналы, реле, STO, PROFINET)
- BrakingResistor (тормозной резистор)
"""

from __future__ import annotations
from typing import Dict, List, Optional, Tuple, Union

from eldraw.core.grid import Point
from eldraw.core.layers import StandardLayers
from eldraw.symbols.base import Symbol


class VFDPowerUnit(Symbol):
    """
    Силовой блок частотного преобразователя (VFD / ПЧ, напр. Siemens Sinamics G120).
    
    Содержит:
    - 3-фазный ввод питания: U1, V1, W1 (сверху);
    - Выводы тормозного резистора: DCP/R1, R2 (слева);
    - 3-фазный выход на двигатель: U2, V2, W2 (снизу);
    - Защитное заземление / экран: PE (справа/снизу);
    - Табличку перекрестной ссылки на блок управления (Control Unit Ref).
    """

    def __init__(
        self,
        refdes: str = "U1",
        value: str = "4.0 kW",
        model: str = "SINAMICS G120",
        control_unit_ref: str = "",
        brake_resistor_ref: str = "",
        pitch: float = 10.0,
    ):
        self.control_unit_ref = control_unit_ref
        self.brake_resistor_ref = brake_resistor_ref
        self.pitch = float(pitch)
        block_name = f"SYM_VFD_POWER_{refdes}_{int(self.pitch)}"
        super().__init__(block_name=block_name, refdes=refdes, value=value, model=model)

        # Силовые входы (сверху, y=15)
        self.add_pin("U1", Point(0.0, 15.0), direction=(0.0, 1.0))
        self.add_pin("V1", Point(self.pitch, 15.0), direction=(0.0, 1.0))
        self.add_pin("W1", Point(2 * self.pitch, 15.0), direction=(0.0, 1.0))

        # Выводы тормозного резистора (слева, x=-15)
        self.add_pin("DCP", Point(-15.0, 5.0), direction=(-1.0, 0.0))
        self.add_pin("R2", Point(-15.0, -5.0), direction=(-1.0, 0.0))

        # Силовые выходы на двигатель (снизу, y=-15)
        self.add_pin("U2", Point(0.0, -15.0), direction=(0.0, -1.0))
        self.add_pin("V2", Point(self.pitch, -15.0), direction=(0.0, -1.0))
        self.add_pin("W2", Point(2 * self.pitch, -15.0), direction=(0.0, -1.0))

        # Заземление / PE (справа, x=30, y=-10)
        self.add_pin("PE", Point(2 * self.pitch + 10.0, -15.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        text_layer = StandardLayers.TEXT.name
        lw = 50

        # Корпус силового модуля: прямоугольник от x=-10 до x=35, y=-10 до y=10
        x_min = -10.0
        x_max = 2 * self.pitch + 15.0  # 35.0
        y_min = -10.0
        y_max = 10.0

        block.add_lwpolyline(
            [(x_min, y_min), (x_max, y_min), (x_max, y_max), (x_min, y_max)],
            close=True,
            dxfattribs={"layer": layer, "lineweight": lw},
        )

        # Выводы сверху (U1, V1, W1)
        for i in range(3):
            x = i * self.pitch
            block.add_line((x, y_max), (x, y_max + 5.0), dxfattribs={"layer": layer, "lineweight": lw})
            # Метки выводов
            block.add_text(
                ["U1", "V1", "W1"][i],
                dxfattribs={"layer": text_layer, "height": 1.6, "style": "GOST_B"},
            ).set_placement((x - 1.2, y_max - 3.5))

        # Выводы слева (DCP, R2)
        block.add_line((x_min, 5.0), (x_min - 5.0, 5.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((x_min, -5.0), (x_min - 5.0, -5.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_text("DCP/R1", dxfattribs={"layer": text_layer, "height": 1.4, "style": "GOST_B"}).set_placement((x_min + 1.0, 4.0))
        block.add_text("R2", dxfattribs={"layer": text_layer, "height": 1.4, "style": "GOST_B"}).set_placement((x_min + 1.0, -6.0))

        # Выводы снизу (U2, V2, W2)
        for i in range(3):
            x = i * self.pitch
            block.add_line((x, y_min), (x, y_min - 5.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_text(
                ["U2", "V2", "W2"][i],
                dxfattribs={"layer": text_layer, "height": 1.6, "style": "GOST_B"},
            ).set_placement((x - 1.2, y_min + 1.5))

        # Вывод PE
        x_pe = 2 * self.pitch + 10.0
        block.add_line((x_pe, y_min), (x_pe, y_min - 5.0), dxfattribs={"layer": layer, "lineweight": lw})
        # Графический символ заземления внутри корпуса около PE
        block.add_line((x_pe - 2.5, y_min + 2.0), (x_pe + 2.5, y_min + 2.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((x_pe - 1.5, y_min + 3.2), (x_pe + 1.5, y_min + 3.2), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((x_pe - 0.5, y_min + 4.4), (x_pe + 0.5, y_min + 4.4), dxfattribs={"layer": layer, "lineweight": lw})

        # Внутренняя диагональ символа преобразователя (выпрямитель/инвертор)
        block.add_line((x_min + 5.0, y_min + 2.0), (x_min + 20.0, y_max - 2.0), dxfattribs={"layer": layer, "lineweight": 25})
        block.add_text("~", dxfattribs={"layer": text_layer, "height": 2.5, "style": "GOST_B"}).set_placement((x_min + 7.0, y_max - 5.0))
        block.add_text("~f", dxfattribs={"layer": text_layer, "height": 2.5, "style": "GOST_B"}).set_placement((x_min + 14.0, y_min + 3.0))

        # Поле кросс-референса на Control Unit (в правой части блока)
        box_x = x_max - 14.0
        block.add_line((box_x, y_min), (box_x, y_max), dxfattribs={"layer": layer, "lineweight": 25})
        block.add_line((box_x, 3.0), (x_max, 3.0), dxfattribs={"layer": layer, "lineweight": 25})
        block.add_text("Reference", dxfattribs={"layer": text_layer, "height": 1.4, "style": "GOST_B"}).set_placement((box_x + 1.0, 5.0))
        block.add_text("Control Unit", dxfattribs={"layer": text_layer, "height": 1.4, "style": "GOST_B"}).set_placement((box_x + 1.0, 3.5))
        if self.control_unit_ref:
            block.add_text(f"Sh. {self.control_unit_ref}", dxfattribs={"layer": text_layer, "height": 1.6, "style": "GOST_B"}).set_placement((box_x + 1.0, -3.0))

    def get_bounds(self) -> Tuple[float, float, float, float]:
        return (-15.0, -15.0, 35.0, 15.0)


class VFDControlUnit(Symbol):
    """
    Блок управления частотным преобразователем (Control Unit, напр. Siemens CU240E-2).
    
    Содержит:
    - Дискретные входы: DI0..DI5, +24V, 0V;
    - Аналоговые каналы: AI0+, AI0-, AI1+, AI1-, AO0+, AO1+, GND;
    - Релейные выходы: DO0 (COM, NO, NC), DO1;
    - Порты связи: 2 x PROFINET RJ45.
    """

    def __init__(
        self,
        refdes: str = "U1.CU",
        value: str = "CU240E-2 PN",
        model: str = "6SL3244-0BB12-1FA0",
        power_unit_ref: str = "",
    ):
        self.power_unit_ref = power_unit_ref
        super().__init__(block_name=f"SYM_VFD_CU240_{refdes}", refdes=refdes, value=value, model=model)

        # Выводы цифровых входов DI (сверху)
        for i in range(6):
            self.add_pin(f"DI{i}", Point(i * 10.0, 20.0), direction=(0.0, 1.0))
        self.add_pin("24V", Point(60.0, 20.0), direction=(0.0, 1.0))
        self.add_pin("0V", Point(70.0, 20.0), direction=(0.0, 1.0))

        # Аналоговые входы/выходы (снизу слева)
        self.add_pin("AI0_P", Point(0.0, -20.0), direction=(0.0, -1.0))
        self.add_pin("AI0_M", Point(10.0, -20.0), direction=(0.0, -1.0))
        self.add_pin("AO0", Point(20.0, -20.0), direction=(0.0, -1.0))
        self.add_pin("AGND", Point(30.0, -20.0), direction=(0.0, -1.0))

        # Релейные выходы DO0 (снизу в центре)
        self.add_pin("DO0_COM", Point(45.0, -20.0), direction=(0.0, -1.0))
        self.add_pin("DO0_NO", Point(55.0, -20.0), direction=(0.0, -1.0))
        self.add_pin("DO0_NC", Point(65.0, -20.0), direction=(0.0, -1.0))

        # PROFINET порты (справа снизу)
        self.add_pin("PN1", Point(85.0, -20.0), direction=(0.0, -1.0))
        self.add_pin("PN2", Point(100.0, -20.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        text_layer = StandardLayers.TEXT.name
        lw = 50

        # Корпус модуля: x in [-10, 115], y in [-15, 15]
        block.add_lwpolyline(
            [(-10.0, -15.0), (115.0, -15.0), (115.0, 15.0), (-10.0, 15.0)],
            close=True,
            dxfattribs={"layer": layer, "lineweight": lw},
        )

        # Выводы сверху (DI0..DI5, 24V, 0V)
        for i in range(6):
            x = i * 10.0
            block.add_line((x, 15.0), (x, 20.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_text(f"DI{i}", dxfattribs={"layer": text_layer, "height": 1.6, "style": "GOST_B"}).set_placement((x - 2.0, 10.0))

        block.add_line((60.0, 15.0), (60.0, 20.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_text("+24V", dxfattribs={"layer": text_layer, "height": 1.4, "style": "GOST_B"}).set_placement((57.0, 10.0))
        block.add_line((70.0, 15.0), (70.0, 20.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_text("0V", dxfattribs={"layer": text_layer, "height": 1.4, "style": "GOST_B"}).set_placement((68.0, 10.0))

        # Аналоговая секция (снизу)
        for x, lbl in [(0.0, "AI0+"), (10.0, "AI0-"), (20.0, "AO0"), (30.0, "AGND")]:
            block.add_line((x, -15.0), (x, -20.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_text(lbl, dxfattribs={"layer": text_layer, "height": 1.4, "style": "GOST_B"}).set_placement((x - 2.5, -12.0))

        # Релейный выход DO0
        for x, lbl in [(45.0, "COM"), (55.0, "NO"), (65.0, "NC")]:
            block.add_line((x, -15.0), (x, -20.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_text(lbl, dxfattribs={"layer": text_layer, "height": 1.4, "style": "GOST_B"}).set_placement((x - 2.5, -12.0))

        # PROFINET RJ45 гнезда
        for x in [85.0, 100.0]:
            block.add_lwpolyline(
                [(x - 4.0, -15.0), (x + 4.0, -15.0), (x + 4.0, -8.0), (x - 4.0, -8.0)],
                close=True,
                dxfattribs={"layer": layer, "lineweight": lw},
            )
            block.add_line((x, -15.0), (x, -20.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_text("PROFINET", dxfattribs={"layer": text_layer, "height": 1.4, "style": "GOST_B"}).set_placement((x - 4.5, -5.0))

        # Заголовок CU240E
        block.add_text("SIEMENS Control Unit CU240E-2", dxfattribs={"layer": text_layer, "height": 2.0, "style": "GOST_B"}).set_placement((-5.0, 2.0))
        if self.power_unit_ref:
            block.add_text(f"Power Section: Sh. {self.power_unit_ref}", dxfattribs={"layer": text_layer, "height": 1.6, "style": "GOST_B"}).set_placement((-5.0, -2.0))

    def get_bounds(self) -> Tuple[float, float, float, float]:
        return (-10.0, -20.0, 115.0, 20.0)


class BrakingResistor(Symbol):
    """Тормозной резистор частотного привода (BR) с теплоотводящим обозначением."""

    def __init__(self, refdes: str = "BR1", value: str = "75 Ohm", model: str = "BW500"):
        super().__init__(block_name="SYM_BRAKING_RESISTOR", refdes=refdes, value=value, model=model)
        self.add_pin("1", Point(0.0, 10.0), direction=(0.0, 1.0))
        self.add_pin("2", Point(0.0, -10.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50

        # Прямоугольник резистора 4x12 мм
        block.add_lwpolyline(
            [(-2.0, -6.0), (2.0, -6.0), (2.0, 6.0), (-2.0, 6.0)],
            close=True,
            dxfattribs={"layer": layer, "lineweight": lw},
        )
        # Выводы
        block.add_line((0.0, 6.0), (0.0, 10.0), dxfattribs={"layer": layer, "lineweight": lw})
        block.add_line((0.0, -6.0), (0.0, -10.0), dxfattribs={"layer": layer, "lineweight": lw})
        # Стрелка теплоотвода (рассеяние энергии)
        block.add_line((-4.0, 4.0), (-6.0, 6.0), dxfattribs={"layer": layer, "lineweight": 25})
        block.add_line((-4.0, 0.0), (-6.0, 2.0), dxfattribs={"layer": layer, "lineweight": 25})
        block.add_line((-4.0, -4.0), (-6.0, -2.0), dxfattribs={"layer": layer, "lineweight": 25})

    def get_bounds(self) -> Tuple[float, float, float, float]:
        return (-6.5, -10.0, 2.5, 10.0)

"""Аппараты защиты электродвигателей и силовых цепей (ГОСТ 2.755 / IEC 60617).

Включает:
- MotorCircuitBreaker (мотор-автомат с тепловым и электромагнитным расцепителем)
- ThermalOverloadRelay (тепловое реле защиты от перегрузки)
"""

from __future__ import annotations
from typing import Dict, List, Optional, Tuple, Union

from eldraw.core.grid import Point
from eldraw.core.layers import StandardLayers
from eldraw.symbols.base import Symbol


class MotorCircuitBreaker(Symbol):
    """
    Автоматический выключатель защиты двигателя (мотор-автомат, QM/QF)
    по ГОСТ 2.755 / IEC 60617-7.
    
    Содержит на каждом полюсе:
    - контакт коммутации;
    - тепловой расцепитель (прямоугольный излом/флажок);
    - электромагнитный мгновенный расцепитель (крестик).
    """

    def __init__(
        self,
        refdes: str = "QM1",
        value: str = "4-6.3A",
        model: str = "GV2ME10",
        poles: int = 3,
        pole_pitch: float = 15.0,
        aux_contacts: Optional[List[str]] = None,
    ):
        """
        :param refdes: Позиционное обозначение (QM1, QF1).
        :param value: Диапазон уставки расцепителя (напр. '4-6.3A').
        :param model: Марка изделия (Schneider GV2, Siemens 3RV2).
        :param poles: Число силовых полюсов (по умолчанию 3).
        :param pole_pitch: Межполюсный шаг в мм.
        :param aux_contacts: Список встроенных доп. контактов (напр. ['NO', 'NC']).
        """
        self.poles = max(1, min(4, int(poles)))
        self.pole_pitch = float(pole_pitch)
        self.aux_contacts = aux_contacts or []
        block_name = f"SYM_MOTOR_CB_{self.poles}P_P{int(self.pole_pitch)}"
        super().__init__(block_name=block_name, refdes=refdes, value=value, model=model)

        # Регистрация силовых выводов
        # Вход сверху: 1, 3, 5
        # Выход снизу: 2, 4, 6
        pin_labels = [(1, 2), (3, 4), (5, 6), (7, 8)]
        for p in range(self.poles):
            x_offset = p * self.pole_pitch
            in_num, out_num = pin_labels[p]
            self.add_pin(str(in_num), Point(x_offset, 10.0), direction=(0.0, 1.0))
            self.add_pin(str(out_num), Point(x_offset, -10.0), direction=(0.0, -1.0))
            self.add_pin(f"in_{p+1}", Point(x_offset, 10.0), direction=(0.0, 1.0))
            self.add_pin(f"out_{p+1}", Point(x_offset, -10.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50

        # Отрисовка каждого силового полюса
        for p in range(self.poles):
            x = p * self.pole_pitch

            # Входной проводник сверху (y: 10 -> 3)
            block.add_line((x, 10.0), (x, 3.0), dxfattribs={"layer": layer, "lineweight": lw})
            # Неподвижный контакт (засечка)
            block.add_line((x - 1.5, 3.0), (x + 1.5, 3.0), dxfattribs={"layer": layer, "lineweight": lw})

            # Подвижный контакт (наклонный нож от (x, -2) к (x + 2.5, 3.0))
            block.add_line((x, -2.0), (x + 2.5, 3.0), dxfattribs={"layer": layer, "lineweight": lw})

            # Электромагнитный расцепитель (крестик на контакте)
            block.add_line((x + 1.5, 1.5), (x + 3.5, 3.5), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_line((x + 1.5, 3.5), (x + 3.5, 1.5), dxfattribs={"layer": layer, "lineweight": lw})

            # Тепловой расцепитель: прямоугольный изгиб / биметаллическая скоба
            # (x, -2) -> (x, -4) -> (x - 2.0, -4) -> (x - 2.0, -7) -> (x, -7) -> (x, -10)
            block.add_lwpolyline(
                [(x, -2.0), (x, -4.0), (x - 2.0, -4.0), (x - 2.0, -7.0), (x, -7.0), (x, -10.0)],
                close=False,
                dxfattribs={"layer": layer, "lineweight": lw},
            )

        # Механическая связь между полюсами (пунктир)
        if self.poles > 1:
            x_start = 0.0
            x_end = (self.poles - 1) * self.pole_pitch
            block.add_line(
                (x_start + 1.25, 0.5),
                (x_end + 1.25, 0.5),
                dxfattribs={"layer": layer, "linetype": "DASHED", "lineweight": 25},
            )

    def get_bounds(self) -> Tuple[float, float, float, float]:
        max_x = (self.poles - 1) * self.pole_pitch + 4.0
        return (-3.0, -10.0, max_x, 10.0)


class ThermalOverloadRelay(Symbol):
    """
    Тепловое реле защиты от перегрузки (KK/FR, напр. РТЛ / TeSys LRD).
    
    Содержит:
    - 3 силовых нагревательных элемента (входы 1-3-5, выходы 2-4-6);
    - Выводы вспомогательных сигнальных контактов (95-96 NC и 97-98 NO).
    """

    def __init__(
        self,
        refdes: str = "KK1",
        value: str = "8.5A",
        model: str = "LRD14",
        include_aux_pins: bool = True,
    ):
        self.include_aux = include_aux_pins
        block_name = f"SYM_THERMAL_OVERLOAD_{'FULL' if include_aux_pins else 'POWER'}"
        super().__init__(block_name=block_name, refdes=refdes, value=value, model=model)

        # Силовые выводы 3 фазы (шаг 15 мм)
        pitch = 15.0
        for p, (in_pin, out_pin) in enumerate([(1, 2), (3, 4), (5, 6)]):
            x = p * pitch
            self.add_pin(str(in_pin), Point(x, 10.0), direction=(0.0, 1.0))
            self.add_pin(str(out_pin), Point(x, -10.0), direction=(0.0, -1.0))
            self.add_pin(f"in_{p+1}", Point(x, 10.0), direction=(0.0, 1.0))
            self.add_pin(f"out_{p+1}", Point(x, -10.0), direction=(0.0, -1.0))

        # Если включены вспомогательные контакты на этом же УГО
        if include_aux_pins:
            # 95-96 NC контакт аварии
            self.add_pin("95", Point(37.5, 10.0), direction=(0.0, 1.0))
            self.add_pin("96", Point(37.5, -10.0), direction=(0.0, -1.0))
            # 97-98 NO контакт сигнализации
            self.add_pin("97", Point(52.5, 10.0), direction=(0.0, 1.0))
            self.add_pin("98", Point(52.5, -10.0), direction=(0.0, -1.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        lw = 50
        pitch = 15.0

        # 3 силовых биметаллических расцепителя
        for p in range(3):
            x = p * pitch
            # Верхний проводник (10 -> 4)
            block.add_line((x, 10.0), (x, 4.0), dxfattribs={"layer": layer, "lineweight": lw})
            # Биметаллическая скоба
            block.add_lwpolyline(
                [(x, 4.0), (x - 2.5, 4.0), (x - 2.5, -4.0), (x, -4.0)],
                close=False,
                dxfattribs={"layer": layer, "lineweight": lw},
            )
            # Нижний проводник (-4 -> -10)
            block.add_line((x, -4.0), (x, -10.0), dxfattribs={"layer": layer, "lineweight": lw})

        # Механическая связь между нагревателями
        block.add_line(
            (-2.5, 0.0),
            (2 * pitch, 0.0),
            dxfattribs={"layer": layer, "linetype": "DASHED", "lineweight": 25},
        )

        # Отрисовка вспомогательных контактов, если включены
        if self.include_aux:
            # Разделительная пунктирная линия блока
            block.add_line(
                (32.5, 10.0),
                (32.5, -10.0),
                dxfattribs={"layer": layer, "linetype": "DASHED", "lineweight": 25},
            )
            # NC контакт 95-96
            x_nc = 37.5
            block.add_line((x_nc, 10.0), (x_nc, 3.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_line((x_nc, -10.0), (x_nc, -3.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_line((x_nc - 2.0, 3.0), (x_nc, -3.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_line((x_nc - 2.0, 3.0), (x_nc + 1.0, 3.0), dxfattribs={"layer": layer, "lineweight": lw})

            # NO контакт 97-98
            x_no = 52.5
            block.add_line((x_no, 10.0), (x_no, 3.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_line((x_no, -10.0), (x_no, -3.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_line((x_no - 2.5, -3.0), (x_no, 3.0), dxfattribs={"layer": layer, "lineweight": lw})

    def get_bounds(self) -> Tuple[float, float, float, float]:
        max_x = 55.0 if self.include_aux else 32.0
        return (-4.0, -10.0, max_x, 10.0)

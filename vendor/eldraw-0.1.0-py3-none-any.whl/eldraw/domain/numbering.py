"""Модуль правил нумерации страниц, позиционных обозначений приборов и маркировки проводов.

Реализует стандарт Robor / EPLAN / ГОСТ 2.710 / IEC 81346:
- Страницы: старт по умолчанию 1000, шаг +10.
- Приборы: <page_number><device_type><device_number_on_that_page> (нумерация слева направо 1, 2, 3...).
- Провода: <page_number><wire_number_on_that_page> (старт 00, шаг +05: 00, 05, 10, 15...).
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

from eldraw.symbols.base import Symbol


# Общепринятые в области промышленной автоматизации буквенные коды типов приборов
STANDARD_DEVICE_TYPES: Dict[str, str] = {
    # Защита и силовая коммутация
    "MotorCircuitBreaker": "QM",
    "CircuitBreaker": "QF",
    "SwitchDisconnector": "QS",
    "ResidualCurrentDevice": "QF",
    "Fuse": "FU",
    # Пускатели и реле
    "ContactorCoil": "KM",
    "RelayCoil": "K",
    "IntermediateRelayCoil": "K",
    "SafetyRelay": "K",
    # Преобразователи и питание
    "VFDPowerUnit": "U",
    "VFDControlUnit": "U",
    "PowerSupply24V": "G",
    # Контроллеры и ПЛК
    "PLCDigitalInputCard": "A",
    "PLCDigitalOutputCard": "A",
    # Кнопки, датчики, индикаторы
    "PushButton": "SB",
    "PilotLight": "HL",
    "NOContact": "SQ",
    "NCContact": "SQ",
    "ChangeoverContact": "K",
    "SolenoidValve": "YV",
    # Клеммы и пассивные компоненты
    "Terminal": "XT",
    "MultiTierTerminal": "XT",
    "BrakingResistor": "R",
    "Resistor": "R",
    "Capacitor": "C",
    "Inductor": "L",
    "Diode": "VD",
    "BJTTransistor": "VT",
}


def get_device_type_code(symbol_or_type: Union[Symbol, str]) -> str:
    """Определяет стандартный буквенный код типа устройства."""
    if isinstance(symbol_or_type, Symbol):
        class_name = symbol_or_type.__class__.__name__
        if class_name in STANDARD_DEVICE_TYPES:
            return STANDARD_DEVICE_TYPES[class_name]
        # Если refdes уже имеет буквенный префикс, извлекаем его
        letters = "".join(c for c in symbol_or_type.refdes if c.isalpha())
        return letters.upper() if letters else "A"

    type_str = str(symbol_or_type).strip()
    if type_str in STANDARD_DEVICE_TYPES:
        return STANDARD_DEVICE_TYPES[type_str]
    return type_str.upper()


@dataclass
class ProjectNumbering:
    """
    Система нумерации страниц, позиционных обозначений приборов и маркировки проводов.
    
    :param start_page: Начальный номер страницы (по умолчанию 1000).
    :param page_step: Шаг нумерации последующих страниц (по умолчанию 10).
    :param wire_step: Шаг нумерации проводов на листе (по умолчанию 5).
    """

    start_page: int = 1000
    page_step: int = 10
    wire_step: int = 5

    def get_next_page_number(self, current_page: Optional[int] = None) -> int:
        """Возвращает следующий номер страницы с шагом page_step."""
        if current_page is None:
            return self.start_page
        return int(current_page) + self.page_step

    def format_device_tag(
        self,
        page_number: Union[int, str],
        device_type: str,
        index_on_page: int,
    ) -> str:
        """
        Форматирует позиционное обозначение прибора по правилу:
        <page_number><device_type><device_number_on_that_page>
        Например: 1000QM1, 1000U1, 1010K1, 1020SQ3.
        """
        code = get_device_type_code(device_type)
        return f"{page_number}{code}{int(index_on_page)}"

    def format_wire_number(
        self,
        page_number: Union[int, str],
        wire_index: int,
    ) -> str:
        """
        Форматирует маркировку провода по правилу:
        <page_number><wire_number_on_that_page> (начиная с 00 с шагом +05).
        Например: 100000, 100005, 100010, 100015...
        """
        offset = int(wire_index) * self.wire_step
        return f"{page_number}{offset:02d}"

    def auto_number_devices_on_page(
        self,
        page_number: Union[int, str],
        symbols: Sequence[Symbol],
        update_symbols: bool = True,
    ) -> Dict[Symbol, str]:
        """
        Автоматически присваивает позиционные обозначения приборам на странице
        в порядке слева направо (по возрастанию координаты X).
        
        :param page_number: Номер текущего листа (напр. 1000).
        :param symbols: Список символов на листе.
        :param update_symbols: Обновлять ли атрибут symbol.refdes.
        :return: Словарь сопоставления {symbol: new_tag}.
        """
        # Исключаем вспомогательные символы (напр. межстраничные стрелки)
        from eldraw.frames.multipage import OffPageConnector
        eligible_symbols = [
            s for s in symbols
            if not isinstance(s, OffPageConnector)
        ]

        # Сортируем строго слева направо (по возрастанию X)
        sorted_symbols = sorted(
            eligible_symbols,
            key=lambda s: (s.position.x if s.position is not None else 0.0,
                           -(s.position.y if s.position is not None else 0.0)),
        )

        counts_by_type: Dict[str, int] = {}
        assigned_tags: Dict[Symbol, str] = {}

        for sym in sorted_symbols:
            dev_type = get_device_type_code(sym)
            counts_by_type[dev_type] = counts_by_type.get(dev_type, 0) + 1
            idx = counts_by_type[dev_type]
            tag = self.format_device_tag(page_number, dev_type, idx)
            assigned_tags[sym] = tag
            if update_symbols:
                sym.refdes = tag

        return assigned_tags

    def auto_number_wires_on_page(
        self,
        page_number: Union[int, str],
        wires: Sequence[Any],
        update_wires: bool = True,
    ) -> List[str]:
        """
        Автоматически маркирует провода на странице: <page_number><00, 05, 10, 15...>.
        
        :param page_number: Номер листа.
        :param wires: Список сегментов проводов.
        :param update_wires: Присваивать ли имя wire.name.
        :return: Список присвоенных номеров проводов.
        """
        wire_names = []
        for i, w in enumerate(wires):
            name = self.format_wire_number(page_number, i)
            wire_names.append(name)
            if update_wires and hasattr(w, "name"):
                w.name = name
        return wire_names

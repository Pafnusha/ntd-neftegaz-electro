"""Семантическая инженерная модель данных ElDraw (Domain Model).

Реализует спецификацию docs/architecture/domain_model.md:
- Port: физический или логический контакт
- DeviceFunction: логическая функция аппарата
- Device: физический аппарат со свойствами и перечнем функций
- Net: эквипотенциальная сеть связности
- Wire: физический графический сегмент провода
- CrossReference: перекрестная ссылка Лист.Колонка
- TerminalStrip: клеммный ряд / колодка
- DeviceRegistry: семантический реестр устройств и автоматический кросс-референс резолвер
"""

from __future__ import annotations
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple, Union

from eldraw.core.grid import Point
from eldraw.frames.multipage import ColumnGrid, OffPageConnector
from eldraw.symbols.automation_advanced import (
    ChangeoverContact,
    IntermediateRelayCoil,
)
from eldraw.symbols.base import Symbol
from eldraw.symbols.drives import VFDControlUnit, VFDPowerUnit
from eldraw.symbols.automation import NCContact, NOContact


@dataclass
class Port:
    """Физический или логический вывод аппарата / клеммы."""
    id: str                                  # '1', '2', 'A1', 'A2', '13', '14', 'U1'
    designation: str = ""                    # Маркировка на корпусе
    signal_type: str = "power"               # 'power', 'control-dc', 'control-ac', 'analog', 'comm'
    voltage_class: str = ""                  # '400VAC', '230VAC', '24VDC', '0VDC', 'PE'
    direction: str = "passive"               # 'in', 'out', 'passive', 'bidirectional'


@dataclass
class DeviceFunction:
    """Логическая инженерная функция физического аппарата."""
    id: str                                  # 'power', 'coil', 'aux-no-1', 'di-card'
    function_type: str                       # 'power-contacts', 'coil', 'aux-no', 'aux-nc', 'changeover', 'vfd-power', 'vfd-control', etc.
    ports: List[Port] = field(default_factory=list)
    symbol: Optional[Symbol] = None
    sheet_number: str = ""
    column: Optional[int] = None

    @property
    def location_ref(self) -> str:
        """Возвращает форматированную ссылку вида Лист.Колонка (напр. '8038.3')."""
        if self.sheet_number and self.column is not None:
            return f"{self.sheet_number}.{self.column}"
        return self.sheet_number or ""


@dataclass
class Device:
    """Физическое устройство / аппарат промышленной автоматики."""
    tag: str                                 # Позиционное обозначение: 'QM1', 'KM1', 'U1', 'A1'
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    device_type: str = ""                    # 'vfd', 'contactor', 'breaker', 'plc', 'relay', 'safety_relay'
    manufacturer: str = ""                   # 'Siemens', 'Schneider', 'Finder'
    article: str = ""                        # Заказной код / каталожный номер
    description: str = ""                    # 'Главный привод каретки'
    location: str = "=QG"                    # Шкаф или технологический узел
    functions: List[DeviceFunction] = field(default_factory=list)

    def add_function(self, func: DeviceFunction) -> DeviceFunction:
        self.functions.append(func)
        return func

    def get_function(self, func_id: str) -> Optional[DeviceFunction]:
        for f in self.functions:
            if f.id == func_id:
                return f
        return None


@dataclass
class Net:
    """Электрическая сеть логической связности (Net != Wire)."""
    name: str                                # 'L1', 'L2', '+24V', '0V', '8038_W1'
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    potential: str = ""                      # '400VAC', '24VDC', '0VDC', 'PE', 'SIGNAL'
    terminals: List[str] = field(default_factory=list)  # ['QM1:2', 'U1:U1']
    is_cross_sheet: bool = False

    def add_terminal(self, term_ref: str) -> None:
        if term_ref not in self.terminals:
            self.terminals.append(term_ref)


@dataclass
class Wire:
    """Геометрический сегмент проводника на конкретном листе чертежа."""
    net_name: str
    start_point: Point
    end_point: Point
    sheet_number: str
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    waypoints: List[Point] = field(default_factory=list)
    wire_type: str = ""                      # 'H07V-K 1.5mm2 Nero'


@dataclass
class CrossReference:
    """Перекрестная ссылка между листами и колонками (Sheet.Column)."""
    target_sheet: str
    target_column: int
    label: str = ""

    def format(self, prefix: str = "") -> str:
        return f"{prefix}{self.target_sheet}.{self.target_column}"


@dataclass
class TerminalStrip:
    """Клеммный ряд / колодка шкафа."""
    tag: str                                 # 'XT1', 'XA1'
    location: str = "=QG"
    description: str = ""
    terminals: List[str] = field(default_factory=list)

    def add_terminal(self, term_no: str) -> None:
        if term_no not in self.terminals:
            self.terminals.append(term_no)


class DeviceRegistry:
    """
    Семантический реестр устройств, цепей и перекрестных ссылок проекта.
    
    Осуществляет:
    1. Учет физических аппаратов (Device) и их графических представлений (Symbol);
    2. Расчет координат колонок (Sheet.Column) по координатной сетке ColumnGrid;
    3. Автоматическое связывание межстраничных переходов (OffPageConnector);
    4. Автоматическое заполнение таблиц контактов под катушками реле и контакторов (Contact Cross-Reference Table);
    5. Автоматическую взаимную адресацию силовых и управляющих блоков ПЧ (VFD).
    """

    def __init__(self):
        self.devices: Dict[str, Device] = {}
        self.nets: Dict[str, Net] = {}
        self.grids: Dict[str, ColumnGrid] = {}
        self.placed_symbols: List[Tuple[str, Symbol, int]] = []   # (sheet_no, symbol, col)
        self.placed_opcs: List[Tuple[str, OffPageConnector, int]] = []  # (sheet_no, opc, col)

    def register_device(self, device: Device) -> Device:
        """Регистрирует физический аппарат в проекте."""
        self.devices[device.tag] = device
        return device

    def get_device(self, tag: str) -> Optional[Device]:
        return self.devices.get(tag)

    def register_grid(self, sheet_no: str, grid: ColumnGrid) -> None:
        """Регистрирует координатную сетку колонок для указанного листа."""
        self.grids[sheet_no] = grid

    def get_grid(self, sheet_no: str) -> ColumnGrid:
        """Возвращает сетку колонок листа (по умолчанию стандартная 12-колоночная А3)."""
        return self.grids.get(sheet_no, ColumnGrid())

    def register_symbol(
        self,
        sheet_no: str,
        symbol: Symbol,
        grid: Optional[ColumnGrid] = None,
    ) -> Tuple[str, int]:
        """
        Регистрирует размещенный символ на листе, вычисляет номер колонки
        и связывает его с устройством в реестре.
        """
        g = grid or self.get_grid(sheet_no)
        col = 1
        if symbol.position is not None:
            col = g.get_column_by_x(symbol.position.x)

        # Регистрация в списке размещенных символов
        self.placed_symbols.append((sheet_no, symbol, col))

        # Если это межстраничный переход (OffPageConnector)
        if isinstance(symbol, OffPageConnector):
            self.placed_opcs.append((sheet_no, symbol, col))

        # Если позиционное обозначение соотносится с устройством
        base_tag = symbol.refdes.split(".")[0].split(":")[0]
        device = self.devices.get(base_tag)
        if device is not None:
            func = DeviceFunction(
                id=symbol.refdes,
                function_type=symbol.__class__.__name__,
                symbol=symbol,
                sheet_number=sheet_no,
                column=col,
            )
            device.add_function(func)

        return (sheet_no, col)

    def register_net(self, net: Net) -> Net:
        """Регистрирует логическую электрическую цепь."""
        self.nets[net.name] = net
        return net

    def resolve_cross_references(self, project: Optional[Any] = None) -> Dict[str, int]:
        """
        Автоматически рассчитывает и разрешает все перекрестные ссылки проекта.
        
        :param project: MultiPageProject (если передан, предварительно регистрирует
                        все символы со всех добавленных листов).
        :return: Словарь со статистикой разрешенных ссылок.
        """
        if project is not None:
            # Синхронизируем сетки и символы со всех страниц проекта
            for sheet_no, canvas in project.pages.items():
                grid = project.grids.get(sheet_no) or self.get_grid(sheet_no)
                self.register_grid(sheet_no, grid)
                for sym in canvas.symbols:
                    # Проверяем, не был ли символ уже зарегистрирован на этом листе
                    if not any(s is sym for s_no, s, _ in self.placed_symbols):
                        self.register_symbol(sheet_no, sym, grid)

        stats = {
            "opc_resolved": 0,
            "coils_resolved": 0,
            "vfd_resolved": 0,
        }

        # 1. Разрешение межстраничных переходов (OffPageConnector)
        # Группируем по net_name
        opcs_by_net: Dict[str, List[Tuple[str, OffPageConnector, int]]] = {}
        for sheet_no, opc, col in self.placed_opcs:
            if opc.net_name:
                opcs_by_net.setdefault(opc.net_name, []).append((sheet_no, opc, col))

        for net_name, opc_list in opcs_by_net.items():
            if len(opc_list) >= 2:
                # Ищем пару: выходящий (right) и входящий (left)
                rights = [item for item in opc_list if item[1].direction == "right"]
                lefts = [item for item in opc_list if item[1].direction == "left"]

                for r_sh, r_opc, r_col in rights:
                    for l_sh, l_opc, l_col in lefts:
                        if r_sh != l_sh:
                            # r_opc указывает на l_opc
                            r_opc.target_ref = f"{l_sh}.{l_col}"
                            r_opc.rebuild()
                            # l_opc указывает на r_opc
                            l_opc.target_ref = f"{r_sh}.{r_col}"
                            l_opc.rebuild()
                            stats["opc_resolved"] += 2
                            break

        # 2. Разрешение таблиц контактов реле и пускателей (Contact Cross-Reference Table)
        coils = [
            (sh, sym, col)
            for sh, sym, col in self.placed_symbols
            if isinstance(sym, IntermediateRelayCoil)
        ]

        contacts = [
            (sh, sym, col)
            for sh, sym, col in self.placed_symbols
            if isinstance(sym, (NOContact, NCContact, ChangeoverContact))
        ]

        for coil_sh, coil, coil_col in coils:
            coil_tag = coil.refdes
            matched_contacts = []
            for c_sh, c_sym, c_col in contacts:
                c_base = c_sym.refdes.split(".")[0].split(":")[0]
                if c_base == coil_tag:
                    contact_type = "NO"
                    if isinstance(c_sym, NCContact):
                        contact_type = "NC"
                    elif isinstance(c_sym, ChangeoverContact):
                        contact_type = "CO"
                    matched_contacts.append((contact_type, f"{c_sh}.{c_col}"))

            if matched_contacts:
                coil.crossrefs = matched_contacts
                coil.rebuild()
                stats["coils_resolved"] += 1

        # 3. Разрешение связей силового и управляющего блоков ПЧ (VFD)
        vfd_power_units = [
            (sh, sym, col)
            for sh, sym, col in self.placed_symbols
            if isinstance(sym, VFDPowerUnit)
        ]
        vfd_ctrl_units = [
            (sh, sym, col)
            for sh, sym, col in self.placed_symbols
            if isinstance(sym, VFDControlUnit)
        ]

        for p_sh, p_sym, p_col in vfd_power_units:
            p_base = p_sym.refdes.split(".")[0]
            for c_sh, c_sym, c_col in vfd_ctrl_units:
                c_base = c_sym.refdes.split(".")[0]
                if p_base == c_base or p_sym.refdes == c_sym.refdes:
                    p_sym.control_unit_ref = f"{c_sh}.{c_col}"
                    p_sym.rebuild()
                    c_sym.power_unit_ref = f"{p_sh}.{p_col}"
                    c_sym.rebuild()
                    stats["vfd_resolved"] += 1

        return stats

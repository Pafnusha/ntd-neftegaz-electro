"""Управление узлами соединений (Junction Dots) и автоматическая детекция Т-образных врезок."""

from __future__ import annotations
from typing import TYPE_CHECKING, List, Set, Tuple, Union

from eldraw.core.grid import Point
from eldraw.core.layers import StandardLayers
from eldraw.routing.wire import Wire

if TYPE_CHECKING:
    from eldraw.core.canvas import SchematicCanvas


class JunctionManager:
    """Менеджер узловых точек электрических соединений по ГОСТ 2.702-2011."""

    def __init__(self, dot_diameter: float = 1.4):
        """
        :param dot_diameter: Диаметр закрашенной точки узла в мм (1.2 - 1.5 мм по ГОСТ).
        """
        self.dot_diameter = dot_diameter
        self.explicit_junctions: List[Point] = []
        self.rendered_junctions: Set[Tuple[float, float]] = set()

    def add_junction(self, pt: Union[Point, Tuple[float, float]]) -> Point:
        """Регистрирует явную точку узлового соединения."""
        p = pt if isinstance(pt, Point) else Point(float(pt[0]), float(pt[1]))
        self.explicit_junctions.append(p)
        return p

    def auto_detect_junctions(self, wires: List[Wire]) -> List[Point]:
        """
        Автоматически находит все Т-образные врезки проводников.
        Т-образный стык возникает, когда конец одного провода упирается
        внутрь прямолинейного сегмента другого провода.
        """
        detected: List[Point] = []

        for i, wire_a in enumerate(wires):
            # Проверяем оба конца провода wire_a
            endpoints = [wire_a.start, wire_a.end]

            for ep in endpoints:
                for j, wire_b in enumerate(wires):
                    if i == j:
                        continue
                    # Если конечная точка провода А лежит строго внутри сегмента провода Б
                    if wire_b.contains_point_interior(ep):
                        detected.append(ep)
                        break

        return detected

    def draw_all_junctions(self, canvas: SchematicCanvas, wires: List[Wire]) -> None:
        """
        Находит все узлы (явные + автоматически обнаруженные Т-стыки)
        и отрисовывает их на слое EL_WIRES.
        """
        # Объединяем явные точки и обнаруженные Т-стыки
        all_pts = list(self.explicit_junctions) + self.auto_detect_junctions(wires)

        for pt in all_pts:
            coord_key = (round(pt.x, 2), round(pt.y, 2))
            # Избегаем повторной отрисовки точки в тех же координатах
            if coord_key not in self.rendered_junctions:
                canvas.add_junction(pt, diameter=self.dot_diameter, layer=StandardLayers.WIRES.name, snap=False)
                self.rendered_junctions.add(coord_key)

"""Ортогональный манхэттенский роутер для прокладки линий электрической связи."""

from __future__ import annotations
from typing import List, Optional, Tuple, Union

from eldraw.core.grid import Point
from eldraw.routing.wire import Wire


class OrthogonalRouter:
    """Генератор ортогональных трасс между точками схемы."""

    @classmethod
    def route(
        cls,
        p1: Point,
        p2: Point,
        strategy: str = "auto",
        dir1: Optional[Tuple[float, float]] = None,
        dir2: Optional[Tuple[float, float]] = None,
        waypoints: Optional[List[Point]] = None,
    ) -> List[Point]:
        """
        Прокладывает ортогональную ломаную линию между точками p1 и p2.
        :param p1: Начальная точка.
        :param p2: Конечная точка.
        :param strategy: "auto", "hv" (сначала гор.), "vh" (сначала верт.).
        :param dir1: Вектор нормали начального вывода.
        :param dir2: Вектор нормали конечного вывода.
        :param waypoints: Список промежуточных опорных точек.
        :return: Упорядоченный список точек трассы.
        """
        if waypoints:
            full_pts: List[Point] = [p1]
            cur = p1
            for wp in waypoints:
                sub_pts = cls._route_simple(cur, wp, strategy="auto")
                full_pts.extend(sub_pts[1:])
                cur = wp
            sub_pts = cls._route_simple(cur, p2, strategy="auto")
            full_pts.extend(sub_pts[1:])
            return cls.simplify(full_pts)

        pts = cls._route_simple(p1, p2, strategy=strategy, dir1=dir1, dir2=dir2)
        return cls.simplify(pts)

    @classmethod
    def _route_simple(
        cls,
        p1: Point,
        p2: Point,
        strategy: str = "auto",
        dir1: Optional[Tuple[float, float]] = None,
        dir2: Optional[Tuple[float, float]] = None,
    ) -> List[Point]:
        # Если точки совпадают
        if p1.distance_to(p2) < 1e-4:
            return [p1]

        # Прямая горизонтальная или вертикальная линия
        if abs(p1.x - p2.x) < 1e-4 or abs(p1.y - p2.y) < 1e-4:
            return [p1, p2]

        strat = strategy.lower()

        if strat == "auto":
            # Выбор стратегии на основе нормалей выводов:
            # Если вывод направлен вверх/вниз (|dy| > |dx|) -> выходим вертикально (vh)
            if dir1 is not None and abs(dir1[1]) > abs(dir1[0]):
                strat = "vh"
            # Если вывод направлен влево/вправо (|dx| >= |dy|) -> выходим горизонтально (hv)
            elif dir1 is not None and abs(dir1[0]) >= abs(dir1[1]):
                strat = "hv"
            # Если задан dir2 для конечной точки:
            elif dir2 is not None and abs(dir2[1]) > abs(dir2[0]):
                # В конечную точку нужно войти вертикально -> значит, первый сегмент горизонтальный
                strat = "hv"
            elif dir2 is not None and abs(dir2[0]) >= abs(dir2[1]):
                strat = "vh"
            else:
                strat = "hv"

        if strat == "hv":
            # Сначала горизонтально: p1 -> (p2.x, p1.y) -> p2
            corner = Point(p2.x, p1.y)
            return [p1, corner, p2]
        else:
            # Сначала вертикально (vh): p1 -> (p1.x, p2.y) -> p2
            corner = Point(p1.x, p2.y)
            return [p1, corner, p2]

    @classmethod
    def simplify(cls, points: List[Point], tol: float = 1e-3) -> List[Point]:
        """
        Устраняет коллинеарные промежуточные точки (объединяет последовательные
        параллельные сегменты в один).
        """
        if len(points) <= 2:
            return points

        cleaned: List[Point] = [points[0]]
        for p in points[1:]:
            if p.distance_to(cleaned[-1]) > tol:
                cleaned.append(p)

        if len(cleaned) <= 2:
            return cleaned

        result: List[Point] = [cleaned[0]]
        for i in range(1, len(cleaned) - 1):
            p_prev = result[-1]
            p_curr = cleaned[i]
            p_next = cleaned[i + 1]

            # Проверяем, лежат ли три точки на одной горизонтали или вертикали
            is_horiz = abs(p_prev.y - p_curr.y) <= tol and abs(p_curr.y - p_next.y) <= tol
            is_vert = abs(p_prev.x - p_curr.x) <= tol and abs(p_curr.x - p_next.x) <= tol

            if not (is_horiz or is_vert):
                result.append(p_curr)

        result.append(cleaned[-1])
        return result

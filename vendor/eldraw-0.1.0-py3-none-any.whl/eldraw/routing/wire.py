"""Представление линии электрической связи (провода) на схеме."""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, List, Tuple, Union

from eldraw.core.grid import Point
from eldraw.core.layers import StandardLayers

if TYPE_CHECKING:
    from eldraw.core.canvas import SchematicCanvas


@dataclass
class Wire:
    """Ортогональная линия электрической связи (провод/цепь)."""

    points: List[Point]
    name: str = ""
    layer: str = StandardLayers.WIRES.name
    lineweight: int = 50  # 0.50 мм по ГОСТ 2.702

    def __post_init__(self):
        if len(self.points) < 2:
            raise ValueError("Провод должен содержать как минимум 2 точки.")

        # Очистка от последовательных дубликатов точек
        cleaned: List[Point] = [self.points[0]]
        for p in self.points[1:]:
            if p.distance_to(cleaned[-1]) > 1e-4:
                cleaned.append(p)
        self.points = cleaned

    @property
    def start(self) -> Point:
        """Начальная точка провода."""
        return self.points[0]

    @property
    def end(self) -> Point:
        """Конечная точка провода."""
        return self.points[-1]

    @property
    def segments(self) -> List[Tuple[Point, Point]]:
        """Список прямолинейных отрезков провода."""
        return [(self.points[i], self.points[i + 1]) for i in range(len(self.points) - 1)]

    def contains_point(self, pt: Point, tol: float = 1e-3) -> bool:
        """Проверяет, лежит ли точка на каком-либо отрезке данного провода."""
        for p1, p2 in self.segments:
            if self._point_on_segment(pt, p1, p2, tol=tol):
                return True
        return False

    def contains_point_interior(self, pt: Point, tol: float = 1e-3) -> bool:
        """
        Проверяет, лежит ли точка строго внутри какого-либо отрезка
        (исключая его концы). Используется для детекции Т-образных врезок.
        """
        for p1, p2 in self.segments:
            if self._point_on_segment(pt, p1, p2, tol=tol):
                # Проверяем, что точка не совпадает с концами отрезка
                if pt.distance_to(p1) > tol and pt.distance_to(p2) > tol:
                    return True
        return False

    @staticmethod
    def _point_on_segment(pt: Point, p1: Point, p2: Point, tol: float = 1e-3) -> bool:
        """Проверка принадлежности точки ортогональному отрезку."""
        # Горизонтальный отрезок
        if abs(p1.y - p2.y) <= tol:
            if abs(pt.y - p1.y) <= tol:
                min_x = min(p1.x, p2.x) - tol
                max_x = max(p1.x, p2.x) + tol
                return min_x <= pt.x <= max_x
        # Вертикальный отрезок
        elif abs(p1.x - p2.x) <= tol:
            if abs(pt.x - p1.x) <= tol:
                min_y = min(p1.y, p2.y) - tol
                max_y = max(p1.y, p2.y) + tol
                return min_y <= pt.y <= max_y
        # Произвольный отрезок
        else:
            dist = pt.distance_to(p1) + pt.distance_to(p2)
            seg_len = p1.distance_to(p2)
            return abs(dist - seg_len) <= tol

        return False

    def draw(self, canvas: SchematicCanvas) -> None:
        """Вычерчивает полилинию провода на холсте."""
        pts = [p.to_tuple() for p in self.points]
        canvas.msp.add_lwpolyline(
            pts,
            close=False,
            dxfattribs={
                "layer": self.layer,
                "lineweight": self.lineweight,
            },
        )

"""Базовый холст чертежа электрической схемы на основе ezdxf."""

from __future__ import annotations
from pathlib import Path
from typing import Union, Tuple, List, Optional
import ezdxf
from ezdxf.document import Drawing
from ezdxf.layouts import Modelspace

from eldraw.core.grid import Grid, Point
from eldraw.core.layers import StandardLayers
from eldraw.core.styles import StandardStyles


class SchematicCanvas:
    """Холст схемы с поддержкой модульной координатной сетки, слоёв ГОСТ и экспорта."""

    def __init__(
        self,
        step: float = 5.0,
        dxf_version: str = "R2010",
        sheet: Optional[Any] = None,
    ):
        """
        Инициализация холста схемы.
        :param step: Шаг модульной сетки в миллиметрах (по умолчанию 5.0 мм).
        :param dxf_version: Версия DXF (R2010 рекомендуется для широкой совместимости).
        :param sheet: Чертёжный лист (Sheet) по ГОСТ 2.104 с рамкой и штампом.
        """
        self.grid = Grid(step=step)
        self.dxf_version = dxf_version
        self.sheet = sheet

        # Создание нового DXF документа
        self.doc: Drawing = ezdxf.new(dxf_version, setup=True)

        # Настройка единиц чертежа: $INSUNITS = 4 (Миллиметры), $MEASUREMENT = 1 (Метрическая)
        self.doc.header["$INSUNITS"] = 4
        self.doc.header["$MEASUREMENT"] = 1
        self.doc.header["$LTSCALE"] = 1.0

        # Регистрация слоев и шрифтов
        StandardLayers.setup_layers(self.doc)
        StandardStyles.setup_styles(self.doc)

        # Пространство модели (Modelspace) для размещения схемы
        self.msp: Modelspace = self.doc.modelspace()

        # Список размещенных компонентов схемы
        self.symbols: List[Any] = []

        # Список линий связи (проводов)
        self.wires: List[Any] = []

        # Список текстовых элементов схемы
        self.texts: List[Any] = []

        # Менеджер узлов соединений (точек 1.4 мм)
        from eldraw.routing.junction import JunctionManager
        self.junction_manager = JunctionManager(dot_diameter=1.4)

        # Если передан лист с рамкой, сразу вычерчиваем его
        if self.sheet is not None:
            self.sheet.draw(self)

    def set_sheet(self, sheet: Any) -> None:
        """Устанавливает и вычерчивает рамку листа со штампом."""
        self.sheet = sheet
        sheet.draw(self)

    def add_symbol(
        self,
        symbol: Any,
        at: Union[Point, Tuple[float, float]],
        rotation: float = 0.0,
        label_pos: Optional[str] = None,
        label_offset: Optional[Tuple[float, float]] = None,
        snap: bool = True,
    ) -> Any:
        """
        Размещает условно-графическое обозначение (УГО) на схеме.
        :param symbol: Экземпляр Symbol (например: CircuitBreaker, Resistor).
        :param at: Координаты точки вставки (автоматически квантуются к сетке 5 мм).
        :param rotation: Угол поворота в градусах (0, 90, 180, 270).
        :param label_pos: Расположение подписи ("right", "left", "top", "bottom").
        :param label_offset: Точное смещение подписи (dx, dy).
        :param snap: Выравнивать ли точку вставки по сетке.
        :return: Размещенный компонент symbol.
        """
        symbol.place(
            self,
            at=at,
            rotation=rotation,
            label_pos=label_pos,
            label_offset=label_offset,
            snap=snap,
        )
        self.symbols.append(symbol)
        return symbol

    def connect(
        self,
        start: Any,
        end: Any,
        waypoints: Optional[List[Union[Point, Tuple[float, float]]]] = None,
        routing: str = "auto",
        add_junction_start: bool = False,
        add_junction_end: bool = False,
        name: str = "",
        lineweight: int = 50,
    ) -> Any:
        """
        Прокладывает ортогональную линию электрической связи (провод) между двумя точками/выводами.
        :param start: Начальная точка: Point, кортеж (x, y) или Pin (например: qf1.pin("out")).
        :param end: Конечная точка: Point, кортеж (x, y) или Pin (например: km1.pin("in")).
        :param waypoints: Список промежуточных опорных точек обхода.
        :param routing: Стратегия трассировки: "auto", "hv" (сначала гор.), "vh" (сначала верт.).
        :param add_junction_start: Принудительно установить точку узла в начале провода.
        :param add_junction_end: Принудительно установить точку узла в конце провода.
        :param name: Маркировка цепи / провода.
        :param lineweight: Толщина линии в сотых долях мм (по умолчанию 50 = 0.50 мм).
        :return: Созданный объект Wire.
        """
        from eldraw.routing.router import OrthogonalRouter
        from eldraw.routing.wire import Wire

        p1, dir1 = self._resolve_endpoint(start)
        p2, dir2 = self._resolve_endpoint(end)

        wps = [self._to_point(w, snap=True) for w in waypoints] if waypoints else None

        points = OrthogonalRouter.route(
            p1=p1,
            p2=p2,
            strategy=routing,
            dir1=dir1,
            dir2=dir2,
            waypoints=wps,
        )

        wire = Wire(points=points, name=name, lineweight=lineweight)
        wire.draw(self)
        self.wires.append(wire)

        if add_junction_start:
            self.junction_manager.add_junction(wire.start)
        if add_junction_end:
            self.junction_manager.add_junction(wire.end)

        return wire

    def add_wire(
        self,
        points: Sequence[Union[Point, Tuple[float, float]]],
        name: str = "",
        lineweight: int = 50,
    ) -> Any:
        """
        Добавляет проводник напрямую по указанному списку точек.
        """
        from eldraw.routing.wire import Wire

        pts = [self._to_point(p, snap=True) for p in points]
        wire = Wire(points=pts, name=name, lineweight=lineweight)
        wire.draw(self)
        self.wires.append(wire)
        return wire

    def _resolve_endpoint(self, target: Any) -> Tuple[Point, Optional[Tuple[float, float]]]:
        """Определяет координаты и вектор нормали конечной точки связи."""
        # Если передан Point
        if isinstance(target, Point):
            return self.grid.snap(target), None
        # Если передан кортеж (x, y)
        if isinstance(target, (tuple, list)):
            return self.grid.snap(Point(float(target[0]), float(target[1]))), None
        # Если передан Pin (имеет get_world_pos или атрибуты)
        if hasattr(target, "local_pos") and hasattr(target, "direction"):
            # Если это Pin, но не привязан к Symbol, используем local_pos
            return self.grid.snap(target.local_pos), target.direction
        raise TypeError(f"Невозможно разрешить точку подключения из объекта: {target}")

    def finalize_connections(self) -> None:
        """Отрисовывает все точки узловых соединений (включая авто-детекцию Т-стыков)."""
        self.junction_manager.draw_all_junctions(self, self.wires)

    def get_bom(self, group_identical: bool = True) -> List[Any]:
        """
        Формирует перечень элементов схемы по ГОСТ 2.702-2011.
        :param group_identical: Объединять ли однотипные последовательные аппараты (например: R1...R3).
        :return: Список объектов BOMItem, отсортированных по стандарту.
        """
        from eldraw.bom.parser import extract_bom
        return extract_bom(self.symbols, group_identical=group_identical)

    def add_pe3_table(
        self,
        at: Optional[Union[Point, Tuple[float, float]]] = None,
        group_identical: bool = True,
    ) -> Point:
        """
        Автоматически генерирует и вычерчивает таблицу перечня элементов (ПЭ3)
        по форме 2 ГОСТ 2.702 над штампом листа.
        :param at: Координаты левого нижнего угла таблицы. Если None — над штампом листа.
        :param group_identical: Группировать ли однотипные аппараты.
        :return: Point левого нижнего угла таблицы.
        """
        from eldraw.bom.pe3 import draw_pe3_table
        items = self.get_bom(group_identical=group_identical)
        return draw_pe3_table(self, items, at=at)

    def export_bom_csv(
        self,
        filepath: Union[str, Path],
        group_identical: bool = True,
        delimiter: str = ";",
    ) -> Path:
        """Экспортирует перечень элементов в CSV-файл для Excel."""
        from eldraw.bom.export import export_bom_csv
        items = self.get_bom(group_identical=group_identical)
        return export_bom_csv(items, filepath=filepath, delimiter=delimiter)

    def add_load_table(
        self,
        feeders: List[Any],
        header_x: float = 25.0,
        header_width: float = 45.0,
        y_bottom: float = 12.0,
    ) -> None:
        """
        Вычерчивает стандартизированную таблицу расчета нагрузок под схемой щита (ГОСТ 2.702 / РТМ 36.18).
        :param feeders: Список объектов LoadFeeder с параметрами групп.
        :param header_x: Координата X левого края таблицы.
        :param header_width: Ширина колонки наименований строк.
        :param y_bottom: Нижняя граница таблицы по оси Y.
        """
        from eldraw.frames.load_table import LoadTable
        LoadTable.draw(
            self,
            feeders=feeders,
            header_x=header_x,
            header_width=header_width,
            y_bottom=y_bottom,
        )

    def run_erc(
        self,
        check_unconnected: bool = True,
        check_attributes: bool = True,
    ) -> Any:
        """
        Выполняет комплексную проверку схемы (ERC - Electrical Rules Check).
        :param check_unconnected: Проверять ли наличие неподключенных выводов.
        :param check_attributes: Проверять ли заполненность реквизитов аппаратов.
        :return: ERCReport с обнаруженными замечаниями и ошибками.
        """
        from eldraw.validation.erc import ERCChecker
        checker = ERCChecker(self)
        return checker.run_all(
            check_unconnected=check_unconnected,
            check_attributes=check_attributes,
        )

    def _to_point(self, pt: Union[Point, Tuple[float, float]], snap: bool = True) -> Point:
        """Вспомогательное преобразование кортежа/точки с опциональным квантованием по сетке."""
        if snap:
            return self.grid.snap(pt)
        if isinstance(pt, Point):
            return pt
        return Point(float(pt[0]), float(pt[1]))

    def add_line(
        self,
        start: Union[Point, Tuple[float, float]],
        end: Union[Point, Tuple[float, float]],
        layer: str = StandardLayers.WIRES.name,
        lineweight: Optional[int] = None,
        snap: bool = True,
    ):
        """
        Добавляет отрезок линии.
        :param start: Начальная точка.
        :param end: Конечная точка.
        :param layer: Слой.
        :param lineweight: Толщина линии (в сотых долях мм), если None - по слою.
        :param snap: Выравнивать ли точки по сетке.
        """
        p1 = self._to_point(start, snap=snap)
        p2 = self._to_point(end, snap=snap)

        attribs = {"layer": layer}
        if lineweight is not None:
            attribs["lineweight"] = lineweight

        return self.msp.add_line(p1.to_tuple(), p2.to_tuple(), dxfattribs=attribs)

    def add_polyline(
        self,
        points: List[Union[Point, Tuple[float, float]]],
        layer: str = StandardLayers.WIRES.name,
        is_closed: bool = False,
        lineweight: Optional[int] = None,
        snap: bool = True,
    ):
        """Добавляет 2D-полилинию по списку точек."""
        pts = [self._to_point(p, snap=snap).to_tuple() for p in points]
        attribs = {"layer": layer}
        if lineweight is not None:
            attribs["lineweight"] = lineweight

        return self.msp.add_lwpolyline(pts, close=is_closed, dxfattribs=attribs)

    def add_rect(
        self,
        p1: Union[Point, Tuple[float, float]],
        p2: Union[Point, Tuple[float, float]],
        layer: str = StandardLayers.SYMBOLS.name,
        lineweight: Optional[int] = None,
        snap: bool = True,
    ):
        """Добавляет прямоугольник по двум противоположным углам."""
        pt1 = self._to_point(p1, snap=snap)
        pt2 = self._to_point(p2, snap=snap)

        corners = [
            (pt1.x, pt1.y),
            (pt2.x, pt1.y),
            (pt2.x, pt2.y),
            (pt1.x, pt2.y),
        ]
        return self.add_polyline(corners, layer=layer, is_closed=True, lineweight=lineweight, snap=False)

    def add_rectangle(
        self,
        p1: Union[Point, Tuple[float, float]],
        p2: Union[Point, Tuple[float, float]],
        layer: str = StandardLayers.SYMBOLS.name,
        lineweight: Optional[int] = None,
        snap: bool = True,
    ):
        """Алиас для add_rect."""
        return self.add_rect(p1, p2, layer=layer, lineweight=lineweight, snap=snap)

    def add_circle(
        self,
        center: Union[Point, Tuple[float, float]],
        radius: float,
        layer: str = StandardLayers.SYMBOLS.name,
        lineweight: Optional[int] = None,
        snap: bool = True,
    ):
        """Добавляет окружность."""
        c = self._to_point(center, snap=snap)
        attribs = {"layer": layer}
        if lineweight is not None:
            attribs["lineweight"] = lineweight

        return self.msp.add_circle(c.to_tuple(), radius=radius, dxfattribs=attribs)

    def add_junction(
        self,
        center: Union[Point, Tuple[float, float]],
        diameter: float = 1.2,
        layer: str = StandardLayers.WIRES.name,
        snap: bool = True,
    ):
        """
        Добавляет точку электрического соединения (закрашенный узел цепи d=1.0-1.5 мм).
        Реализуется через закрашенную штриховку HATCH или плотную полилинию-круг.
        """
        c = self._to_point(center, snap=snap)
        radius = diameter / 2.0

        # В DXF закрашенная точка создается через SOLID HATCH
        hatch = self.msp.add_hatch(color=StandardLayers.WIRES.color, dxfattribs={"layer": layer})
        edge_path = hatch.paths.add_edge_path()
        # Добавляем 2 дуги по 180 градусов для полного круга
        edge_path.add_arc(c.to_tuple(), radius=radius, start_angle=0, end_angle=360)
        return hatch

    def add_text(
        self,
        text: str,
        position: Union[Point, Tuple[float, float]],
        height: float = StandardStyles.HEIGHT_REFDES,
        layer: str = StandardLayers.REFDES.name,
        rotation: float = 0.0,
        style: str = StandardStyles.STYLE_GOST,
        align: str = "LEFT",
        source: Optional[str] = None,
        snap: bool = False,
    ):
        """
        Добавляет однострочный текст.
        :param text: Содержимое текста.
        :param position: Точка вставки.
        :param height: Высота шрифта (по умолчанию 3.5 мм).
        :param layer: Слой текста.
        :param rotation: Угол поворота текста в градусах.
        :param style: Текстовый стиль (по умолчанию GOST_TYPE_B).
        :param align: Выравнивание текста ("LEFT", "CENTER", "RIGHT").
        :param source: Источник/компонент надписи (например, "QF1").
        :param snap: Выравнивать ли точку вставки по сетке.
        """
        p = self._to_point(position, snap=snap)
        align_upper = align.upper()
        lines = text.split("\n")

        from eldraw.core.text import TextEntity

        if len(lines) == 1:
            txt = self.msp.add_text(
                text,
                dxfattribs={
                    "layer": layer,
                    "height": height,
                    "style": style,
                    "rotation": rotation,
                },
            )

            if align_upper == "CENTER":
                txt.set_placement(p.to_tuple(), align=ezdxf.enums.TextEntityAlignment.MIDDLE_CENTER)
            elif align_upper == "RIGHT":
                txt.set_placement(p.to_tuple(), align=ezdxf.enums.TextEntityAlignment.BOTTOM_RIGHT)
            else:
                txt.set_placement(p.to_tuple(), align=ezdxf.enums.TextEntityAlignment.BOTTOM_LEFT)

            entity = TextEntity(
                text=text,
                position=p,
                height=height,
                rotation=rotation,
                layer=layer,
                style=style,
                align=align_upper,
                source=source,
            )
            self.texts.append(entity)
            return txt
        else:
            line_spacing = height * 1.6
            num_lines = len(lines)
            total_h = (num_lines - 1) * line_spacing

            created_txts = []
            for idx, line_str in enumerate(lines):
                if align_upper == "CENTER":
                    y_offset = (total_h / 2.0) - idx * line_spacing
                else:
                    y_offset = -idx * line_spacing

                line_p = Point(p.x, p.y + y_offset)
                txt = self.msp.add_text(
                    line_str,
                    dxfattribs={
                        "layer": layer,
                        "height": height,
                        "style": style,
                        "rotation": rotation,
                    },
                )
                if align_upper == "CENTER":
                    txt.set_placement(line_p.to_tuple(), align=ezdxf.enums.TextEntityAlignment.MIDDLE_CENTER)
                elif align_upper == "RIGHT":
                    txt.set_placement(line_p.to_tuple(), align=ezdxf.enums.TextEntityAlignment.BOTTOM_RIGHT)
                else:
                    txt.set_placement(line_p.to_tuple(), align=ezdxf.enums.TextEntityAlignment.BOTTOM_LEFT)

                entity = TextEntity(
                    text=line_str,
                    position=line_p,
                    height=height,
                    rotation=rotation,
                    layer=layer,
                    style=style,
                    align=align_upper,
                    source=source,
                )
                self.texts.append(entity)
                created_txts.append(txt)

            return created_txts[0]

    def save_dxf(self, filepath: Union[str, Path], audit: bool = True) -> Path:
        """Сохраняет чертёж в файл формата DXF с аудитом целостности."""
        from eldraw.export.dxf import export_dxf
        return export_dxf(self, filepath=filepath, audit=audit)

    def render_html(self, theme: str = "light") -> str:
        """SVG как строка (без записи файла) — для браузера."""
        from eldraw.export.preview import render_svg_string
        return render_svg_string(self, theme=theme)

    def render_svg(self, filepath: Union[str, Path], theme: str = "light") -> Path:
        """Рендерит чертеж в векторный формат SVG с поддержкой тем (light, dark, cad)."""
        from eldraw.export.preview import render_svg
        return render_svg(self, filepath=filepath, theme=theme)

    def render_png(self, filepath: Union[str, Path], dpi: int = 300, theme: str = "light") -> Path:
        """Рендерит чертеж в растровый формат PNG с заданным разрешением DPI."""
        from eldraw.export.preview import render_png
        return render_png(self, filepath=filepath, theme=theme, dpi=dpi)

    def render_pdf(self, filepath: Union[str, Path], theme: str = "light") -> Path:
        """Рендерит готовый векторный PDF-документ чертежа для печати."""
        from eldraw.export.preview import render_pdf
        return render_pdf(self, filepath=filepath, theme=theme)

    def export_dwg(self, filepath: Union[str, Path], version: str = "R2018") -> bool:
        """
        Экспортирует схему в формат DWG с помощью доступного внешнего конвертера.
        :return: True при успехе, False если утилиты не найдены.
        """
        from eldraw.export.dwg import convert_dxf_to_dwg
        target_path = Path(filepath)
        temp_dxf = target_path.with_suffix(".dxf")
        self.save_dxf(temp_dxf)
        return convert_dxf_to_dwg(temp_dxf, target_path, version=version)

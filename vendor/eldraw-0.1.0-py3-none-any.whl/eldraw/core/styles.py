"""Текстовые стили и высоты шрифтов по ГОСТ 2.304."""

from __future__ import annotations
from typing import Any


class StandardStyles:
    """Стандартные шрифтовые параметры по ГОСТ."""

    # Наименование стиля в DXF
    STYLE_GOST = "GOST_TYPE_B"

    # Высоты шрифта в миллиметрах
    HEIGHT_PARAMS = 2.5  # Номиналы, параметры, номера клемм, мелкие надписи
    HEIGHT_REFDES = 3.5  # Позиционные обозначения (QF1, KM1, R1, C1)
    HEIGHT_SUBTITLE = 5.0  # Заголовки функциональных групп, узлов, таблиц
    HEIGHT_TITLE = 7.0  # Заголовок схемы, марка щита

    @classmethod
    def setup_styles(cls, doc: Any) -> None:
        """Регистрирует чертёжный шрифт по ГОСТ в документе DXF."""
        if cls.STYLE_GOST not in doc.styles:
            # Создаем стиль с наклоном 15 градусов по ГОСТ 2.304
            # В AutoCAD стандартным шрифтом является ISOCPEUR или gost.shx
            doc.styles.new(
                name=cls.STYLE_GOST,
                dxfattribs={
                    "font": "isocpeur.ttf",
                    "oblique": 15.0,  # Угол наклона в градусах
                },
            )

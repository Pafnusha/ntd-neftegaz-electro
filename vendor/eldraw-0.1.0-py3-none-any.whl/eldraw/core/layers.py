"""Система слоёв электрической схемы по стандартам ГОСТ 2.702-2011."""

from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any


@dataclass(frozen=True)
class LayerDef:
    """Определение параметров слоя DXF."""

    name: str
    color: int  # Индекс цвета AutoCAD Color Index (ACI: 1=Red, 2=Yellow, 3=Green, 4=Cyan, 5=Blue, 6=Magenta, 7=White/Black, 8=Gray)
    lineweight: int  # Толщина в сотых долях мм (e.g. 50 = 0.50 мм, 25 = 0.25 мм, 70 = 0.70 мм)
    description: str
    linetype: str = "Continuous"


class StandardLayers:
    """Стандартные слои схем по ГОСТ."""

    # Линии электрической связи (провода, фазы, шины) - основная линия 0.50 мм
    WIRES = LayerDef(
        name="EL_WIRES",
        color=1,  # Красный
        lineweight=50,
        description="Линии электрической связи, шины и провода",
    )

    # Графика условно-графических обозначений (УГО) - основная линия 0.50 мм
    SYMBOLS = LayerDef(
        name="EL_SYMBOLS",
        color=7,  # Белый/Черный
        lineweight=50,
        description="Графика условно-графических обозначений (УГО)",
    )

    # Позиционные обозначения (QF1, KM1, R1, C1) - тонкая линия 0.25 мм
    REFDES = LayerDef(
        name="EL_REFDES",
        color=6,  # Пурпурный
        lineweight=25,
        description="Позиционные обозначения компонентов",
    )

    # Номиналы, технические характеристики, типы - тонкая линия 0.20 мм
    PARAMS = LayerDef(
        name="EL_PARAMS",
        color=3,  # Зеленый
        lineweight=20,
        description="Параметры, номиналы и типы аппаратов",
    )

    # Номера клемм, контактов и выводов - тонкая линия 0.20 мм
    TERMINALS = LayerDef(
        name="EL_TERMINALS",
        color=2,  # Желтый
        lineweight=20,
        description="Номера клемм, маркировка цепей и контактов",
    )

    # Рамка чертежа и штамп по ГОСТ 2.104 - 0.70 мм (внешняя) и 0.25 мм
    FRAME = LayerDef(
        name="EL_FRAME",
        color=7,  # Белый/Черный
        lineweight=70,
        description="Рамка формата и основная надпись (штамп)",
    )

    # Таблицы спецификаций, перечня элементов (ПЭ3), таблиц нагрузок
    TABLES = LayerDef(
        name="EL_TABLES",
        color=7,  # Белый/Черный
        lineweight=35,
        description="Таблицы перечня элементов и спецификаций",
    )

    # Текстовые пояснения, заголовки, маркировки и примечания - 0.25 мм
    TEXT = LayerDef(
        name="EL_TEXT",
        color=7,  # Белый/Черный
        lineweight=25,
        description="Текстовые пояснения, таблицы и примечания",
    )

    # Вспомогательная координатная сетка (отключаемый слой)
    GRID = LayerDef(
        name="EL_GRID",
        color=8,  # Серый
        lineweight=9,
        description="Вспомогательная координатная сетка",
    )

    @classmethod
    def all_layers(cls) -> list[LayerDef]:
        """Возвращает список всех предопределенных слоев."""
        return [
            cls.WIRES,
            cls.SYMBOLS,
            cls.REFDES,
            cls.PARAMS,
            cls.TERMINALS,
            cls.TEXT,
            cls.FRAME,
            cls.TABLES,
            cls.GRID,
        ]

    @classmethod
    def setup_layers(cls, doc: Any) -> None:
        """Регистрирует все стандартные слои в документе ezdxf."""
        for layer_def in cls.all_layers():
            if layer_def.name not in doc.layers:
                layer = doc.layers.add(
                    name=layer_def.name,
                    color=layer_def.color,
                    linetype=layer_def.linetype,
                    lineweight=layer_def.lineweight,
                )
                layer.description = layer_def.description

"""Модульная координатная сетка и геометрические примитивы точек."""

from __future__ import annotations
import math
from dataclasses import dataclass
from typing import Tuple, Union


@dataclass(frozen=True)
class Point:
    """Точка в 2D-пространстве схемы (в миллиметрах)."""

    x: float
    y: float

    def offset(self, dx: float = 0.0, dy: float = 0.0) -> Point:
        """Возвращает новую точку со смещением."""
        return Point(self.x + dx, self.y + dy)

    def distance_to(self, other: Point) -> float:
        """Евклидово расстояние до другой точки."""
        return math.hypot(self.x - other.x, self.y - other.y)

    def manhattan_to(self, other: Point) -> float:
        """Манхэттенское расстояние (по сетке) до другой точки."""
        return abs(self.x - other.x) + abs(self.y - other.y)

    def to_tuple(self) -> Tuple[float, float]:
        """Преобразование в кортеж (x, y) для совместимости с ezdxf."""
        return (self.x, self.y)

    def __add__(self, other: Union[Point, Tuple[float, float]]) -> Point:
        if isinstance(other, Point):
            return Point(self.x + other.x, self.y + other.y)
        return Point(self.x + other[0], self.y + other[1])

    def __sub__(self, other: Union[Point, Tuple[float, float]]) -> Point:
        if isinstance(other, Point):
            return Point(self.x - other.x, self.y - other.y)
        return Point(self.x - other[0], self.y - other[1])

    def __mul__(self, scalar: float) -> Point:
        return Point(self.x * scalar, self.y * scalar)

    def __repr__(self) -> str:
        return f"Point({self.x:.2f}, {self.y:.2f})"


class Grid:
    """Модульная координатная сетка для электрических схем."""

    def __init__(self, step: float = 5.0):
        """
        Инициализация координатной сетки.
        :param step: Шаг модульной сетки в миллиметрах (обычно 5.0 мм по ГОСТ 2.701/2.702 или 2.5 мм).
        """
        if step <= 0:
            raise ValueError("Шаг сетки должен быть строго положительным числом.")
        self.step = float(step)

    def snap_value(self, val: float) -> float:
        """Квантование одного числового значения к ближайшему узлу сетки."""
        snapped = round(val / self.step) * self.step
        # Избавляемся от отрицательного нуля -0.0
        return 0.0 if abs(snapped) < 1e-9 else round(snapped, 4)

    def snap(self, x: Union[float, Point, Tuple[float, float]], y: float | None = None) -> Point:
        """
        Принудительное выравнивание координат точки по узлам сетки.
        Поддерживает вызов snap(x, y) или snap(Point) или snap((x, y)).
        """
        if isinstance(x, Point):
            px, py = x.x, x.y
        elif isinstance(x, (tuple, list)):
            px, py = x[0], x[1]
        elif y is not None:
            px, py = float(x), float(y)
        else:
            raise ValueError("Некорректные аргументы для snap(). Ожидается (x, y) или Point.")

        return Point(self.snap_value(px), self.snap_value(py))

    def is_on_grid(self, pt: Point, tol: float = 1e-3) -> bool:
        """Проверяет, лежит ли точка строго на узле координатной сетки."""
        rem_x = abs(pt.x % self.step)
        rem_y = abs(pt.y % self.step)
        on_x = rem_x <= tol or abs(rem_x - self.step) <= tol
        on_y = rem_y <= tol or abs(rem_y - self.step) <= tol
        return on_x and on_y

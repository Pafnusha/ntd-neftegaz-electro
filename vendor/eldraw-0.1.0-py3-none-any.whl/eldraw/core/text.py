"""Модуль работы с текстом, геометрическими границами (Bounding Box) и выравниванием по ГОСТ."""

from __future__ import annotations
import math
from dataclasses import dataclass
from typing import Tuple, Optional
from eldraw.core.grid import Point
from eldraw.core.styles import StandardStyles


@dataclass
class TextEntity:
    """Текстовый элемент на чертеже с расчетом габаритов и коллизий."""

    text: str
    position: Point
    height: float = StandardStyles.HEIGHT_REFDES
    rotation: float = 0.0  # Угол поворота в градусах (0, 90, 180, 270)
    layer: str = "EL_REFDES"
    style: str = StandardStyles.STYLE_GOST
    align: str = "LEFT"  # "LEFT", "CENTER", "RIGHT"
    source: Optional[str] = None  # Ссылка на компонент-владелец (например, "QF1")

    @property
    def estimated_width(self) -> float:
        """
        Приблизительная ширина текста в миллиметрах для шрифта ГОСТ 2.304 (тип Б).
        Ширина большинства букв составляет ~0.6-0.65 от высоты шрифта,
        межсимвольный интервал ~0.15-0.2 от высоты.
        """
        if not self.text:
            return 0.0
        # Для однострочного текста
        lines = self.text.split("\n")
        max_len = max(len(line) for line in lines)
        char_width = self.height * 0.65
        return max_len * char_width

    @property
    def estimated_height(self) -> float:
        """Высота текстового блока в миллиметрах с учетом многострочности."""
        lines = self.text.split("\n")
        line_height = self.height * 1.3
        return len(lines) * line_height

    def get_bbox(self, margin: float = 0.5) -> Tuple[float, float, float, float]:
        """
        Вычисляет осесимметричный ограничивающий прямоугольник (AABB) текста в мировых координатах.
        :param margin: Дополнительный защитный отступ вокруг текста (по умолчанию 0.5 мм).
        :return: (x_min, y_min, x_max, y_max)
        """
        w = self.estimated_width
        h = self.estimated_height
        px, py = self.position.x, self.position.y
        rot = self.rotation % 360.0

        # Базовое смещение для точки вставки в зависимости от выравнивания
        if self.align.upper() == "CENTER":
            dx = -w / 2.0
            dy = -h / 2.0
        elif self.align.upper() == "RIGHT":
            dx = -w
            dy = 0.0
        else:  # LEFT
            dx = 0.0
            dy = 0.0

        if math.isclose(rot, 0.0, abs_tol=1e-3):
            x_min = px + dx - margin
            x_max = px + dx + w + margin
            y_min = py + dy - margin
            y_max = py + dy + h + margin
        elif math.isclose(rot, 90.0, abs_tol=1e-3):
            # Поворот на 90 градусов против часовой стрелки: X -> -Y, Y -> X
            x_min = px - h - margin
            x_max = px + margin
            y_min = py + dx - margin
            y_max = py + dx + w + margin
        elif math.isclose(rot, 180.0, abs_tol=1e-3):
            x_min = px - dx - w - margin
            x_max = px - dx + margin
            y_min = py - h - margin
            y_max = py + margin
        elif math.isclose(rot, 270.0, abs_tol=1e-3):
            x_min = px - margin
            x_max = px + h + margin
            y_min = py - dx - w - margin
            y_max = py - dx + margin
        else:
            # Для произвольного угла поворота рассчитываем крайние точки
            rad = math.radians(rot)
            cos_a, sin_a = math.cos(rad), math.sin(rad)
            corners = [
                (dx, dy),
                (dx + w, dy),
                (dx + w, dy + h),
                (dx, dy + h),
            ]
            rot_x = [px + (cx * cos_a - cy * sin_a) for cx, cy in corners]
            rot_y = [py + (cx * sin_a + cy * cos_a) for cx, cy in corners]
            x_min = min(rot_x) - margin
            x_max = max(rot_x) + margin
            y_min = min(rot_y) - margin
            y_max = max(rot_y) + margin

        return (round(x_min, 3), round(y_min, 3), round(x_max, 3), round(y_max, 3))

    def intersects_bbox(self, other_bbox: Tuple[float, float, float, float], margin: float = 0.0) -> bool:
        """Проверяет пересечение ограничивающего прямоугольника текста с другим прямоугольником."""
        b1_xmin, b1_ymin, b1_xmax, b1_ymax = self.get_bbox(margin=margin)
        b2_xmin, b2_ymin, b2_xmax, b2_ymax = other_bbox

        return not (
            b1_xmax < b2_xmin
            or b1_xmin > b2_xmax
            or b1_ymax < b2_ymin
            or b1_ymin > b2_ymax
        )

    def intersects_segment(
        self,
        p1: Point,
        p2: Point,
        margin: float = 0.5,
    ) -> bool:
        """
        Проверяет, пересекает ли отрезок линии связи (проводника) ограничивающий прямоугольник текста.
        """
        x_min, y_min, x_max, y_max = self.get_bbox(margin=margin)

        # 1. Проверка, лежит ли хотя бы один из концов внутри AABB
        if (x_min <= p1.x <= x_max and y_min <= p1.y <= y_max) or (
            x_min <= p2.x <= x_max and y_min <= p2.y <= y_max
        ):
            return True

        # 2. Быстрое отсечение: если обе точки строго слева/справа/сверху/снизу
        if (p1.x < x_min and p2.x < x_min) or (p1.x > x_max and p2.x > x_max):
            return False
        if (p1.y < y_min and p2.y < y_min) or (p1.y > y_max and p2.y > y_max):
            return False

        # 3. Проверка пересечения отрезка со всеми 4 ребрами прямоугольника
        edges = [
            (Point(x_min, y_min), Point(x_max, y_min)),  # низ
            (Point(x_max, y_min), Point(x_max, y_max)),  # право
            (Point(x_max, y_max), Point(x_min, y_max)),  # верх
            (Point(x_min, y_max), Point(x_min, y_min)),  # лево
        ]

        for e1, e2 in edges:
            if _segments_intersect(p1, p2, e1, e2):
                return True

        return False


def _segments_intersect(p1: Point, p2: Point, p3: Point, p4: Point) -> bool:
    """Проверяет пересечение двух 2D-отрезков p1-p2 и p3-p4."""
    def ccw(a: Point, b: Point, c: Point) -> float:
        return (c.y - a.y) * (b.x - a.x) - (b.y - a.y) * (c.x - a.x)

    d1 = ccw(p1, p2, p3)
    d2 = ccw(p1, p2, p4)
    d3 = ccw(p3, p4, p1)
    d4 = ccw(p3, p4, p2)

    if ((d1 > 0 and d2 < 0) or (d1 < 0 and d2 > 0)) and (
        (d3 > 0 and d4 < 0) or (d3 < 0 and d4 > 0)
    ):
        return True

    # Проверка коллинеарности
    if math.isclose(d1, 0.0, abs_tol=1e-5) and _on_segment(p1, p2, p3):
        return True
    if math.isclose(d2, 0.0, abs_tol=1e-5) and _on_segment(p1, p2, p4):
        return True
    if math.isclose(d3, 0.0, abs_tol=1e-5) and _on_segment(p3, p4, p1):
        return True
    if math.isclose(d4, 0.0, abs_tol=1e-5) and _on_segment(p3, p4, p2):
        return True

    return False


def _on_segment(p: Point, q: Point, r: Point) -> bool:
    """Проверяет, лежит ли точка r на отрезке pq (при условии коллинеарности)."""
    return (
        min(p.x, q.x) - 1e-5 <= r.x <= max(p.x, q.x) + 1e-5
        and min(p.y, q.y) - 1e-5 <= r.y <= max(p.y, q.y) + 1e-5
    )

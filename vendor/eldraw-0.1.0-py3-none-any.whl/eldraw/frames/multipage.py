"""Подсистема многолистовых проектов промышленной автоматизации (Robor / SPAC / EPLAN style).

Включает:
- ColumnGrid (12-колоночная координатная сетка листа 1..12)
- OffPageConnector (межстраничные стрелочные переходы цепей с адресацией Лист.Колонка)
- MultiPageProject (менеджер многостраничного альбома чертежей с авто-разрешением ссылок)
"""

from __future__ import annotations
import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Union

from eldraw.core.canvas import SchematicCanvas
from eldraw.core.grid import Point
from eldraw.core.layers import StandardLayers
from eldraw.symbols.base import Symbol


@dataclass
class ColumnGrid:
    """
    Координатная сетка колонок по ГОСТ / IEC (12 колонок на листе А3).
    Вычерчивается вдоль верхнего края внутренней рамки.
    """
    num_columns: int = 12
    x_min: float = 20.0       # Левый край внутренней рамки
    x_max: float = 415.0      # Правый край внутренней рамки (для А3)
    y_pos: float = 287.0      # Высота горизонтальной полосы колонок
    height: float = 5.0       # Высота строки номеров колонок

    @property
    def column_width(self) -> float:
        return (self.x_max - self.x_min) / float(self.num_columns)

    def get_column_center_x(self, col_index: int) -> float:
        """Возвращает X-координату центра колонки (col_index: 1..num_columns)."""
        idx = max(1, min(self.num_columns, int(col_index)))
        return self.x_min + (idx - 0.5) * self.column_width

    def get_column_by_x(self, x: float) -> int:
        """Определяет номер колонки (1..num_columns) по координате X."""
        if x < self.x_min:
            return 1
        if x >= self.x_max:
            return self.num_columns
        col = int((x - self.x_min) / self.column_width) + 1
        return max(1, min(self.num_columns, col))

    def draw_on_canvas(self, canvas: SchematicCanvas) -> None:
        """Отрисовывает верхний координатный пояс колонок."""
        layer = StandardLayers.FRAME.name
        text_layer = StandardLayers.FRAME.name

        # Нижняя линия пояса колонок
        canvas.add_line(Point(self.x_min, self.y_pos), Point(self.x_max, self.y_pos), layer=layer, lineweight=25)

        # Вертикальные засечки и номера колонок 1..12
        for i in range(self.num_columns + 1):
            x = self.x_min + i * self.column_width
            canvas.add_line(Point(x, self.y_pos), Point(x, self.y_pos + self.height), layer=layer, lineweight=25)

        for col in range(1, self.num_columns + 1):
            cx = self.get_column_center_x(col)
            canvas.add_text(
                str(col),
                position=Point(cx, self.y_pos + 1.2),
                height=2.5,
                align="CENTER",
                layer=text_layer,
            )


class OffPageConnector(Symbol):
    """
    Межстраничный соединитель цепей (Off-Page Connector / Cross-Sheet Wire Arrow).
    
    Вычерчивает стрелку направления перехода цепи с текстом маркировки
    провода и адреса целевого листа/колонки (напр. "8000R2  8002.1").
    """

    def __init__(
        self,
        refdes: str = "OPC1",
        net_name: str = "",
        target_ref: str = "",
        direction: str = "right",  # "right" (выход на след. лист) или "left" (вход с пред. листа)
    ):
        """
        :param net_name: Маркировка цепи/провода (напр. "8000R2", "813020").
        :param target_ref: Ссылка на целевой лист и колонку (напр. "8002.1", "8150.1").
        :param direction: "right" или "left".
        """
        self.net_name = net_name
        self.target_ref = target_ref
        self.direction = direction.lower()
        block_name = f"SYM_OPC_{self.direction.upper()}_{refdes}"
        super().__init__(block_name=block_name, refdes=refdes, value=target_ref, model="")
        self.show_labels = False

        # Точка подключения провода
        if self.direction == "right":
            self.add_pin("in", Point(-10.0, 0.0), direction=(-1.0, 0.0))
        else:
            self.add_pin("out", Point(10.0, 0.0), direction=(1.0, 0.0))

    def build_geometry(self, block) -> None:
        layer = StandardLayers.SYMBOLS.name
        text_layer = StandardLayers.TEXT.name
        lw = 50

        if self.direction == "right":
            # Стрелка вправо: вход на (-10, 0), острие на (0, 0)
            block.add_line((-10.0, 0.0), (-5.0, 0.0), dxfattribs={"layer": layer, "lineweight": lw})
            # Закрашенный треугольник стрелки от -5 до 0
            block.add_lwpolyline(
                [(-5.0, -2.5), (0.0, 0.0), (-5.0, 2.5)],
                close=True,
                dxfattribs={"layer": layer, "lineweight": lw},
            )
            # Надписи над и под стрелкой
            if self.net_name:
                block.add_text(self.net_name, dxfattribs={"layer": text_layer, "height": 1.8, "style": "GOST_B"}).set_placement((-12.0, 2.5))
            if self.target_ref:
                block.add_text(self.target_ref, dxfattribs={"layer": text_layer, "height": 1.8, "style": "GOST_B"}).set_placement((2.0, -0.8))
        else:
            # Стрелка влево: острие на (0, 0), выход на (10, 0)
            block.add_line((0.0, 0.0), (10.0, 0.0), dxfattribs={"layer": layer, "lineweight": lw})
            block.add_lwpolyline(
                [(5.0, -2.5), (0.0, 0.0), (5.0, 2.5)],
                close=True,
                dxfattribs={"layer": layer, "lineweight": lw},
            )
            if self.target_ref:
                block.add_text(self.target_ref, dxfattribs={"layer": text_layer, "height": 1.8, "style": "GOST_B"}).set_placement((-16.0, -0.8))
            if self.net_name:
                block.add_text(self.net_name, dxfattribs={"layer": text_layer, "height": 1.8, "style": "GOST_B"}).set_placement((6.0, 2.5))

    def get_bounds(self) -> Tuple[float, float, float, float]:
        if self.direction == "right":
            return (-15.0, -3.0, 25.0, 6.0)
        else:
            return (-25.0, -3.0, 15.0, 6.0)


class MultiPageProject:
    """
    Менеджер многостраничного альбома электрических схем (Project Manager).
    Управляет страницами, сквозными ссылками и пакетным экспортом.
    """

    def __init__(self, title: str = "Industrial Automation Project"):
        self.title = title
        self.pages: Dict[str, SchematicCanvas] = {}
        self.page_order: List[str] = []
        self.grids: Dict[str, ColumnGrid] = {}
        self._registry = None

    @property
    def registry(self):
        if self._registry is None:
            from eldraw.domain.model import DeviceRegistry
            self._registry = DeviceRegistry()
        return self._registry

    def add_page(
        self,
        sheet_number: str,
        canvas: SchematicCanvas,
        col_grid: Optional[ColumnGrid] = None,
    ) -> None:
        """Добавляет лист чертежа в проект."""
        self.pages[sheet_number] = canvas
        if col_grid is not None:
            self.grids[sheet_number] = col_grid
            self.registry.register_grid(sheet_number, col_grid)
        if sheet_number not in self.page_order:
            self.page_order.append(sheet_number)

    def get_page(self, sheet_number: str) -> Optional[SchematicCanvas]:
        return self.pages.get(sheet_number)

    def resolve_cross_references(self) -> Dict[str, int]:
        """Автоматически рассчитывает и связывает перекрестные ссылки между листами проекта."""
        return self.registry.resolve_cross_references(project=self)

    def export_all(self, output_dir: str = "output", prefix: str = "project") -> List[str]:
        """Пакетный экспорт всех листов проекта во все форматы (DXF, SVG, PNG, PDF)."""
        import os
        os.makedirs(output_dir, exist_ok=True)
        generated_files = []

        for sheet_no in self.page_order:
            canvas = self.pages[sheet_no]
            base_name = f"{prefix}_sh{sheet_no}"

            dxf_path = os.path.join(output_dir, f"{base_name}.dxf")
            svg_path = os.path.join(output_dir, f"{base_name}.svg")
            png_path = os.path.join(output_dir, f"{base_name}.png")
            pdf_path = os.path.join(output_dir, f"{base_name}.pdf")

            canvas.save_dxf(dxf_path)
            canvas.render_svg(svg_path)
            canvas.render_png(png_path, dpi=300)
            canvas.render_pdf(pdf_path)

            generated_files.extend([dxf_path, svg_path, png_path, pdf_path])

        return generated_files

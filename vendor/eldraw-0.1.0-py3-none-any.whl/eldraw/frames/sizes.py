"""Стандартные форматы листов по ГОСТ 2.301-68 и геометрия рамок по ГОСТ 2.104-2006."""

from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import Tuple


class FormatOrientation(str, Enum):
    """Ориентация чертёжного листа."""

    PORTRAIT = "portrait"
    LANDSCAPE = "landscape"


@dataclass(frozen=True)
class SheetDimensions:
    """Геометрические размеры листа и внутренней рамки в миллиметрах."""

    name: str
    width: float
    height: float
    orientation: FormatOrientation = FormatOrientation.LANDSCAPE

    # Отступы по ГОСТ 2.104-2006:
    # 20 мм слева (поле подшивки), по 5 мм с остальных сторон
    MARGIN_LEFT: float = 20.0
    MARGIN_RIGHT: float = 5.0
    MARGIN_TOP: float = 5.0
    MARGIN_BOTTOM: float = 5.0

    @property
    def inner_x_min(self) -> float:
        """Левая координата внутренней рамки."""
        return self.MARGIN_LEFT

    @property
    def inner_y_min(self) -> float:
        """Нижняя координата внутренней рамки."""
        return self.MARGIN_BOTTOM

    @property
    def inner_x_max(self) -> float:
        """Правая координата внутренней рамки."""
        return self.width - self.MARGIN_RIGHT

    @property
    def inner_y_max(self) -> float:
        """Верхняя координата внутренней рамки."""
        return self.height - self.MARGIN_TOP

    @property
    def inner_width(self) -> float:
        """Ширина рабочего поля внутри рамки."""
        return self.inner_x_max - self.inner_x_min

    @property
    def inner_height(self) -> float:
        """Высота рабочего поля внутри рамки."""
        return self.inner_y_max - self.inner_y_min

    @property
    def title_block_origin(self) -> Tuple[float, float]:
        """
        Точка вставки основной надписи (правый нижний угол штампа совпадает
        с правым нижним углом внутренней рамки).
        Возвращает левый нижний угол штампа шириной 185 мм.
        """
        return (self.inner_x_max - 185.0, self.inner_y_min)


class SheetFormat:
    """Каталог стандартных форматов листов ЕСКД."""

    # А4 по ГОСТ 2.301 выполняется преимущественно вертикальным
    A4 = SheetDimensions("A4", 210.0, 297.0, FormatOrientation.PORTRAIT)
    A4_LANDSCAPE = SheetDimensions("A4", 297.0, 210.0, FormatOrientation.LANDSCAPE)

    # А3 — наиболее частый формат для электрических схем щитов и автоматики
    A3 = SheetDimensions("A3", 420.0, 297.0, FormatOrientation.LANDSCAPE)
    A3_PORTRAIT = SheetDimensions("A3", 297.0, 420.0, FormatOrientation.PORTRAIT)

    # А2 и А1 для крупных проектов подстанций и ВРУ
    A2 = SheetDimensions("A2", 594.0, 420.0, FormatOrientation.LANDSCAPE)
    A1 = SheetDimensions("A1", 841.0, 594.0, FormatOrientation.LANDSCAPE)

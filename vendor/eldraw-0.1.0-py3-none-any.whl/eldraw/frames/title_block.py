"""Основная надпись (штамп) по ГОСТ 2.104-2006 (Форма 1 и Форма 2а)."""

from __future__ import annotations
from dataclasses import dataclass
from typing import TYPE_CHECKING, Tuple

from eldraw.core.layers import StandardLayers
from eldraw.core.styles import StandardStyles

if TYPE_CHECKING:
    from eldraw.core.canvas import SchematicCanvas


@dataclass
class TitleBlockData:
    """Данные для заполнения граф основной надписи по ГОСТ 2.104."""

    title: str = "Схема электрическая принципиальная"  # Графа 1
    doc_code: str = "ЭБ.001.000.Э3"  # Графа 2 (Децимальный номер / обозначение)
    organization: str = ""  # Графа 9 (Предприятие / организация)
    designer: str = ""  # Графа 11 (Разработал)
    checker: str = ""  # Графа 11 (Проверил)
    tech_controller: str = ""  # Графа 11 (Т. контр.)
    norm_controller: str = ""  # Графа 11 (Н. контр.)
    approver: str = ""  # Графа 11 (Утвердил)
    date: str = ""  # Графа 13 (Дата)
    sheet_number: int = 1  # Графа 7 (Лист)
    total_sheets: int = 1  # Графа 8 (Листов)
    litera: str = "Э"  # Графа 4 (Литера)
    mass: str = "—"  # Графа 5 (Масса)
    scale: str = "—"  # Графа 6 (Масштаб)


class TitleBlockForm1:
    """
    Основная надпись по ГОСТ 2.104-2006, Форма 1 (185 × 55 мм).
    Применяется для первых и заглавных листов схем и чертежей.
    """

    WIDTH = 185.0
    HEIGHT = 55.0

    @classmethod
    def draw(cls, canvas: SchematicCanvas, origin: Tuple[float, float], data: TitleBlockData) -> None:
        """
        Вычерчивает штамп Форма 1.
        :param canvas: Холст схемы.
        :param origin: Координаты (x0, y0) левого нижнего угла штампа.
        :param data: Данные для заполнения граф.
        """
        x0, y0 = origin
        x_max = x0 + cls.WIDTH
        y_max = y0 + cls.HEIGHT

        # Толщины линий по ГОСТ:
        # Толстая основная линия s = 0.70 мм (lineweight 70)
        # Сплошная тонкая линия s/2 = 0.25 мм (lineweight 25)
        lw_thick = 70
        lw_thin = 25
        layer = StandardLayers.FRAME.name

        # --- 1. Внешний контур штампа 185 x 55 мм (толстая линия) ---
        canvas.add_rect((x0, y0), (x_max, y_max), layer=layer, lineweight=lw_thick, snap=False)

        # --- 2. Главные горизонтальные разделители ---
        # Линия y = y0 + 40 (отделяет таблицу изменений, децимальный номер и литеру)
        canvas.add_line((x0, y0 + 40.0), (x_max, y0 + 40.0), layer=layer, lineweight=lw_thick, snap=False)

        # Линия y = y0 + 20 в правой зоне (отделяет Организацию от Листа/Листов)
        canvas.add_line((x0 + 135.0, y0 + 20.0), (x_max, y0 + 20.0), layer=layer, lineweight=lw_thick, snap=False)

        # --- 3. Главные вертикальные разделители ---
        # Граница левого блока подписей (x = x0 + 65.0)
        canvas.add_line((x0 + 65.0, y0), (x0 + 65.0, y_max), layer=layer, lineweight=lw_thick, snap=False)

        # Граница между графой 1 (наименование) и графой 9/Лист (x = x0 + 135.0)
        canvas.add_line((x0 + 135.0, y0), (x0 + 135.0, y_max), layer=layer, lineweight=lw_thick, snap=False)

        # --- 4. Левый блок: Строки подписей (y от y0 до y0 + 40.0) ---
        # Вертикальные разделители колонок подписей
        canvas.add_line((x0 + 17.0, y0), (x0 + 17.0, y0 + 40.0), layer=layer, lineweight=lw_thin, snap=False)
        canvas.add_line((x0 + 40.0, y0), (x0 + 40.0, y_max), layer=layer, lineweight=lw_thin, snap=False)
        canvas.add_line((x0 + 55.0, y0), (x0 + 55.0, y_max), layer=layer, lineweight=lw_thin, snap=False)

        # Горизонтальные строчные разделители (8 строк по 5 мм)
        for i in range(1, 8):
            y_line = y0 + i * 5.0
            canvas.add_line((x0, y_line), (x0 + 65.0, y_line), layer=layer, lineweight=lw_thin, snap=False)

        # --- 5. Левый блок: Таблица изменений (y от y0 + 40.0 до y_max) ---
        canvas.add_line((x0 + 7.0, y0 + 40.0), (x0 + 7.0, y_max), layer=layer, lineweight=lw_thin, snap=False)
        canvas.add_line((x0 + 17.0, y0 + 40.0), (x0 + 17.0, y_max), layer=layer, lineweight=lw_thin, snap=False)
        canvas.add_line((x0, y0 + 45.0), (x0 + 65.0, y0 + 45.0), layer=layer, lineweight=lw_thin, snap=False)
        canvas.add_line((x0, y0 + 50.0), (x0 + 65.0, y0 + 50.0), layer=layer, lineweight=lw_thin, snap=False)

        # --- 6. Правый блок: Литера, масса, масштаб (y от y0 + 40.0 до y_max) ---
        canvas.add_line((x0 + 135.0, y0 + 50.0), (x_max, y0 + 50.0), layer=layer, lineweight=lw_thin, snap=False)
        canvas.add_line((x0 + 150.0, y0 + 40.0), (x0 + 150.0, y_max), layer=layer, lineweight=lw_thin, snap=False)
        canvas.add_line((x0 + 167.0, y0 + 40.0), (x0 + 167.0, y_max), layer=layer, lineweight=lw_thin, snap=False)

        # --- 7. Правый блок: Лист и Листов (y от y0 + 20.0 до y0 + 40.0) ---
        canvas.add_line((x0 + 135.0, y0 + 35.0), (x_max, y0 + 35.0), layer=layer, lineweight=lw_thin, snap=False)
        canvas.add_line((x0 + 155.0, y0 + 20.0), (x0 + 155.0, y0 + 40.0), layer=layer, lineweight=lw_thin, snap=False)

        # =========================================================================
        # ТЕКСТОВЫЕ ПОДПИСИ И ЗАПОЛНЕНИЕ ГРАФ
        # =========================================================================

        # Таблица изменений: заголовки
        cls._add_text(canvas, "Изм.", (x0 + 1.0, y0 + 51.2), height=2.5)
        cls._add_text(canvas, "Лист", (x0 + 8.0, y0 + 51.2), height=2.5)
        cls._add_text(canvas, "№ докум.", (x0 + 18.0, y0 + 51.2), height=2.5)
        cls._add_text(canvas, "Подп.", (x0 + 42.0, y0 + 51.2), height=2.5)
        cls._add_text(canvas, "Дата", (x0 + 56.5, y0 + 51.2), height=2.5)

        # Роли подписывающих
        roles = [
            ("Разраб.", data.designer, y0 + 36.2),
            ("Пров.", data.checker, y0 + 31.2),
            ("Т.контр.", data.tech_controller, y0 + 26.2),
            ("", "", y0 + 21.2),
            ("", "", y0 + 16.2),
            ("", "", y0 + 11.2),
            ("Н.контр.", data.norm_controller, y0 + 6.2),
            ("Утв.", data.approver, y0 + 1.2),
        ]

        for role_title, person_name, y_pos in roles:
            if role_title:
                cls._add_text(canvas, role_title, (x0 + 1.5, y_pos), height=2.5)
            if person_name:
                cls._add_text(canvas, person_name, (x0 + 18.5, y_pos), height=2.5)
            if data.date:
                cls._add_text(canvas, data.date, (x0 + 56.0, y_pos), height=2.1)

        # Графа 1: Наименование изделия / схемы (центр x0+65 .. x0+135, y0 .. y0+40)
        lines = [line.strip() for line in data.title.split("\n") if line.strip()]
        if len(lines) == 1 and len(lines[0]) * (3.5 * 0.65) > 55.0:
            words = lines[0].split(" ")
            mid = len(words) // 2
            if mid > 0:
                lines = [" ".join(words[:mid]), " ".join(words[mid:])]

        if len(lines) == 1:
            cls._add_text(canvas, lines[0], (x0 + 100.0, y0 + 20.0), height=3.5, align="CENTER")
        elif len(lines) >= 2:
            cls._add_text(canvas, lines[0], (x0 + 100.0, y0 + 24.0), height=3.5, align="CENTER")
            cls._add_text(canvas, lines[1], (x0 + 100.0, y0 + 16.0), height=3.0, align="CENTER")

        # Графа 2: Обозначение документа (децимальный номер, x0+65 .. x0+135, y0+40 .. y_max)
        cls._add_text(canvas, data.doc_code, (x0 + 100.0, y0 + 47.0), height=5.0, align="CENTER")

        # Графа 4, 5, 6: Лит., Масса, Масштаб
        cls._add_text(canvas, "Лит.", (x0 + 138.0, y0 + 51.2), height=2.5)
        cls._add_text(canvas, "Масса", (x0 + 152.0, y0 + 51.2), height=2.5)
        cls._add_text(canvas, "Масштаб", (x0 + 168.0, y0 + 51.2), height=2.1)

        cls._add_text(canvas, data.litera, (x0 + 140.0, y0 + 43.5), height=3.5)
        cls._add_text(canvas, data.mass, (x0 + 156.0, y0 + 43.5), height=3.5)
        cls._add_text(canvas, data.scale, (x0 + 172.0, y0 + 43.5), height=3.5)

        # Графа 7, 8: Лист, Листов
        cls._add_text(canvas, "Лист", (x0 + 140.0, y0 + 36.2), height=2.5)
        cls._add_text(canvas, "Листов", (x0 + 163.0, y0 + 36.2), height=2.5)

        cls._add_text(canvas, str(data.sheet_number), (x0 + 143.0, y0 + 26.0), height=4.0)
        cls._add_text(canvas, str(data.total_sheets), (x0 + 167.0, y0 + 26.0), height=4.0)

        # Графа 9: Предприятие / организация (x0+135 .. x_max, y0 .. y0+20)
        if data.organization:
            h_org = min(2.5, max(1.5, 36.0 / (len(data.organization) * 0.85)))
            cls._add_text(canvas, data.organization, (x0 + 160.0, y0 + 10.0), height=h_org, align="CENTER")

    @staticmethod
    def _add_text(canvas: SchematicCanvas, text: str, pos: Tuple[float, float], height: float, align: str = "LEFT") -> None:
        """Вспомогательный метод добавления текста в рамку штампа."""
        canvas.add_text(
            text=text,
            position=pos,
            height=height,
            layer=StandardLayers.FRAME.name,
            style=StandardStyles.STYLE_GOST,
            align=align,
            snap=False,
        )


class TitleBlockForm2a:
    """
    Основная надпись по ГОСТ 2.104-2006, Форма 2а (185 × 15 мм).
    Применяется для последующих листов многостраничных схем.
    """

    WIDTH = 185.0
    HEIGHT = 15.0

    @classmethod
    def draw(cls, canvas: SchematicCanvas, origin: Tuple[float, float], data: TitleBlockData) -> None:
        """Вычерчивает штамп последующих листов Форма 2а."""
        x0, y0 = origin
        x_max = x0 + cls.WIDTH
        y_max = y0 + cls.HEIGHT

        lw_thick = 70
        lw_thin = 25
        layer = StandardLayers.FRAME.name

        # Внешний контур 185 x 15 мм
        canvas.add_rect((x0, y0), (x_max, y_max), layer=layer, lineweight=lw_thick, snap=False)

        # Таблица изменений слева (65 мм)
        canvas.add_line((x0 + 65.0, y0), (x0 + 65.0, y_max), layer=layer, lineweight=lw_thick, snap=False)
        canvas.add_line((x0 + 7.0, y0), (x0 + 7.0, y_max), layer=layer, lineweight=lw_thin, snap=False)
        canvas.add_line((x0 + 17.0, y0), (x0 + 17.0, y_max), layer=layer, lineweight=lw_thin, snap=False)
        canvas.add_line((x0 + 40.0, y0), (x0 + 40.0, y_max), layer=layer, lineweight=lw_thin, snap=False)
        canvas.add_line((x0 + 55.0, y0), (x0 + 55.0, y_max), layer=layer, lineweight=lw_thin, snap=False)
        canvas.add_line((x0, y0 + 10.0), (x0 + 65.0, y0 + 10.0), layer=layer, lineweight=lw_thin, snap=False)

        # Децимальный номер (x0 + 65 до x0 + 175)
        canvas.add_line((x0 + 175.0, y0), (x0 + 175.0, y_max), layer=layer, lineweight=lw_thick, snap=False)

        # Лист (x0 + 175 до x_max)
        canvas.add_line((x0 + 175.0, y0 + 10.0), (x_max, y0 + 10.0), layer=layer, lineweight=lw_thin, snap=False)

        # Тексты
        TitleBlockForm1._add_text(canvas, "Изм.", (x0 + 1.0, y0 + 11.2), height=2.5)
        TitleBlockForm1._add_text(canvas, "Лист", (x0 + 8.0, y0 + 11.2), height=2.5)
        TitleBlockForm1._add_text(canvas, "№ докум.", (x0 + 18.0, y0 + 11.2), height=2.5)
        TitleBlockForm1._add_text(canvas, "Подп.", (x0 + 42.0, y0 + 11.2), height=2.5)
        TitleBlockForm1._add_text(canvas, "Дата", (x0 + 56.5, y0 + 11.2), height=2.5)

        # Децимальный номер
        TitleBlockForm1._add_text(canvas, data.doc_code, (x0 + 75.0, y0 + 5.0), height=5.0)

        # Лист
        TitleBlockForm1._add_text(canvas, "Лист", (x0 + 176.0, y0 + 11.2), height=2.5)
        TitleBlockForm1._add_text(canvas, str(data.sheet_number), (x0 + 178.0, y0 + 3.0), height=3.5)

"""Управление листом схемы: внешние границы, рамка по ГОСТ и штамп."""

from __future__ import annotations
from typing import TYPE_CHECKING, Optional, Tuple
from eldraw.core.layers import StandardLayers
from eldraw.frames.sizes import SheetDimensions, SheetFormat
from eldraw.frames.title_block import TitleBlockData, TitleBlockForm1, TitleBlockForm2a

if TYPE_CHECKING:
    from eldraw.core.canvas import SchematicCanvas


class Sheet:
    """Чертёжный лист с оформлением по ГОСТ 2.104-2006 и ГОСТ 2.301-68."""

    def __init__(
        self,
        dimensions: SheetDimensions = SheetFormat.A3,
        title_block_data: Optional[TitleBlockData] = None,
        is_first_sheet: bool = True,
        show_outer_border: bool = True,
        show_grafa_26: bool = True,
    ):
        """
        Инициализация чертёжного листа.
        :param dimensions: Геометрия формата (по умолчанию А3 альбомный 420x297 мм).
        :param title_block_data: Данные для заполнения граф штампа.
        :param is_first_sheet: Первый лист (Форма 1, 55 мм) или последующий (Форма 2а, 15 мм).
        :param show_outer_border: Вычерчивать ли внешнюю границу обреза листа.
        :param show_grafa_26: Вычерчивать ли графу 26 в левом верхнем углу (децимальный номер).
        """
        self.dimensions = dimensions
        self.title_data = title_block_data or TitleBlockData()
        self.is_first_sheet = is_first_sheet
        self.show_outer_border = show_outer_border
        self.show_grafa_26 = show_grafa_26

    @property
    def title_block_height(self) -> float:
        """Высота штампа в зависимости от формы."""
        return TitleBlockForm1.HEIGHT if self.is_first_sheet else TitleBlockForm2a.HEIGHT

    @property
    def working_bounds(self) -> Tuple[float, float, float, float]:
        """
        Габариты внутренней области чертежа (x_min, y_min, x_max, y_max).
        Обратите внимание: правый нижний угол занят штампом 185 мм шириной.
        """
        return (
            self.dimensions.inner_x_min,
            self.dimensions.inner_y_min,
            self.dimensions.inner_x_max,
            self.dimensions.inner_y_max,
        )

    def is_point_in_working_area(self, x: Any, y: Optional[float] = None) -> bool:
        """Проверяет, попадает ли точка в допустимую рабочую область чертежа (не наезжая на штамп)."""
        if hasattr(x, "x") and hasattr(x, "y"):
            px, py = float(x.x), float(x.y)
        elif isinstance(x, (tuple, list)) and len(x) >= 2:
            px, py = float(x[0]), float(x[1])
        elif y is not None:
            px, py = float(x), float(y)
        else:
            raise ValueError(f"Некорректные координаты точки: {x}, {y}")

        dims = self.dimensions
        # Проверка выхода за границы внутренней рамки
        if not (dims.inner_x_min <= px <= dims.inner_x_max and dims.inner_y_min <= py <= dims.inner_y_max):
            return False

        # Проверка наложения на область штампа в правом нижнем углу
        tb_x_min, tb_y_min = dims.title_block_origin
        tb_x_max = dims.inner_x_max
        tb_y_max = tb_y_min + self.title_block_height

        if tb_x_min <= px <= tb_x_max and tb_y_min <= py <= tb_y_max:
            return False

        return True

    def draw(self, canvas: SchematicCanvas) -> None:
        """
        Вычерчивает на холсте рамку и основную надпись.
        """
        dims = self.dimensions
        layer = StandardLayers.FRAME.name

        # 1. Внешняя линия листа (линия обреза) - тонкая линия 0.25 мм
        if self.show_outer_border:
            canvas.add_rect(
                (0.0, 0.0),
                (dims.width, dims.height),
                layer=layer,
                lineweight=25,
                snap=False,
            )

        # 2. Внутренняя рамка по ГОСТ 2.104 (20 мм слева, по 5 мм с остальных сторон)
        # Сплошная основная толстая линия s = 0.70 мм
        canvas.add_rect(
            (dims.inner_x_min, dims.inner_y_min),
            (dims.inner_x_max, dims.inner_y_max),
            layer=layer,
            lineweight=70,
            snap=False,
        )

        # 3. Дополнительная графа 26 в левом верхнем углу (децимальный номер, повернутый на 180 градусов)
        # Размер 70x14 мм по ГОСТ 2.104
        if self.show_grafa_26:
            g26_x0 = dims.inner_x_min
            g26_y0 = dims.inner_y_max - 14.0
            canvas.add_rect(
                (g26_x0, g26_y0),
                (g26_x0 + 70.0, dims.inner_y_max),
                layer=layer,
                lineweight=70,
                snap=False,
            )
            if self.title_data.doc_code:
                # Текст повернут на 180 градусов
                canvas.add_text(
                    text=self.title_data.doc_code,
                    position=(g26_x0 + 65.0, dims.inner_y_max - 4.5),
                    height=5.0,
                    layer=layer,
                    rotation=180.0,
                    snap=False,
                )

        # 4. Основная надпись (штамп в правом нижнем углу)
        origin = dims.title_block_origin
        if self.is_first_sheet:
            TitleBlockForm1.draw(canvas, origin, self.title_data)
        else:
            TitleBlockForm2a.draw(canvas, origin, self.title_data)

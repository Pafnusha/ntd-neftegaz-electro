"""
Таблица расчетных нагрузок и характеристик отходящих линий для однолинейных схем щитов.
Соответствует требованиям ГОСТ 2.702-2011 и РТМ 36.18.32.4-92.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import TYPE_CHECKING, List, Optional
from eldraw.core.grid import Point
from eldraw.core.layers import StandardLayers
from eldraw.core.styles import StandardStyles

if TYPE_CHECKING:
    from eldraw.core.canvas import SchematicCanvas


@dataclass
class LoadFeeder:
    """Параметры отходящей группы (фидера) распределительного щита."""

    group_num: str  # Номер группы ("1", "2", "3P-1")
    name: str  # Наименование электроприемника ("Освещение", "Розетки кухни")
    power_kw: float  # Установленная мощность Ру, кВт
    current_a: float  # Расчетный ток Iр, А
    phase: str  # Фаза подключения ("L1", "L2", "L3", "L1-L3")
    breaker: str  # Тип и номинал защитного аппарата ("10A B", "16A C", "25A 3P")
    cable: str  # Марка и сечение кабеля ("ВВГнг-LS 3x1.5")
    length_m: float  # Длина кабельной линии, м
    x_pos: float  # Координата X центра фидера на схеме
    width: float = 25.0  # Ширина колонки фидера (по умолчанию 25 мм)


class LoadTable:
    """Отрисовщик таблицы расчетных данных линий под однолинейной схемой щита."""

    # Строки таблицы: (Имя строки, высота строки в мм)
    ROWS = [
        ("Номер группы", 7.0),
        ("Наименование электроприемника", 14.0),
        ("Ру, кВт", 7.0),
        ("Iр, А", 7.0),
        ("Фаза", 7.0),
        ("Аппарат защиты", 10.0),
        ("Кабель (марка, сечение)", 10.0),
        ("Длина, м", 7.0),
    ]

    @classmethod
    def draw(
        cls,
        canvas: SchematicCanvas,
        feeders: List[LoadFeeder],
        header_x: float = 25.0,
        header_width: float = 45.0,
        y_bottom: float = 12.0,
    ) -> None:
        """
        Вычерчивает таблицу характеристик отходящих линий.
        :param canvas: Экземпляр SchematicCanvas.
        :param feeders: Список фидеров с параметрами и координатами.
        :param header_x: Левая координата шапки строк.
        :param header_width: Ширина колонки наименований строк (45 мм).
        :param y_bottom: Нижняя граница таблицы по оси Y.
        """
        if not feeders:
            return

        layer = StandardLayers.TABLES.name
        total_height = sum(h for _, h in cls.ROWS)
        y_top = y_bottom + total_height

        # Вычисляем общую ширину таблицы
        max_feeder_x = max(f.x_pos + f.width / 2.0 for f in feeders)
        total_width = max_feeder_x - header_x

        # Внешний контур таблицы (толщина 0.35 мм)
        canvas.add_rectangle(
            Point(header_x, y_bottom),
            Point(header_x + total_width, y_top),
            layer=layer,
            lineweight=35,
            snap=False,
        )

        # Разделительная вертикальная линия между шапкой строк и колонками фидеров
        canvas.add_line(
            Point(header_x + header_width, y_bottom),
            Point(header_x + header_width, y_top),
            layer=layer,
            lineweight=35,
            snap=False,
        )

        # Вычерчивание горизонтальных строк
        current_y = y_top
        for name, row_height in cls.ROWS:
            current_y -= row_height

            # Разделительная горизонтальная линия
            canvas.add_line(
                Point(header_x, current_y),
                Point(header_x + total_width, current_y),
                layer=layer,
                lineweight=20,
                snap=False,
            )

            # Текст заголовка строки в шапке
            cell_w = header_width - 3.0
            if len(name) * (2.0 * 0.65) > cell_w:
                if " " in name and row_height >= 9.0:
                    words = name.split(" ")
                    mid = len(words) // 2
                    line1 = " ".join(words[:mid])
                    line2 = " ".join(words[mid:])
                    canvas.add_text(
                        f"{line1}\n{line2}",
                        Point(header_x + header_width / 2.0, current_y + row_height / 2.0),
                        height=1.7,
                        layer=StandardLayers.REFDES.name,
                        align="CENTER",
                        source="LOAD_TABLE_HDR",
                        snap=False,
                    )
                else:
                    h_hdr = min(1.8, max(1.4, (cell_w - 1.0) / (len(name) * 0.65)))
                    canvas.add_text(
                        name,
                        Point(header_x + header_width / 2.0, current_y + row_height / 2.0),
                        height=h_hdr,
                        layer=StandardLayers.REFDES.name,
                        align="CENTER",
                        source="LOAD_TABLE_HDR",
                        snap=False,
                    )
            else:
                canvas.add_text(
                    name,
                    Point(header_x + header_width / 2.0, current_y + row_height / 2.0),
                    height=2.0,
                    layer=StandardLayers.REFDES.name,
                    align="CENTER",
                    source="LOAD_TABLE_HDR",
                    snap=False,
                )

        # Вычерчивание вертикальных колонок и данных фидеров
        for feeder in feeders:
            col_left = feeder.x_pos - feeder.width / 2.0
            col_right = feeder.x_pos + feeder.width / 2.0

            # Правая граница колонки
            canvas.add_line(
                Point(col_right, y_bottom),
                Point(col_right, y_top),
                layer=layer,
                lineweight=20,
                snap=False,
            )

            # Заполнение ячеек фидера данными
            data_values = [
                feeder.group_num,
                feeder.name,
                f"{feeder.power_kw:.1f}",
                f"{feeder.current_a:.1f}",
                feeder.phase,
                feeder.breaker,
                feeder.cable,
                f"{feeder.length_m:.0f}",
            ]

            row_y = y_top
            for val, (_, r_height) in zip(data_values, cls.ROWS):
                row_y -= r_height
                cell_w = feeder.width - 2.5
                char_w_std = 2.0 * 0.65  # 1.30 мм
                if len(val) * char_w_std <= cell_w:
                    f_height = 2.0
                elif len(val) * (1.6 * 0.65) <= cell_w:
                    f_height = 1.6
                else:
                    f_height = min(1.5, max(1.2, cell_w / (len(val) * 0.65)))

                canvas.add_text(
                    val,
                    Point(feeder.x_pos, row_y + r_height / 2.0),
                    height=f_height,
                    layer=StandardLayers.PARAMS.name,
                    align="CENTER",
                    source="LOAD_TABLE",
                    snap=False,
                )
